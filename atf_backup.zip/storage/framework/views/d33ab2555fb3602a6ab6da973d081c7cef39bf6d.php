  
<?php $__env->startSection('admin_main_content'); ?>    

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    
                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">

                        <h3 class="no_padding bottom_padding"><i class="fas fa-cog fa-spin"></i> Settings </h3>

                    </div>

                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                                    

                    <div class="box_layout right_padding col-md-12 col-sm-12 col-xs-12">
                               
                        <?php echo Form::open(['url'=>'/update-user-settings','method'=>'post','enctype'=>'multipart/form-data']); ?>


                            <h3>
                                <!-- <svg 
                                    aria-hidden="true" 
                                    data-prefix="fas" 
                                    data-icon="user-cog" 
                                    role="img" 
                                    xmlns="http://www.w3.org/2000/svg" 
                                    viewBox="0 0 640 512" 
                                    class="svg-inline--fa fa-user-cog fa-w-20 fa-spin fa-lg"
                                    style="width: 25px;"
                                    ><path 
                                        fill="currentColor"
                                        d="M610.5 373.3c2.6-14.1 2.6-28.5 0-42.6l25.8-14.9c3-1.7 4.3-5.2 3.3-8.5-6.7-21.6-18.2-41.2-33.2-57.4-2.3-2.5-6-3.1-9-1.4l-25.8 14.9c-10.9-9.3-23.4-16.5-36.9-21.3v-29.8c0-3.4-2.4-6.4-5.7-7.1-22.3-5-45-4.8-66.2 0-3.3.7-5.7 3.7-5.7 7.1v29.8c-13.5 4.8-26 12-36.9 21.3l-25.8-14.9c-2.9-1.7-6.7-1.1-9 1.4-15 16.2-26.5 35.8-33.2 57.4-1 3.3.4 6.8 3.3 8.5l25.8 14.9c-2.6 14.1-2.6 28.5 0 42.6l-25.8 14.9c-3 1.7-4.3 5.2-3.3 8.5 6.7 21.6 18.2 41.1 33.2 57.4 2.3 2.5 6 3.1 9 1.4l25.8-14.9c10.9 9.3 23.4 16.5 36.9 21.3v29.8c0 3.4 2.4 6.4 5.7 7.1 22.3 5 45 4.8 66.2 0 3.3-.7 5.7-3.7 5.7-7.1v-29.8c13.5-4.8 26-12 36.9-21.3l25.8 14.9c2.9 1.7 6.7 1.1 9-1.4 15-16.2 26.5-35.8 33.2-57.4 1-3.3-.4-6.8-3.3-8.5l-25.8-14.9zM496 400.5c-26.8 0-48.5-21.8-48.5-48.5s21.8-48.5 48.5-48.5 48.5 21.8 48.5 48.5-21.7 48.5-48.5 48.5zM224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm201.2 226.5c-2.3-1.2-4.6-2.6-6.8-3.9l-7.9 4.6c-6 3.4-12.8 5.3-19.6 5.3-10.9 0-21.4-4.6-28.9-12.6-18.3-19.8-32.3-43.9-40.2-69.6-5.5-17.7 1.9-36.4 17.9-45.7l7.9-4.6c-.1-2.6-.1-5.2 0-7.8l-7.9-4.6c-16-9.2-23.4-28-17.9-45.7.9-2.9 2.2-5.8 3.2-8.7-3.8-.3-7.5-1.2-11.4-1.2h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c10.1 0 19.5-3.2 27.2-8.5-1.2-3.8-2-7.7-2-11.8v-9.2z" 
                                        class=""
                                    ></path>
                                </svg> -->
                                <i class="fas fa-user-cog"></i> User Settings </h3> 
                            <hr>

                            <div class="no_padding right_padding col-md-5 col-sm-12 col-xs-12">

                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label class="control-label" > ID: </label>
                                    <input type="text" id="" class="form-control admin_id" value="<?php echo e(Session::get('admin_id')); ?>" disabled>
                                    <input type="hidden" id=""  name="admin_id" value="<?php echo e(Session::get('admin_id')); ?>" class="form-control">
                                    <input type="hidden" class="old_image" name="old_image" >
                                    
                                </div>

                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label for="user-name">User Name:</label>
                                    <input type="text" class="form-control" value="<?php echo e(Session::get('admin_name')); ?>" name="admin_name" placeholder="User Name" id="admin-name" required>
                                </div>
                                
                                
                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                
                                    <label for="user-image">User Image:</label>
                                    
                                    <input type="file" class="form-control" name="admin_image" id="admin-image">
                                    
                                    <br>
                                    
                                    <img src="<?php echo e(asset(Session::get('admin_image'))); ?>" alt="<?php echo e(Session::get('admin_name')); ?>" class="img-circle" height="80px" width="auto">
                                    
                                </div>

                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label for="Old-Email">Old Email:</label>
                                    <input type="email" class="form-control" value="" name="old_email" placeholder="Old Email" id="Old-Email">
                                </div>
                                
                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label for="New-Email">New Email:</label>
                                    <input type="email" class="form-control" value="" name="admin_email" placeholder="New Email" id="New-Email">
                                </div>
                                
                                
                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label for="old-pass">Old Password:</label>
                                    <input type="psw" class="form-control" value="" name="old_password" placeholder="Old Password" id="old-pass">
                                </div>
                                
                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label for="New-pass">New Password:</label>
                                    <input type="psw" class="form-control" value="" name="admin_password" placeholder="New Password" id="New-pass">
                                </div>
                                
                                <div class="form-group form-group-sm" style="margin-bottom: 25px;">
                                    <label for="RetypeNew-pass">Retype New Password:</label>
                                    <input type="psw" class="form-control" value="" name="retype_password" placeholder="Retype New Password" id="RetypeNew-pass">
                                </div>
				

                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-md"><i class="fa fa-cogs"></i> Save Settings</button>
                                </div> 

                            </div> 

                        <?php echo Form::close(); ?>


                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>