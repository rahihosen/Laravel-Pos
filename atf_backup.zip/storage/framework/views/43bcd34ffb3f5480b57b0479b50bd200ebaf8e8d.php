<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mukto Restaura </title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    
    <style>
        body{
            margin:0;
            padding:0;
        }
        .print_page {
            margin:3px;
            padding:7px;
            border:1px solid lightgray;
        }
        .print_page img{
            margin:0 auto;
            padding:0;
        }
        .print_page h4{
            margin:0;
            padding:5px 0 0 0;
            text-align:center;
        }
        .print_page p{
            margin:0;
            padding:3px 0;
            text-align:center;
            font-size:11px;
        }
        table {
            width:100%;
            text-align:left;
            margin:0;
            padding:3px 0;
        }
        table td{
            text-align:left;
            font-size:12px;
            padding:3px 0;
        }
        table.table_prc td{
            text-align:right;
        }
    </style>
   
   
  </head>
  
  
  
  <body class="print_page">
       <?php 
            $company=DB::table('settings')
                    ->first();
            ?>
    <p><img src="<?php echo e(asset($company->company_logo)); ?>" width="60" height="45"></p>
    <h4><?php echo $company->company_name; ?></h4>
    <p><?php echo $company->company_address; ?></br>Email: <?php echo $company->company_email;?>, Mob: <?php echo $company->company_mobile;?></br></p>
    <table>
        <tbody>
            <tr><?php
                foreach($single_order_info_customer as $order_customer){?>
    
                <?php
                    $customer_id=$order_customer->customer_id;
                ?>
                <td>Order # <?php echo $order_id=$order_customer->order_id;?></td>
                <td>Date: <?php echo $order_id=$order_customer->order_created_date;?></td> <?php 
       
                }
               ?>
               <?php 
                $order_id=$order_customer->order_id;
                 $table_number = DB::table('order_details')
                                ->where('order_id',$order_id)
                                ->first();
                ?>
                <td>Table # <?php echo $table_number->table_number;?></td>
            </tr>
        </tbody>
    </table>
    <?php 
    $customer = DB::table('customer')
                ->where('customer_id',$customer_id)
                ->get();
    foreach($customer as $cust){ ?>
    <table>
        <tbody>
            <tr>
                <td>Customer: <?php echo $cust->customer_name;?></td>
                <td>Mob: <?php echo $cust->customer_mobile;?></td>
            </tr>
        </tbody>
    </table>
        
    <?php  } ?>
    
    <table class="table_prc" style="border-top:1px solid lightgray;">
                <tr>
                    <td><b>Item</b></td>
                    <td><b>Qty</b></td>
                    <td><b>Price</b></td>
                    <td><b>S.Total</b></td>
                </tr>

              
              <?php $__currentLoopData = $single_order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($order->product_name); ?></td>
                    <td><?php echo e($order->product_qty); ?></td>
                    <td><?php echo e($order->product_sale_price); ?></td>
                    <td><?php echo e($order->product_qty*$order->product_sale_price); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                

                <tr style="border-top:1px solid lightgray;">
                    <?php $order_id=$order->order_id;?>
                    
                    <td colspan="2"><b>Total</b></td>
                    <td colspan="2"><b><?php echo e($order = DB::table('order')
                ->where('order_id',$order_id)
                ->sum('order_total')); ?> TK.</b></td>
                
                </tr>
                
                <tr>
                    <?php 
                 $dis_rec_ret = DB::table('order')
                                ->where('order_id',$order_id)
                                ->first();
                ?>
                    
                    <td colspan="2"><b>Discount</b></td>
                    <td colspan="2"><b><?php echo $dis_rec_ret->order_discount;?>%</b></td>
                
                </tr>
                <tr>
                    
                    <td colspan="2"><b>Payable</b></td>
                    <td colspan="2"><b><?php echo $dis_rec_ret->total_amount_payable;?> TK.</b></td>
                
                </tr>
                <tr>
                    
                    <td colspan="2"><b>Cash</b></td>
                    <td colspan="2"><b><?php echo $dis_rec_ret->amount_received;?> TK.</b></td>
                
                </tr>
                <tr>
                    
                    <td colspan="2"><b>Return</b></td>
                    <td colspan="2"><b><?php echo $dis_rec_ret->amount_return;?> TK.</b></td>
                
                </tr>

            </table>
            
  </body>
 
  
  
  
   
   <script src="<?php echo e(asset('public/admin_asset/vendors/jquery/dist/jquery.min.js')); ?>"></script>
   <!-- Bootstrap -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    
    
    <script>
        window.print();
        window.close();
    </script>
  
</html>