  
<?php $__env->startSection('admin_main_content'); ?>
    
    <div class="right_col right_col_back" role="main">
    
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="box_layout col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <h3 class="no_padding"><i class="fa fa-shopping-bag"></i> Stock Product List </h3>
                    </div>

                    <!-- name Search list -->
                    <div class="col-md-8 col-sm-8 col-xs-12">

                        <div class="form-group form-inline pull-right">
                            <button type="button" class="name_from_to_stock_list btn btn-success">Go!</button>
                        </div>

                        <div class="form-group form-inline pull-right">
                            <div class="input-group dae no_margin" style="width: 20em;">
                                
                                <select id="cat-name" name="fk_category_id" class="form-control fk_category_id" >

                                    <option value="0">None</option>

                                    <?php  $categorys = DB::table('category')->get(); ?>
                                    
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>

                        <div class="form-group form-inline pull-right no_margin">

                            <div class="input-group date no_margin">
                                <input type="text" class="search_stock form-control" placeholder="Search..." style="width: 20em;">
                            </div>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                    <!-- /name Search list -->
                </div>


                <?php 

                    $message = Session::get('message');

                    if ( $message !='') { ?>

                        <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                            <h5 class="text-center">

                                <?php

                                    if(isset($message)) { ?>

                                        <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <strong> <?php echo $message;?> </strong>
                                        </div>
                                        
                                    <?php
                                        Session::put('message','');
                                    }
                                ?>

                            </h5>
                        </div> 
                        
                        <?php 
                    }
                    
                ?>
                
                <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Stock List</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">

                            <div class="table-responsive">
                                <table class="table table-striped bulk_action table-responsive table-bordered">
                                    <thead>
                                        <tr class="headings">
                                            
                                            <th class="column-title text-center"> Product ID </th>
                                            <th class="column-title text-center"> Product Name </th>                                        
                                            <th class="column-title text-center"> Current Stock </th>
                                            <th class="column-title text-center"> last In </th>
                                            <th class="column-title text-center"> Total Sold </th>
                                            <th class="column-title text-center"> Action </th>

                                        </tr>
                                    </thead>

                                    <tbody class="search_results">
                                        <?php foreach($all_product_info as $product) { ?>

                                        <?php  $pid = $product->product_id; ?>

                                            <tr class="even pointer">
                                                
                                                <td class="text-center"><?php echo e($product->product_id); ?></td>
                                                <td class="text-center"><?php echo e($product->product_name); ?></td>
                                                <td class="text-center">
                                                    <?php 
                                                        $total = DB::table('stock')->where('product_id', $pid)->sum('stock_quantity');
                                                        
                                                        $total2 = DB::table('wastage')->where('product_id', $pid)->sum('wastage_quantity');

                                                        $total3 = DB::table('order_details')->where('product_id', $pid)->sum('product_qty');
                                                        
                                                        $result = ($total - $total2 - $total3);

                                                        echo $result;
                                                    ?>
                                                </td>                                            
                                                <td class="text-center">

                                                    <?php
                                                        $single_product = DB::table('stock')->where('product_id', $product->product_id)->orderBy('stock_id', 'DESC')->value('stock_quantity');

                                                        echo $single_product;
                                                    ?>
                                                    
                                                </td>

                                                <td class="text-center">
                                                    <?php 
                                                        $total = DB::table('order_details')->where('product_id', $pid)->sum('product_qty');
                                                        echo $total;
                                                    ?>
                                                </td>
                                                
                                                <td class="last text-center">
                                                    
                                                    <button
                                                        class="btn btn-primary btn-xs add_stock" 
                                                        value="<?php echo e($product->product_id); ?>" 
                                                        data-productName="<?php echo e($product->product_name); ?>" 
                                                        ><i class="glyphicon glyphicon-plus-sign"></i> Add Stock
                                                    </button>

                                                    <button 
                                                        class="btn btn-info btn-xs view_stock" 
                                                        value="<?php echo e($product->product_id); ?>" 
                                                        data-productName="<?php echo e($product->product_name); ?>"
                                                        ><i class="glyphicon glyphicon-eye-open "></i> View Stock
                                                    </button>

                                                    <button 
                                                        class="btn btn-primary btn-xs add_wastage" 
                                                        value="<?php echo e($product->product_id); ?>" 
                                                        data-productName="<?php echo e($product->product_name); ?>"
                                                        ><i class="glyphicon glyphicon-plus-sign"></i> Add Wastage
                                                    </button>

                                                </td>
                                            </tr>

                                        <?php  } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>    
                        
                        <div class="hide_pagi pull-right">
                            <?php if( $all_product_info != '' ): ?>
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/add-stock?page=1')); ?>">First</a> </li>
                                </ul>

                                <?php echo e($all_product_info->links()); ?> 

                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/add-stock?page='.$all_product_info->lastPage())); ?>">Last</a> </li>
                                </ul>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Add Stock -->
    <div style="z-index:9999999999" class="modal fade add_stock_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Add Stock <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-stock', 'method'=>'post']); ?>

                        
                        <div class="form-group form-group-sm">
                            <input type="hidden" id="produict-id" name="product_id" value="" required="required" class="form-control product_id">

                            <label class="control-label" for="product-id">Product ID</label>
                            <input type="text" id="product-id" class="form-control product_id" value="" disabled>

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label " for="product-name">Product Name</label>
                            <input type="text" id="product-name" name="product_name" value="" required="required" class="form-control product_name" disabled>
                                                       
                            
                        </div>

                        <div class="form-group">

                            <label class="control-label" for="last-name">New Stock Quantity</label>
                            <input type="number" id="last-name" name="stock_quantity" min="0" required="required" class="form-control stock_quantity">
                            
                        </div>             

                        <div class="ln_solid"></div>
                        
                        <div class="form-group">
                            
                            <!-- <a href="<?php echo e(URL::to('add-stock')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" class="btn btn-success">Update</button>
                           
                        </div>

                    <?php echo Form::close(); ?>

                        
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    <!-- Modal View Stock -->
    <div style="z-index:9999999999" class="modal fade view_stock_modal" id="" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">View Stock "<span class="product_name"></span>" <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">Date / Time</th>
                                    <th class="text-center">Added By</th>
                                    <th class="text-center">Quantity</th>
                                    
                                </tr>
                            </thead>
                            <tbody class="return_product">
                                
                                
                                                                        
                            </tbody>
                        </table>
                    </div> 

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>


    <!-- Modal Add Wastage -->
    <div style="z-index:9999999999" class="modal fade add_wastage_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Add Westage <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/store-wastage', 'method'=>'post']); ?>

                        
                        <div class="form-group form-group-sm">
                            <input type="hidden" id="produict-id" name="product_id" value="" required="required" class="form-control product_id">

                            <label class="control-label" for="product-id">Product ID</label>
                            <input type="text" id="product-id" class="form-control product_id" value="" disabled>

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label " for="product-name">Product Name</label>
                            <input type="text" id="product-name" name="product_name" value="" required="required" class="form-control product_name" disabled>
                                                       
                            
                        </div>

                        <div class="form-group">

                            <label class="control-label" for="last-name">Wastage Quantity</label>
                            <input type="number" id="last-name" name="wastage_quantity" min="0" required="required" class="form-control wastage_quantity">
                            
                        </div>             

                        <div class="ln_solid"></div>
                        
                        <div class="form-group">
                            
                            <!-- <a href="<?php echo e(URL::to('add-stock')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" class="btn btn-success">Add Wastage</button>
                           
                        </div>

                    <?php echo Form::close(); ?>

                        
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>