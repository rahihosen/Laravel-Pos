  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2> Returned Order List </h2>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 

                        <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>


                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        
                                        <th class="column-title text-center">Return Order Created at </th>
                                        <th class="column-title text-center">Return Order ID </th>
                                        <th class="column-title text-center">Order ID </th>
                                        <th class="column-title text-center">Customer Name </th>
                                        <th class="column-title text-center">Return Order Total</th>
                                        <!--<th class="column-title text-center" style="width:20%;"> Action </th>-->
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach($all_return_order_info as $return_order) {?>

                                        <tr class="even pointer">
                                            <td class="text-center"><?php echo e($return_order->return_order_created_date.' at '.$return_order->return_order_created_time); ?></td>
                                            <td class="text-center"><?php echo e($return_order->return_order_id); ?></td>
                                            <td class="text-center"><?php echo e($return_order->order_id); ?></td>
                                            <td class="text-center"><?php echo e($return_order->customer_name); ?></td>
                                            <td class="text-center"><?php echo e($return_order->order_total); ?></td>
                                            <!--
                                            <td class="last text-center">
                                                <a href="<?php echo e(URL::to('/view-return-order/'.$return_order->order_id)); ?>" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-print"></i> Print</a>
                                                <a href="<?php echo e(URL::to('/view-return-order/'.$return_order->order_id)); ?>" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-eye-open"></i> View</a>

                                            </td>-->
                                        </tr>
                                    <?php  } ?>
                                        
                                         <tr>
                                            <td></td>
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $total_return_order_id= DB::table('return_order')
                                                                ->count('return_order_id');
                                                    ?>
                                                </b>
                                            </td>
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $total_order_id= DB::table('return_order')
                                                                ->count('order_id');
                                                    ?>
                                                </b>
                                            </td>
                                            <td></td>
                                            
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $total_return_order_total= DB::table('return_order')
                                                                ->sum('order_total');
                                                    ?>
                                                </b>
                                            </td>
                                            
                                             
                                        </tr>
                                        
                                        

                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>