  
<?php $__env->startSection('admin_main_content'); ?>
<style>
	.print_page {
		margin:3px;
		padding:7px;
		border:1px solid lightgray;
	}
	.print_page img{
		margin:0 auto;
		padding:0;
		width: 400px;
		height: auto;
	}
	.print_page .com_name{
		margin:0;
		padding:5px 0 0 0;
		text-align:center;
		color: #136734;
		font-size: 25px;
	}
	.print_page p{
		margin:0;
		padding:3px 0;
		text-align:center;
		font-size:15px;
	}
	table {
		width:100%;
		text-align:left;
		margin:0;
		padding:3px 0;
	}
	table td{
		text-align:left;
		font-size:14px;
		padding:5px 0;
	}
	table.table_prc td{
		text-align:right;
	}
	.pr-1 {
		padding-right: 1rem;
	}
</style>
<div class="right_col right_col_back" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">  
                    <div class="x_content"> 
						<div class="no_padding col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-12"> 
						
							<?php 
								$company = DB::table('settings')->first();
							?>
							<div id="print_page"> 
								

								<table>
									<tbody>

										<tr>
											<td width="50%">
												<p><img src="<?php echo e(asset($company->company_logo)); ?>" height="auto" width="400px"></p>
											</td>
											
											<td width="50%" class="text-center">
												<h4 class="com_name"><?= $company->company_name; ?></h4>
										
												<p><?= $company->company_address; ?><br/>Email: <?= $company->company_email;?>, Mob: <?= $company->company_mobile;?><br/></p>
											</td>
											
										</tr>

									</tbody>
								</table>
								
								<table>
									<tbody>

										<tr>
											<td width="65%">Order: #<?php echo e($single_order_info_customer->order_id); ?></td>
											
											<td width="35%" class="text-center">Date: <?php echo e($single_order_info_customer->order_created_date); ?></td>
											
											<!--<td style="text-align: center;">Table: 
												<?php
													
													$all_tables = DB::table('tables')->get();

													$result = explode(',',$single_order_info_customer->table_number);

													foreach ($all_tables as $all_tables) {

														if(in_array($all_tables->table_id,$result)){
														?>
													
															<?= $all_tables->table_name; ?>

														<?php    
														}        
													} 
												?>   
											</td>-->
											
										</tr>

									</tbody>
								</table>

								<table>
									<tbody>
										<tr>
											<td width="65%">Customer:  <?php echo e($single_order_info_customer->customer_name); ?></td>
											<td width="35%" class="text-center">Mob: <?php echo e($single_order_info_customer->customer_mobile); ?></td>
											<!--<td>Emali: <?php echo e($single_order_info_customer->customer_email); ?></td>-->
										</tr>
									</tbody>
								</table>

								<table class="table_prc" style="border-top:1px solid lightgray;">

									<tr>
										<td class="pr-1"><b>Item</b></td>
										<td class="pr-1"><b>Qty</b></td>
										<td class="pr-1"><b>Price</b></td>
										<td class="pr-1"><b>S.Total</b></td>
									</tr>

										
									<?php $__currentLoopData = $single_order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<tr>
											<td class="pr-1"><?php echo e($order->product_name); ?></td>
											<td class="pr-1"><?php echo e($order->product_qty); ?></td>
											<td class="pr-1"><?php echo e($order->product_sale_price); ?></td>
											<td class="pr-1"><?php echo e($order->product_qty*$order->product_sale_price); ?></td>
										</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<tr style="border-top:1px solid lightgray;">
										<?php $order_id=$order->order_id;?>
										
										<td colspan="2"><b>Total:</b></td>
										<td colspan="2"><b>TK. <?php echo e($order = DB::table('order')
											->where('order_id',$order_id)
											->sum('order_total')); ?> </b>
										</td>

									</tr>
											
									<tr>
										
										<td colspan="2"><b>Discount:</b></td>
										<td colspan="2"><b><?= $single_order_info_customer->order_discount; ?></b></td>
									
									</tr>

									<tr>
										
										<td colspan="2"><b>After Discount:</b></td>
										<td colspan="2"><b>TK. <?= $single_order_info_customer->after_discount; ?></b></td>
									
									</tr>

									<tr>
										
										<td colspan="2"><b>Vat:</b></td>
										<td colspan="2"><b><?= $single_order_info_customer->order_vat; ?>%</b></td>
									
									</tr>

									<tr>
										
										<td colspan="2"><b>Amount Payable:</b></td>
										<td colspan="2"><b>TK. <?= $single_order_info_customer->total_amount_payable; ?> </b></td>
									
									</tr>

									<tr style="border-top:1px dotted gray;">
										
										<td colspan="2"><b>Ammount Paid:</b></td>
										<td colspan="2"></td>
										
									</tr>
									
									<?php
										$order_id = $single_order_info_customer->order_id;

										$data = DB::table('pament_details')->where('order_id', $order_id)->get();
										$tot_paid = 0;
										foreach($data as $data){
											
											$tot_paid += $data->amount;
									?> 

									<tr>
										<td colspan="2">
											<b><?=$data->created_date.' '.$data->created_time;?></b>
										</td>
										
										<td>
											<b><?=$data->transaction_no;?></b>
										</td>
										
										<td>
											<b><?=$data->amount;?></b>
										</td>
									
									</tr>
									
									<?php }?>

									<tr style="border-top:1px dotted gray;">
										
										<td colspan="2"><b>Total Paid:</b></td>
										<td colspan="2"><b>TK. <?=$tot_paid;?></b></td>
									
									</tr>

									<tr style="border-top:1px dotted gray;">
										
										<td colspan="2"><b>Due:</b></td>
										<td colspan="2"><b>TK. 
											<?php
												$result =  ($single_order_info_customer->total_amount_payable) - $tot_paid;
												echo $result;
											?></b>
										</td>
									</tr>
									<tr>
										<td colspan="2"><b>Previous Due Amount:</b></td>
										<td colspan="2"><b>TK. <?php echo e($tot_previous_due - $result); ?></b></td>
									</tr>

									<tr>
										<td colspan="2"><b>Total Due Amount:</b></td>
										<td colspan="2"><b>TK. <?php echo e($tot_previous_due); ?></b></td>
									</tr>

									<tr>
										<td colspan="4"></td>
										<td colspan="4"></td>
									</tr>
									

									<tr>
										<td colspan="4" style="text-align: center;">Powered by Muktodhara Technology Limited </td>										
									</tr>

								</table>

							</div>
			
							<br>
							<br>
							<div class="col-md-12 text-center">
								
								<button target="_blank" class="btn btn-info print"><i class="fa fa-print"></i> Print</button>
								<button class="btn btn-warning extra_payment" customer_id="<?php echo e($single_order_info_customer->customer_id); ?>" order_id="<?php echo e($single_order_info_customer->order_id); ?>"><i class="fa fa-money"></i> Payment</button>
							</div>

							<div class="clearfix"></div>						
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    
    <div style="z-index:9999999999" class="modal fade extra_payment_modal" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Payment <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>
                <div class="modal-body">
                
                    <?php echo Form::open(['url' => '/add-extra-payment-customer', 'method'=>'post']); ?>

                        
                        <div class="form-group form-group-sm">
                            <input type="hidden" class="customer_id" name="customer_id">
                            <input type="hidden" class="order_id" name="order_id">
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="account-name">Account Name </label>

                            <select id="account-name" name="account_id" class="form-control active" required>
                                
                                <?php $accounts = DB::table('accounts')->get();?>
                                    
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    
                                    <option value="<?= $accounts->account_id;?>" ><?= $accounts->account_name;?></option>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                            </select>
                        
                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label for="payment">Add Payment:</label>
                            <input id="payment" class="due_payment form-control" name="amount" pattern="[0-9]+([\.,][0-9]+)?" step="0.01" min="0.01" type="number"  placeholder="Payment" required>
                            
                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label for="check-No">Check No:</label>
                            <input type="text" id="check-No" class="form-control" name="check_no"  placeholder="Check No">
                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label for="receipt-no">Receipt / Transaction No.</label>
                            <input type="text" id="receipt-no" class="form-control"  name="transaction"  placeholder="Receipt / Transaction No">
                            
                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label for="payment-note">Payment Note</label>
                            <input type="text" id="payment-note" class="form-control"  name="note" placeholder="Payment Note">
                            
                        </div>                          
                        
                        <button type="submit" class="btn btn-primary">Add Payment</button>
                    <?php echo Form::close(); ?>

                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div> 
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>

<script>
    $(document).ready(function() {
        
		$(document).on('click', '.print', function() {

			var prtContent = document.getElementById("print_page");

			var WinPrint = window.open('', '', 'left=0,top=0,width=1200,height=900,toolbar=0,scrollbars=0,status=0');

			WinPrint.document.writeln('<html><head><title></title><style>..hide_print_sec {display:none;} table td {padding:10px !important;}</style>');
			WinPrint.document.writeln('<html><head><title></title><style>.print_page { margin:3px;padding:7px;border:1px solid lightgray;} .print_page img{margin:0 auto;padding:0;width: 400px;height: auto;}.print_page .com_name{margin:0;padding:5px 0 0 0;text-align:center;color: #136734;font-size: 25px;}.print_page p{margin:0;padding:3px 0;text-align:center;font-size:15px;}table {width:100%;text-align:left;margin:0;padding:3px 0;}table td{text-align:left;font-size:14px;padding:5px 0;}table.table_prc td{text-align:right;}.pr-1 {padding-right: 1rem;}</style>');

			WinPrint.document.writeln('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">');

			WinPrint.document.writeln('<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet"> ');

			WinPrint.document.writeln('</head><body style="margin:0 10px;">');

			WinPrint.document.writeln('<br>');

			WinPrint.document.writeln(prtContent.innerHTML);

			WinPrint.document.writeln('</body></html>');
			WinPrint.document.close();
			WinPrint.focus();

		});
		
        $(document).on('click', '.extra_payment', function() {

            var customer_id = $(this).attr('customer_id');

            var order_id = $(this).attr('order_id');

            $('.customer_id').val(customer_id);
            $('.order_id').val(order_id);

            // $('.ammount_purchase_due').val(amountDuePurchase);

            // $('.due_payment').attr('max', amountDuePurchase);

            $('.extra_payment_modal').modal();

        });

        $(document).on('click', '.extra_payment', function() {

            var buyer_id = $(this).val();

            $(".throw_extra_payment").html();

            $('.throw_extra_payment').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");

            $.ajax({

                url: "<?php echo e(URL('/view-extra-payment-supplier')); ?>",

                method: "GET",

                data: {
                    buyer_id: buyer_id
                },

                success: function(data) {

                    $('.throw_extra_payment').html(data);
                }

            });


            $('.view_extra_payment_modal').modal();

        });
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>