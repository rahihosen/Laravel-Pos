  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->             
                       
<div class="right_col" role="main">             
                         
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                       
                    <div class="x_content">
                        
                        <div class="col-lg-2 col-md-2 col-sm-3 col-xs-12" style="padding-top:10px; background:#94bfd2;height:945px;overflow-y:scroll;">
                                
                                
                                <p class="cat_list_tag cat_list_tag_active" data-cat-id="all" data-cat-name="All Products">All Items</p>
                                
                            <?php $__currentLoopData = $all_cat_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_cat_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <p data-cat-id="<?php echo e($all_cat_info->category_id); ?>" data-cat-name="<?php echo e($all_cat_info->category_name); ?>" class="cat_list_tag" ><?php echo e($all_cat_info->category_name); ?></p>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                              
                        <div style="background:#e1e1e1;height:945px;overflow-y:scroll;" class="col-lg-5 col-md-5 col-sm-4 col-xs-12">
                            <h4 class="show_pro_small_cat" style="padding:10px;text-align:center;margin:0;">ITEMS </h4><br>
                           <div class="table-responsive show_pro_all">
                             
                    
                            <?php $__currentLoopData = $all_product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                            <div class="col-md-4" style="padding:10px 0; background-color:#fff; border:1px solid #ccc; margin-bottom:5px;" align="center">
                                  
                                <a style="cursor:pointer;" class="add_cart" data-productid="<?php echo e($products->product_id); ?>">
                                    <img src="<?php echo e($products->product_image); ?>" class="img-thumbnail" style="height:70px; width:100px;"/>
                                </a><br />
                                
                                <h4 style="padding:5px 0 0 0;margin:0;"><a style="cursor:pointer;" class="add_cart" data-productid="<?php echo e($products->product_id); ?>"><?php echo e($products->product_name); ?></a></h4>
                              
                  
                            </div>
    
                             
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            
                        </div>
                        
                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                            <div id="cart_details">
                                 <h3 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h3> 
                                <h4 align="center">ORDER DETAILS</h4>
                                
                                <?php 
                        $data=Cart::content();
                        ?>
                         <table id="cart" class="table table-hover table-condensed">
    				<thead>
						<tr class="text-center" style="background:#023264;color:#fff;">
							<th>Image</th>
                            <th>Name</th>
							<th>Price</th>
							<th style="width:90px;">Quantity</th>
							<th class="text-center">Subtotal</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody class="cart_list_table">
                    <?php if(Cart::count() != "0"): ?>
                                    
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="rem_row_<?php echo e($products->rowId); ?>">
							<td data-th="Product">
                                <img src="<?php echo e($products->options['image']); ?>" alt="Product Image" width="50px" height='40px'/>
							</td>
                            <td data-th="Name"><h5 class="nomargin"><?php echo e($products->name); ?></h5></td>
							<td style="vertical-align: inherit;" data-th="Price">Tk.<?php echo e($products->price); ?></td>
                                                        
							<td data-th="Quantity">              
                               <div class="q_input_fields">
                                <button onclick ="minusFunction('product_id_<?php echo e($products->rowId); ?>','<?php echo e($products->price); ?>')" class="q_minus"><i class="fa fa-minus"></i></button><input value="<?php echo e($products->qty); ?>" class="product_id_<?php echo e($products->rowId); ?> q_input" type="text" disabled><button onclick ="plusFunction('product_id_<?php echo e($products->rowId); ?>','<?php echo e($products->price); ?>')" class="q_plus"><i class="fa fa-plus"></i></button>
                                </div>

							</td>
                                                        
							<td style="vertical-align: inherit;" data-th="Subtotal" class="shwTotal_<?php echo e($products->rowId); ?> text-center"><?php echo e($products->price*$products->qty); ?></td>

							<td style="vertical-align: inherit;" class="actions" data-th="">	
                                <button type="button" onclick="removeFunction('<?php echo $products->rowId; ?>')" class="btn btn-danger btn-xs"><i class="fa fa-remove"></i></button>								
							</td>
						</tr>
                                                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                    <?php else: ?>
                    <tr>
                        <td colspan="3">
                            <h2>Cart is Empty!</h2>
					   </td>
                    </tr>
                    <?php endif; ?>   
                                        
					</tbody>
				</table>
				
                <?php echo Form::open(['url'=>'/save-order','method'=>'post']); ?>

                                    
                                 
                <table class="table table-condensed">
        
                    <tr>                   
                        <td style="text-align:right;"><h4 data-total-dis="<?php echo e(Cart::total()); ?>" class="get_total_for_dis">Total TK. <?php echo e(Cart::total()); ?></h4></td>
                    </tr>
                    <tr>                   
                        <td style="text-align:right;"><b>Discount (%): </b><input type="text" pattern="(^[0-9]{1,2})+(\.[0-9]{0,2})?" title="Numbers only (eg. 5, 5.05, 5.55, 5., 5.0 etc) Max 99.99" value="0" class="discount_input"  name="order_discount" required></td>
                    </tr>
                    <tr>                   
                        <td style="text-align:right;"><b>Total Ammount Payable: </b><input type="text" class="after_discount_input" disabled><input type="hidden" name="total_amount_payable" class="after_discount_input"></td>
                    </tr>
                    <tr>                   
                        <td style="text-align:right;"><b>Ammount Received: </b><input type="text" pattern="(^[0-9]{1,11})+(\.[0-9]{0,2})?" title="Numbers only" name="amount_received" class="ammount_received" required></td>
                    </tr>
                    <tr>                   
                        <td style="text-align:right;"><b>Ammount Return: </b><input type="text" class="ammount_return" disabled/> <input name="amount_return" type="hidden" class="ammount_return"></td>
                    </tr>
                    <tr>                   
                        <td style="text-align:right;"><b>Due: </b><input type="text" class="ammount_due" disabled/> <input name="amount_due" type="hidden" class="ammount_due"> </td>
                    </tr>
                </table>
                               
                                
                                
                                
                                             
                                                   
                                                    <label for="inputCity">Order Type:</label>
                                                        <select name="order_type" class="form-control" >
                                                           <option value="1">Non Parcel</option>
                                                            <option value="2">Parcel</option>
                                                           
                                                        
                                                        </select>
                                                      <br>
                                                    <label for="inputCity">Table Number:</label>
                                                        <select name="table_number" class="form-control" >
                                                            <option value="1">Table One</option>
                                                            <option value="2">Table Two</option>
                                                            <option value="3">Table Three</option>
                                                            <option value="4">Table Four</option>
                                                            <option value="5">Table Five</option>
                                                            <option value="6">Table Six</option>
                                                            <option value="7">Table Seven</option>
                                                            <option value="8">Table Eight</option>
                                                            <option value="9">Table Nine</option>
                                                            <option value="10">Table Ten</option>
                                                        </select>
                                                      <br>
                                                     
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                    
                                                     <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                        
                                                        <input type="radio" class="check_cust" name="default_customer" value="1" checked> Default &nbsp;&nbsp;
                                                        
                                                        <input type="radio" class="check_cust" name="default_customer" value="2"> Add Customer
                                                        
                                                        
                                                      </div>
                                
                                                      <div><br></div>
                                                    
                                                        <div style="display:none;" class="collapse_hide ">
                                                            <label for="inputCity">Customer Name:</label>
                                                            <input type="text" name="customer_name" class="form-control" id="inputCity">
                                                            <br>
                                                            <label for="inputCity">Customer Mobile:</label>
                                                            <input type="text" name="customer_mobile" class="form-control" id="inputCity">
                                                            <br>
                                                            <label for="inputCity">Customer Email:</label>
                                                            <input type="email" name="customer_email" class="form-control" id="inputCity">
                                                      
                                                        </div>
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                    <br>
                                                    <div style="margin:0 auto; width:220px;" ><button type="submit" name="save_or_print" value="1" class="btn btn-primary">Save Order</button>
                                                    <button type="submit" name="save_or_print" value="2" class="btn btn-success">Save & Print</button>
                                                    </div>
                                                    <?php echo Form::close(); ?>

                                                    <br>
                                                    <?php echo Form::open(['url'=>'/destoryCart','method'=>'POST']); ?>              
                                                    <button type="submit" style="margin:0 auto; width:100px;" class="btn btn-block btn-danger">Clear All</button>                                
                                                    <?php echo Form::close(); ?>

                                                    
                                                    
                            </div>
                        </div>
                        
                     

                    </div>
                </div>
            </div>
            
           
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>