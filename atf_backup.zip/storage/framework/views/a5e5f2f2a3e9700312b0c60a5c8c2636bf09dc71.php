  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                
                
                <div class="x_panel">
                    <div class="x_title">
                        <h2> <?php
                        $customer_id = $customer_sales_info_row->customer_id;
                        $customer_name_query = DB::table('customer')
                                ->where('customer_id',$customer_id)
                                ->first();
                        echo $customer_name_query->customer_name;
                        ?> - Order List</h2>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 
                        
                        <!-- form date pickers -->
                      
                        <form>  
                        <div class="form-group col-md-4">
                            <div class="input-group date">
                                <input type="text" class="date_from datepicker form-control" value="<?php echo e(date("Y-m-d")); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input-group date">
                                <input type="text" class="date_to datepicker form-control" value="<?php echo e(date("Y-m-d")); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-2">
                            <button type="button" class="date_from_to btn btn-success">Go!</button>
                        </div>
                         </form>
                 
                <!-- /form datepicker -->
                
                

                        <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>


                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        
                                        <th class="column-title text-center">Order Date </th>
                                        <th class="column-title text-center">Order ID </th>
                                       
                                        <th class="column-title text-center"> Order Total</th>
                                        <th class="column-title text-center" style="width:20%;"> Action </th>
                                    </tr>
                                </thead>

                                <tbody class="order_list_table">
                                    <?php foreach($customer_sales_info as $order) {?>

                                        <tr class="even pointer">
                                            <td class="text-center"><?php echo e($order->order_created_date); ?></td>
                                            <td class="text-center"><?php echo e($order->order_id); ?></td>
                                           
                                            <td class="text-center"><?php echo e($order->order_total); ?></td>
                                            <td class="last text-center">
                                                <a href="<?php echo e(URL::to('/print-order-page/'.$order->order_id)); ?>" target="_blank" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-print"></i> Print</a>
                                                <a href="<?php echo e(URL::to('/view-order/'.$order->order_id)); ?>" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-eye-open"></i> View</a>

                                            </td>
                                        </tr>
                                    <?php  } ?>
                                        <tr>
                                            
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                          
                                            <td class="text-center">
                                                <b>
                                                   Total:TK. <?php
                                                     echo $sub_total= DB::table('order_details')
                                                                ->where('customer_id',$order->customer_id)
                                                                ->sum('sub_total');
                                                    ?>
                                                </b>
                                            </td>
                                            
                                        </tr>

                                </tbody>
                            </table>
                        </div>
                <a href="<?php echo e(URL::to('customer-list')); ?>" class="btn btn-primary pull-right">Back</a>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>