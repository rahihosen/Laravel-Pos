  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->

<div class="right_col" role="main">
    
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    
                    <div class="x_title">
                       

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 
                       <h2> <a href="add-customer" class="btn btn-primary"> <i class="fa fa-plus" aria-hidden="true"></i>
                                Add Customer </a> </h2>
                       
                        <table id="cart" class="table table-hover table-condensed">
    				<thead>
						<tr>
							<th style="width:50%">Product</th>
							<th style="width:10%">Price</th>
							<th style="width:8%">Quantity</th>
							<th style="width:22%" class="text-center">Subtotal</th>
							<th style="width:10%"></th>
						</tr>
					</thead>
					<tbody>
                                           <?php if(Cart::count() != "0"): ?> 
                                       
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td data-th="Product">
								<div class="row">
									<div class="col-sm-2 hidden-xs"><img src="" width="150" height="100" alt="..." class="img-responsive"/></div>
									<div class="col-sm-10">
										<h4 class="nomargin"><?php echo e($products->name); ?></h4>
										
									</div>
								</div>
							</td>
							<td data-th="Price">Tk.<?php echo e($products->price); ?></td>
                                                        
							<td data-th="Quantity">
                                                            
                                                            
                                                            
                                                            <input type="number" class="form-control text-center" value="<?php echo e($products->qty); ?>" id="upCart<?php echo e($products->id); ?>">
                                                            
                                                            <input type="hidden" class="form-control text-center" value="<?php echo e($products->rowId); ?>" id="rowId<?php echo e($products->id); ?>">
                                                            
                                                                
                                                              
                                                              
							</td>
                                                        
							<td data-th="Subtotal" class="text-center"><?php echo e($products->price*$products->qty); ?></td>
							<td class="actions" data-th="">
								
                                                                <a href="<?php echo e(url('cart/remove/'.$products->rowId)); ?>">Remove</a>								
							</td>
						</tr>
                                                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php else: ?>
                                        <tr>
                                          <td data-th="Product">
                                              <h2>Cart is Empty!</h2>
					   </td>
                                        </tr>
                                        
                                        <?php endif; ?>
                                                
					</tbody>
					<tfoot>
						<tr class="visible-xs">
							<td class="text-center"><strong>Total TK. <?php echo e(Cart::total()); ?></strong></td>
						</tr>
						<tr>
							<td><a href="<?php echo e(URL::to('customerProductList')); ?>" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
							<td colspan="2" class="hidden-xs"></td>
							<td class="hidden-xs text-center"><strong>Total TK. <?php echo e(Cart::total()); ?></strong></td>
							<td><a href="<?php echo e(URL::to('checkout')); ?>" class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></a></td>
                                                        
						</tr>
					</tfoot>
				</table>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>