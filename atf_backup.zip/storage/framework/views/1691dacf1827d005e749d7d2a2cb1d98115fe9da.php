  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2> Stock Product List </h2>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 

                        <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>


                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        <th class="column-title text-center">Stock ID </th>
                                        <th class="column-title text-center">Product ID </th>
                                        <th class="column-title text-center"> Product Name </th>
                                        <th class="column-title text-center"> Current Stock Qty </th>
                                       
                                        <th class="column-title text-center"> Last in Stock Qty </th>
                                        <th class="column-title text-center"> Total in Stock Qty </th>
                                       
                                        <!--<th class="column-title"> Action </th>-->
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach($all_stock_info as $stock) {?>

                                        <tr class="even pointer">
                                            <td class="text-center"><?php echo e($stock->stock_id); ?></td>
                                            <td class="text-center"><?php echo e($stock->product_id); ?></td>
                                            <td class="text-center"><?php echo e($stock->product_name); ?></td>
                                          <td class="text-center"><?php echo e(($stock->total_in_qty + $stock->total_canceled_qty) - ($stock->total_sales_qty + $stock->total_wastage_qty)); ?></td>
                                            <td class="text-center"><?php echo e($stock->last_in_qty); ?></td>
                                            <td class="text-center"><?php echo e($stock->total_in_qty); ?></td>
                                           
                                           
                                            
                                           <!-- <td class=" last">
                                                <a href="#" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-eye-open"></i> View</a>
                                            </td>-->
                                        </tr>
                                    <?php  } ?>
                                        
                                        
                                         <tr>
                                            <td></td>
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $total_product_id= DB::table('stock')
                                                                ->count('product_id');
                                                    ?>
                                                </b>
                                            </td>
                                            <td></td>
                                            
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $last_in_stock_qty= DB::table('stock')
                                                                ->sum('last_in_qty');
                                                    ?>
                                                </b>
                                            </td>
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $total_in_stock_qty= DB::table('stock')
                                                                ->sum('total_in_qty');
                                                    ?>
                                                </b>
                                            </td>
                                            <td></td>
                                        </tr>

                                </tbody>
                            </table>
                        </div>
                         <div class="pull-right">
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/stock-list?page=1')); ?>">First</a> </li>
                            </ul>
                            <?php echo e($all_stock_info->links()); ?> 
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/stock-list?page='.$all_stock_info->lastPage())); ?>">Last</a> </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>