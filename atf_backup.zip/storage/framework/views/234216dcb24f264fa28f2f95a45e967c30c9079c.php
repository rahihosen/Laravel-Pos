  
<?php $__env->startSection('admin_main_content'); ?>
    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">

				<?php if(count($errors) > 0): ?>

					<div class="alert alert-danger alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">

						<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
								<li>Your Image Size is too big.</li>
								<li>Maximum Image Size 2MB</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>

				<?php endif; ?>
				
				<div class="box_layout col-md-12 col-sm-12 col-xs-12">

					<h3 class="no_padding"><i class="fa fa-plus"></i> Add New  </h3>

				</div>


				<?php 

					$message = Session::get('message');

					if ( $message !='') { ?>

						<div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

							<h5 class="text-center">

								<?php

									if(isset($message)) { ?>

										<div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
											<strong> <?php echo $message;?> </strong>
										</div>
										
									<?php
										Session::put('message','');
									}
								?>

							</h5>
						</div> 
						
						<?php 
					}
					
				?>


				<div class="no_padding right_padding res_no_padding col-md-6 col-sm-6 col-xs-12">				
					
					<div class="panel panel-amin">

						<div class="panel-heading">
							<h3 class="panel-title">Description</h3>
							<span class="pull-right clickable"><i class="fa fa-plus"></i></span>
						</div>

						<div class="panel-body">        
							
							<?php echo Form::open(['url' => '/save-product','method'=>'post','enctype'=>'multipart/form-data']); ?>

						
								<div class="form-group">

									<label for="name">Name</label>
									
									<input type="text" placeholder="Name" id="name" name="product_name" class="form-control" required>
									
									<div><br></div>
									
								</div>
								
								<div class="form-group">

									<label for="cat">Generics</label>
									
									<select id="cat" name="fk_category_id" class="form-control" required>
										
										<?php $__currentLoopData = $published_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</select>
									
									<div><br></div>
									
								</div>
								
								<div class="form-group">

									<label for="Type">Type</label>
									
									<select id="Type" name="product_type" class="form-control">
										
										<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($type->type_id); ?>"><?php echo e($type->type_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</select>
									
									<div><br></div>
									
								</div>

						</div>

					</div>
				</div>

				
				<div class="no_padding col-md-6 col-sm-6 col-xs-12">				
					
					<div class="panel panel-amin">

						<div class="panel-heading">
							<h3 class="panel-title">Pricing & Publication</h3>
							<span class="pull-right clickable"><i class="fa fa-plus"></i></span>
						</div>

						<div class="panel-body">

							<!-- <div class="form-group">

								<label class="control-label" for="last-name"> Purchase Price </label>
								<input type="number" id="" name="product_purchase_price" min="1"  required="required" class="form-control">

							</div> -->
								
							<div class="form-group">

								<label for="image">Image </label>
								
								<input type="file" id="image" name="product_image" class="form-control">
								
							</div> 

							<div class="form-group">

								<label for="price">Sell Price </label>
								
								<input type="number" placeholder="Price" id="price" name="product_sell_price"  min="0.01" step="0.01" class="form-control" required>

							</div>
							
							<div class="form-group">

								<label for="outRange">Out of Stock Range</label>
								
								<input type="number" min="0" placeholder="Out of Stock Range" id="outRange" name="out_of_stock_range" class="form-control" value="10" required>
								
								
							</div>

							<div class="form-group" >

								<label>Publication Status</label> <br>
								
								<div class="btn-group" data-toggle="buttons">

									<label class="btn btn-default active">
									
										<input type="radio" name="product_status" value="1" checked> &nbsp; Published &nbsp;
										
									</label>
									
									<label class="btn btn-default">
									
										<input type="radio" name="product_status" value="0"> Unpublished
										
									</label>
									
								</div>


							</div>

						</div>
					</div>
				</div>
			</div>

			<div style="margin-left: 10px;">
			
				<button type="submit" class="btn btn-success btn-lg"><i class="fa fa-plus"></i> Save</button>
				
			</div>

			<?php echo Form::close(); ?>


		</div>
	
    </div>
    <!-- /page content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>