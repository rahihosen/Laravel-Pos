<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Muktodhara Admin Login </title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/animate.css/animate.min.css')); ?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('public/admin_asset/build/css/custom.min.css')); ?>" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
              
              
              <?php echo Form::open(['url' => '/admin_login','method'=>'post']); ?>

    
    
            
              <h1>Admin Login</h1>
              
              <h5 class="text-center" style="color:red;">
                  <?php
                  $exception=Session::get('exception');
                  if(isset($exception))
                  {
                      echo $exception;
                      Session::put('exception','');
                  }
                  ?>
              </h5>
              <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>
              
              <div>
                  <input type="text" class="form-control" placeholder="Admin Email" name="admin_email" required="" />
              </div>
              <div>
                  <input type="password" class="form-control" placeholder="Password" name="admin_password" required="" />
              </div>
              <div>
                  <button type="submit" class="btn btn-default">Log in</button>
                <!--<a class="reset_pass" href="#">Lost your password?</a>-->
              </div>

              <div class="clearfix"></div>

              <div class="separator">
               

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1> Mukto Pharmacy Management</h1>
                  <p>©2018 All Rights Reserved.</p>
                </div>
              </div>
            
              
              <?php echo Form::close(); ?>

              
              
          </section>
        </div>

      </div>
    </div>
  </body>
</html>