  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Update Wastage Product </h2>

                       
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <div id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                                 
                            <?php echo Form::open(['url'=>'/update-wastage','method'=>'post','enctype'=>'multipart/form-data','name'=>'edit_stock']); ?>

                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Product ID
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="first-name" class="form-control col-md-7 col-xs-12 " value="<?php echo e($single_product_info->product_id); ?>" disabled>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Product Name
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="last-name" name="product_name" value="<?php echo e($single_product_info->product_name); ?>" required="required" class="form-control col-md-7 col-xs-12" disabled>
                                    <input type="hidden" id="last-name" name="product_id" value="<?php echo e($single_product_info->product_id); ?>" required="required" class="form-control col-md-7 col-xs-12">
                                 
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Wastage Quantity
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="number" id="last-name" name="last_in_wastage_qty" required="required" class="form-control col-md-7 col-xs-12">
        
                                </div>
                            </div>
                            
             

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <a href="<?php echo e(URL::to('add-wastage')); ?>" class="btn btn-primary">Back</a>
                                    <button class="btn btn-primary" type="reset">Reset</button>
                                    <button type="submit" class="btn btn-success">Add Wastage</button>
                                </div>
                            </div>

                            <?php echo Form::close(); ?>

                        </div
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

</div>

<!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>