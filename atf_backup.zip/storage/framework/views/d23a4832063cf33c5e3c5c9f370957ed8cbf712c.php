  
<?php $__env->startSection('admin_main_content'); ?>

	<?php 
		date_default_timezone_set("Asia/Dhaka");
		$today = date("Y-m-d");
	?>

	<div class="right_col" role="main">

		<div class="row top_tiles">

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-cubes"></i></div>
					<div class="count"><?= DB::table('product')->count('product_id');?></div>
					<h3>Total Medicines</h3>
					<p>Total Sum of All Medicines.</p>
				</div>
			</div>

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-shopping-basket"></i></div>
					<div class="count"><?= DB::table('product')->count('product_id');?></div>
					<h3>Medicine Groups</h3>
					<p>Total Sum of Medicine Groups.</p>
				</div>
			</div>

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-users"></i></div>
					<div class="count"><?= DB::table('customer')->count('customer_id');?></div>
					<h3>Customers</h3>
					<p>Total Sum of All Customers.</p>
				</div>
			</div>

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-user-plus"></i></div>
					<div class="count"><?= DB::table('admin')->count('admin_id');?></div>
					<h3>Users</h3>
					<p>Total Sum of All Users.</p>
				</div>
			</div>
		</div>

		<div class="row" style="margin-top: 10px;">
			<div class="col-md-12 col-sm-12 col-xs-12 ">
				<div class="x_panel">
				
					<div class="x_title">
						<h2 style="width:auto;">Orders & Medicines Summary</h2>
						<h2 class="pull-right"><a class="pull-right collapse-link"><i class="fa fa-chevron-up"></i></a></h2>
						<div class="clearfix"></div>
					</div>

					<div class="x_content">
						<div class="col-md-6 col-sm-12 col-xs-12">
							<br>
							<!-- <div class="col-md-12 col-sm-12 col-xs-12 no_padding">
								
								<div class="col-md-1 col-sm-12 col-xs-12 no_padding">
								</div>

								<div class="col-md-4 col-sm-5 col-xs-12 no_padding form-group">
									<div class="input-group date">
										<input type="text" class="date_from datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
										</div>
									</div>
								</div>

								<div class="no_padding form-group col-md-4 col-sm-5 col-xs-12">
									<div class="input-group date">
										<input type="text" class="date_to datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
										</div>
									</div>
								</div>

								<div class="no_padding form-group col-md-2 col-sm-2 col-xs-12">
									<button type="button" class="date_from_to_due btn btn-success">Go!</button>
								</div>
							</div> -->
							
							<div class="clearfix"></div>
							<br>
							
							<canvas id="lineChart"></canvas>
						
						</div>

						<div class="col-md-6 col-sm-12 col-xs-12">
						
							<br>
							<!-- <div class="col-md-12 col-sm-12 col-xs-12 no_padding">
								<div class="no_padding col-md-1 col-sm-1 col-xs-12">
								</div>
								<div class="no_padding form-group col-md-5 col-sm-5 col-xs-12">
									
									<select class="form-control col-md-12 col-sm-12 col-xs-12 get_year">
									<?php for ($i=2018;$i<2060;$i++){?>
										<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
									<?php }?>
									</select>
								</div>
								<div class="no_padding form-group col-md-2 col-sm-2 col-xs-2">
									<button type="button" class="date_from_to_due btn btn-success">Go!</button>
								</div>
							</div> -->
								
							<div class="clearfix"></div>
							<br>
							
							<canvas id="mybarChart"></canvas>
						
						</div>

					</div>
				</div>
			</div>
		</div>

		

		<div class="row" style="margin-top: 10px;padding-bottom: 10px;">
			<div class="col-md-12">
				<div class="x_panel">
					<div class="x_title">
						<h2 style="width:auto;">Sales Summary (Total, Paid & Due)</h2>
						<h2 class="pull-right"><a class="pull-right collapse-link"><i class="fa fa-chevron-up"></i></a></h2>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">

						<div class="row" style="border-bottom: 1px solid #E0E0E0; padding-bottom: 5px; margin-bottom: 5px;">
							
							<!-- <div class="col-md-3 col-sm-12 col-xs-12">
								<br>
								<br>
								<div class="no_padding form-group col-md-12 col-sm-5 col-xs-12">
									<div class="input-group date">
										<input type="text" class="date_from datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
										</div>
									</div>
								</div>
								<div class="no_padding form-group col-md-12 col-sm-5 col-xs-12">
									<div class="input-group date">
										<input type="text" class="date_to datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
										<div class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
										</div>
									</div>
								</div>
								<div class="no_padding form-group col-md-2 col-sm-2 col-xs-12">
									<button type="button" class="date_from_to_due btn btn-success">Go!</button>
								</div>
							</div> -->
							<div class="col-md-6 col-sm-12 col-xs-12">
								<br>
								
								<canvas id="lineChartAmmount"></canvas>
								<br>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
		
	<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>