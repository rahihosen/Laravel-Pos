  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2> Sales Reports By Order </h2>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 
                    <form>  
                        <div class="form-group col-md-4">
                            <div class="input-group date">
                                <input type="text" class="date_from datepicker form-control" value="<?php echo e(date("Y-m-d")); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input-group date">
                                <input type="text" class="date_to datepicker form-control" value="<?php echo e(date("Y-m-d")); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-2">
                            <button type="button" class="date_from_to_for_sales_order btn btn-success">Go!</button>
                        </div>
                         </form>
                        <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>


                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        <th class="column-title text-center">Date </th>
                                        <th class="column-title text-center">Sale ID </th>
                                        <th class="column-title text-center">Customer </th>
                                        
                                        <th class="column-title text-center">Sub Total </th>
                                        
                                        
                                    </tr>
                                </thead>

                                <tbody class="order_list_table">
                                    <?php foreach($all_sales_info as $sales) {?>

                                        <tr class="even pointer">
                                            <td class="text-center"><?php echo e($sales->order_created_date.' at '.$sales->order_created_time); ?></td>
                                            <td class="text-center"><?php echo e($sales->order_id); ?></td>
                                            <td class="text-center"><?php echo e($sales->customer_name); ?></td>                                            
                                            <td class="text-center"><?php echo e($sales->order_total); ?></td> 
                                        </tr>
                                        
                                    <?php  } ?>
                                        <tr>
                                            <td></td>
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $total_order_id= DB::table('order')
                                                                ->count('order_id');
                                                    ?>
                                                </b>
                                            </td>
                                            <td></td>
                                            
                                            <td class="text-center">
                                                <b>
                                                   Total: <?php
                                                     echo $sub_total= DB::table('order_details')
                                                                ->sum('sub_total');
                                                    ?>
                                                </b>
                                            </td>
                                        </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="hide_pagi pull-right">
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/sales-report-by-order?page=1')); ?>">First</a> </li>
                            </ul>
                            <?php echo e($all_sales_info->links()); ?>

                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/sales-report-by-order?page='.$all_sales_info->lastPage())); ?>">Last</a> </li>
                            </ul>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>