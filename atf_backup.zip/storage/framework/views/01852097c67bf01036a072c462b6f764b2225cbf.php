  

<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="box_layout col-md-12 col-sm-12 col-xs-12">

                    
                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <h3 class="no_padding">
                            <button class="btn btn-primary add_product">
                                <i class="fa fa-plus" aria-hidden="true"></i> Add Product Item
                            </button>
                        </h3>
                    </div>

                    <div class="col-md-8 col-sm-8 col-xs-12">

                        <div class="form-group form-inline pull-right">
                            <button type="button" class="name_from_to_product_list btn btn-success">Go!</button>
                        </div>

                        <div class="form-group form-inline pull-right">
                            <div class="input-group dae no_margin" style="width: 20em;">
                                
                                <select id="cat-name" name="fk_category_id" class="form-control fk_category_id" >

                                    <option value="0">None</option>

                                    <?php  $categorys = DB::table('category')->get(); ?>
                                    
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->category_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>

                        <div class="form-group form-inline pull-right no_margin">

                            <div class="input-group date no_margin">

                                <input type="text" class="search_product form-control" placeholder="Search..." style="width: 20em;">
                                
                            </div>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                    <!-- /form datepicker -->

                    <h5 class="text-center" style="color:green;">
                        
                        <?php
                            $message=Session::get('message');

                            if(isset($message)) {
                                echo $message;
                                Session::put('message','');
                            }
                        ?>

                    </h5>

                    <div class="clearfix"></div>

                </div>

                <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                    <div class="panel panel-amin">

                        <div class="panel-heading">
                            <h3 class="panel-title">Food List</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">

                            <div class="table-responsive">

                                <table class="table table-striped  bulk_action table-responsive table-bordered">
                                    <thead>
                                        <tr class="headings">
                                            <th class="column-title text-center">ID </th>
                                            <th class="column-title text-center"> Name </th>
                                            <th class="column-title text-center"> Image </th>                                        
                                            <th class="column-title text-center"> Menu </th>
                                            <!-- <th class="column-title text-center"> Purchase Price </th> -->
                                            <th class="column-title text-center"> Sell Price </th>
                                            <th class="column-title text-center"> Status </th>
                                            <th class="column-title text-center"> Action </th>
                                        </tr>
                                    </thead>

                                    <tbody class="search_results">

                                        <?php foreach($all_product_info as $product) { ?>

                                            <tr class="even pointer">
                                            
                                                <td class="text-center"><?php echo e($product->product_id); ?></td>
                                                <td class="text-center"><?php echo e($product->product_name); ?></td>
                                                <td class="text-center"><img src="<?php echo e(asset($product->product_image)); ?>" width="80" height="50"></td>
                                                <td class="text-center"><?php echo e($product->category_name); ?></td>
                                                <!-- <td class="text-center"><?php echo e($product->product_purchase_price); ?></td> -->
                                                <td class="text-center"><?php echo e($product->product_sell_price); ?></td>
                                                <td class="text-center">

                                                    <?php if($product->product_status==1) { ?>

                                                        <a class="btn btn-success btn-xs">Active</a>

                                                    <?php } else { ?> 

                                                        <a class="btn btn-warning btn-xs">Inactive</a>

                                                    <?php } ?>

                                                </td>
                                                
                                                
                                                <td class="last text-center">

                                                    <button
                                                        class="btn btn-dark btn-xs edit_product"

                                                        value="<?php echo e($product->product_id); ?>"
                                                        productName="<?php echo e($product->product_name); ?>"
                                                        productPurchasePrice="<?php echo e($product->product_purchase_price); ?>"
                                                        productSellPrice="<?php echo e($product->product_sell_price); ?>"
                                                        productCategory="<?php echo e($product->fk_category_id); ?>"
                                                        productCategoryName="<?php echo e($product->category_name); ?>"
                                                        productImage="<?php echo e(asset($product->product_image)); ?>"
                                                        oldImage="<?php echo e($product->product_image); ?>"
                                                        productStatus="<?php echo e($product->product_status); ?>"
                                                        >
                                                        <i class="glyphicon glyphicon-pencil"></i> Edit
                                                    </button>

                                                    <button 
                                                        class="btn btn-info btn-xs view_product"
                                                        value="<?php echo e($product->product_id); ?>" >

                                                        <i class="glyphicon glyphicon-eye-open "></i> View
                                                    </button>
                                                    
                                                </td>
                                            </tr>
                                        <?php  } ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <div class="hide_pagi pull-right">
                            <?php if( $all_product_info != ''): ?> 
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/product-list?page=1')); ?>">First</a> </li>
                                </ul>
                                <?php echo e($all_product_info->links()); ?> 
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/product-list?page='.$all_product_info->lastPage())); ?>">Last</a> </li>
                                </ul>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>
                
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- Modal Add Product -->
    <div style="z-index:9999999999" class="modal fade add_product_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Add Product <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url' => '/save-product2','method'=>'post','enctype'=>'multipart/form-data']); ?>

                            
                        <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name"> Name </label>                                                                   
                            <input type="text" id="last-name" name="product_name" required="required" class="form-control">
                            
                        </div>

                        <!-- <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name"> Purchase Price </label>
                            <input type="number" id="" name="product_purchase_price" min="1" required="required" class="form-control">
                            
                        </div> -->

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name">Sell Price</label>
                            <input type="number" id="" name="product_sell_price" min="1" required="required" class="form-control">
                            
                        </div>

                        <div class="form-group form-group-sm">
                            <label class="control-label" for="cat-name"> Category</label>
                             
                            <select id="cat-name" name="fk_category_id" class="form-control" required="required">
                                
                                <?php 
                                    $product_category = DB::table('category')->get();
                                    foreach($product_category as $product_category ) {  ?>
                                    
                                    <option value="<?= $product_category->category_id;?>"><?= $product_category->category_name;?></option>
                                
                                <?php } ?>   

                            </select>
                            
                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name"> Image </label>
                            <input type="file" id="last-name" name="product_image" class="form-control">
                            
                        </div>
                    
                        <div><br></div>

                        <div class="form-group form-group-sm">
                            <label class="control-label">Publication Status: </label>

                            <div id="gender" class="btn-group" data-toggle="buttons">

                                <label class="btn btn-default" >
                                    <input type="radio" name="product_status" value="1" required="required"> &nbsp; Published &nbsp;
                                </label>
                                
                                <label class="btn btn-default" >
                                    <input type="radio" name="product_status" value="0" required="required"> Unpublished
                                </label>

                            </div>
                            
                        </div>
                        
                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">

                            <!-- <a href="<?php echo e(URL::to('product-list')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" class="btn btn-success">Save</button>
                            
                        </div>

                    <?php echo Form::close(); ?>

                        
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    <!-- Modal Edit Product -->
    <div style="z-index:9999999999" class="modal fade edit_product_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Edit Product <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-product','method'=>'post','enctype'=>'multipart/form-data','name'=>'edit_product']); ?>


                        <div class="form-group form-group-sm">

                            <label class="control-label" for="first-name">ID </label>
                            <input type="text" id="first-name" class="form-control product_id" value="" disabled>
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name">Product Name </label>                            
                            <input type="text" id="last-name" name="product_name" value="" required="required" class="form-control product_name">

                            <input type="hidden" class="product_id" name="product_id">
                            
                            <input type="hidden" class="old_image" name="old_image" />
                            
                        </div>

                        <!-- <div class="form-group form-group-sm">

                            <label class="control-label" for="product-price">Product Purchase Price </label>
                            <input type="number" id="last-name" name="product_purchase_price" min="1" value="" required="required" class="form-control product_purchase_price">    
                            
                        </div> -->
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label" for="product-price">Product Sell Price </label>
                            <input type="number" id="last-name" name="product_sell_price" min='1' value="" required="required" class="form-control product_sell_price">    
                            
                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label" for="cat-name">Product Category </label>

                            <select name="fk_category_id" class="form-control" id="product-category">
                                
                                <option class="fk_category_id" value=""></option>
                                <?php 
                                    $product_category = DB::table('category')->get();

                                    foreach($product_category as $product_category ) {  ?>
                                    
                                    <option value="<?= $product_category->category_id;?>"><?= $product_category->category_name;?></option>
                                
                                <?php } ?>                                

                            </select>

                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label  " for="last-name">Product Image </label>

                            <input type="file" id="product-image" name="product_image" class="clear_image form-control">
                            <img src="" alt="image" class="product_img top_margin" width="auto" height="60px" >
                            
                        </div>                                               
                        
                        <div class="form-group form-group-sm" style="margin-top: 30px;">

                            <label class="control-label ">Publication Status</label>
                            <div id="gender" class="btn-group" data-toggle="buttons">

                                <label class="edit_product_type_active btn btn-default">
                                    <input type="radio" name="product_status" value="1"> &nbsp; Published &nbsp;
                                </label>

                                <label class="edit_product_type_inactive btn btn-default">
                                    <input type="radio" name="product_status" value="0"> Unpublished
                                </label>
                                
                            </div>
                        </div>

                        <div class="ln_solid"></div>
                        
                        <!-- <a href="<?php echo e(URL::to('product-list')); ?>" class="btn btn-primary">Back</a>
                        <button class="btn btn-primary" type="reset">Reset</button> -->
                        <button type="submit" class="btn btn-success">Update</button>
                        

                    <?php echo Form::close(); ?>

                        
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal View Product -->
    <div style="z-index:9999999999" class="modal fade view_product_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content" >

                <div class="modal-header" >
                    <h4 class="modal-title">View Product <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body" id="client_details">
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped return_product" >
                            
                        </table>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="print_details btn btn-default" style="float: left;">Print</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>