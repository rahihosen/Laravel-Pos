  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col right_col_back" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Edit Role </h2>

                       
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <div id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>                   
                            <?php echo Form::open(['url'=>'/update-role','method'=>'post','enctype'=>'multipart/form-data','name'=>'edit_role']); ?>

                        
                    <?php 
                      $str=DB::table('admin_role')
                              ->first();
                      
                        $admin = explode(",",$str->admin_role_features);
                        $manager = explode(",",$str->manager_role_features);
                        $salesman = explode(",",$str->salesman_role_features);
                        
                        function check_function($op, $uo){
                            if(in_array($op,$uo)){
                                return "checked";
                              }else{
                                  return " ";
                              }
                        }
                       $admin_checked_user = check_function(1,$admin);
                       $admin_checked_settings = check_function(2,$admin);
                       $admin_checked_report = check_function(3,$admin);
                       $admin_checked_order = check_function(4,$admin);
                       $admin_checked_product = check_function(5,$admin);
                       
                       $manager_checked_user = check_function(1,$manager);
                       $manager_checked_settings = check_function(2,$manager);
                       $manager_checked_report = check_function(3,$manager);
                       $manager_checked_order = check_function(4,$manager);
                       $manager_checked_product = check_function(5,$manager);
                       
                       $salesman_checked_user = check_function(1,$salesman);
                       $salesman_checked_settings = check_function(2,$salesman);
                       $salesman_checked_report = check_function(3,$salesman);
                       $salesman_checked_order = check_function(4,$salesman);
                       $salesman_checked_product = check_function(5,$salesman);
                       
                      ?>

                      <label>Admin Role:</label>
                      
                      <input type="checkbox" name="admin_role_features[]" id="hobby1" value="1" <?php echo e($admin_checked_user); ?> class="flat" disabled=""> User
                      <input type="checkbox" name="admin_role_features[]" id="hobby2" value="2" <?php echo e($admin_checked_settings); ?> class="flat" disabled=""> Settings
                      <input type="checkbox" name="admin_role_features[]" id="hobby3" value="3" <?php echo e($admin_checked_report); ?> class="flat" disabled=""> Report
                      <input type="checkbox" name="admin_role_features[]" id="hobby4" value="4" <?php echo e($admin_checked_order); ?> class="flat" disabled=""> Order
                      <input type="checkbox" name="admin_role_features[]" id="hobby4" value="5" <?php echo e($admin_checked_product); ?> class="flat" required="" disabled=""> Product
                        
                        <hr>
                         <label>Manager Role:</label>
                      
                      
                        <input type="checkbox" name="manager_role_features[]" id="hobby1" value="1" <?php echo e($manager_checked_user); ?> class="flat" /> User
                        <input type="checkbox" name="manager_role_features[]" id="hobby2" value="2" <?php echo e($manager_checked_settings); ?> class="flat" /> Settings
                        <input type="checkbox" name="manager_role_features[]" id="hobby3" value="3" <?php echo e($manager_checked_report); ?> class="flat" /> Report
                        <input type="checkbox" name="manager_role_features[]" id="hobby4" value="4" <?php echo e($manager_checked_order); ?> class="flat" /> Order
                        <input type="checkbox" name="manager_role_features[]" id="hobby4" value="5" <?php echo e($manager_checked_product); ?> class="flat" required=""/> Product
                        
                        <br>
                        <hr>
                         <label>Salesman Role:</label>
                      
                      
                        <input type="checkbox" name="salesman_role_features[]" id="hobby1" value="1" <?php echo e($salesman_checked_user); ?> class="flat" /> User
                        <input type="checkbox" name="salesman_role_features[]" id="hobby2" value="2" <?php echo e($salesman_checked_settings); ?> class="flat" /> Settings
                        <input type="checkbox" name="salesman_role_features[]" id="hobby3" value="3" <?php echo e($salesman_checked_report); ?> class="flat" /> Report
                        <input type="checkbox" name="salesman_role_features[]" id="hobby4" value="4" <?php echo e($salesman_checked_order); ?> class="flat" /> Order
                        <input type="checkbox" name="salesman_role_features[]" id="hobby4" value="5" <?php echo e($salesman_checked_product); ?> class="flat" required=""/> Product
                        

                       <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <a href="<?php echo e(URL::to('create-role')); ?>" class="btn btn-primary">Back</a>
                                    <button class="btn btn-primary" type="reset">Reset</button>
                                    <button type="submit" class="btn btn-success">Update</button>
                                </div>
                            </div>

                            <?php echo Form::close(); ?>

                        </div
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>