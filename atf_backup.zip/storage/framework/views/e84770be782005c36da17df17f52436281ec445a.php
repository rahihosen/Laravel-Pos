  
<?php $__env->startSection('admin_main_content'); ?>

	<?php 
		date_default_timezone_set("Asia/Dhaka");
		$today = date("Y-m-d");
	?>

	<div class="right_col" role="main">
		
		

		<?php 
			
			if(isset($_GET['error'])){
				
				$message = $_GET['error'];

				if ($message == 1) {  ?>

					<div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

						<h5 class="text-center">


							<div class="alert alert-danger alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<strong> Access Denied ! </strong>
							</div>
									
								

						</h5>
					</div> 
				
					<?php 
				}
			}
			
		?>
			

		
		<div class="row top_tiles">

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-cubes"></i></div>
					<div class="count"><?= DB::table('product')->count('product_id');?></div>
					<h3>Total Medicines</h3>
					<p>Total Sum of All Medicines.</p>
				</div>
			</div>

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-shopping-basket"></i></div>
					<div class="count"><?= DB::table('category')->count('category_id');?></div>
					<h3>Generics</h3>
					<p>Total Sum of Generics.</p>
				</div>
			</div>

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-users"></i></div>
					<div class="count"><?= DB::table('customer')->count('customer_id');?></div>
					<h3>Customers</h3>
					<p>Total Sum of All Customers.</p>
				</div>
			</div>

			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-user-plus"></i></div>
					<div class="count"><?= DB::table('admin')->count('id');?></div>
					<h3>Users</h3>
					<p>Total Sum of All Users.</p>
				</div>
			</div>
			
		</div>

		<div class="row" style="margin-top: 10px;">
			<div class="col-md-12 col-sm-12 col-xs-12 ">
			
				<div class="col-md-12 col-sm-12 col-xs-12 no_padding">
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Orders & Medicines Summary</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">
							<br>
							<div class="no_padding right_padding res_no_padding col-md-6 col-sm-12 col-xs-12">
								<canvas id="lineChart"></canvas>
							</div>
							<div class="no_padding right_padding res_no_padding col-md-6 col-sm-12 col-xs-12">
								<canvas id="mybarChart"></canvas>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row top_tiles">
		
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-shopping-cart"></i></div>
					<div class="count"><?= DB::table('order')->where('order_status',1)->count('order_id');?></div>
					<h3>Orders</h3>
					<p>Total Sum of All Orders.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-money"></i></div>
					<div class="count"><?= DB::table('order')->where('order_status',1)->sum('total_amount_payable');?></div>
					<h3>Order Amount</h3>
					<p>Total Sum of Amount of All Orders.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-money"></i></div>
					<div class="count"><?= DB::table('pament_details')->where('status',1)->sum('amount');?></div>
					<h3>Ammount Paid</h3>
					<p>Total Sum of Paid Amount of All Orders.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-money"></i></div>
					<div class="count"><?= DB::table('order')->where('order_status',1)->sum('total_amount_payable') - DB::table('pament_details')->where('status',1)->sum('amount');?></div>
					<h3>Ammount Due</h3>
					<p>Total Sum of Dued Amount of All Orders.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fas fa-bezier-curve"></i></div>
					<div class="count"><?= DB::table('product_type')->count('type_id');?></div>
					<h3>Medicine Types</h3>
					<p>Total Sum of Medicine Types.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-archive"></i></div>
					<div class="count"><?= DB::table('stock')->sum('stock_quantity');?></div>
					<h3>Total Stock</h3>
					<p>Total Sum of Medicines Stock.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-balance-scale"></i></div>
					<div class="count"><?= DB::table('order_details')->where('order_details_status',1)->sum('product_qty');?></div>
					<h3>Medicines Sold</h3>
					<p>Total Sum of Medicines Sold.</p>
				</div>
			</div>
			
			<div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				<div class="tile-stats">
					<div class="icon"><i class="fa fa-trash"></i></div>
					<div class="count"><?= DB::table('wastage')->sum('wastage_quantity');?></div>
					<h3>Total Wastage</h3>
					<p>Total Sum of Medicines Wasted.</p>
				</div>
			</div>
			
			
		</div>

		<div class="row" style="margin-top: 10px;">
			<div class="col-md-12 col-sm-12 col-xs-12 ">
			
				<div class="col-md-12 col-sm-12 col-xs-12 no_padding">
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Sales Summary (Total, Paid & Due)</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">
							<br>
							<div class="no_padding right_padding res_no_padding col-md-7 col-sm-12 col-xs-12">
								<canvas id="lineChartAmmount"></canvas>
							</div>
							
							<div class="no_padding col-md-5 col-sm-12 col-xs-12">
								<span><i class="fa fa-square text-primary"></i> Total Order Amount</span>
								<br>
								<span><i class="fa fa-square text-info"></i> Total Due Amount</span>
								<br>
								<br>
								<canvas id="piChart" style="width: 484px; height: 242px;" width="484" height="242"></canvas>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
		
	<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>