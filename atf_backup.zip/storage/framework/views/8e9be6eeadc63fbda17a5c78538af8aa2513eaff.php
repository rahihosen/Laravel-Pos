  
<?php $__env->startSection('admin_main_content'); ?>
    
    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <h3 class="no_padding bottom_padding"><i class="fa fa-user-plus"></i> User Management </h3>
                        
                    </div>


                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                    

                    <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Add User</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">        
                                
                                
                                <?php echo Form::open(['url' => '/save-admin','method'=>'post','enctype'=>'multipart/form-data']); ?>

                                
                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="last-name">Admin Name </label>
                                        <input type="text" id="last-name" name="admin_name" required="required" class="form-control">
                                        
                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="last-name">Admin Email</label>
                                        <input type="text" id="last-name" name="admin_email" required="required" class="form-control ">
                                        
                                    </div>
                                    
                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="last-name" style="padding-top: 10px;">Admin Photo </label>
                                        <input type="file" id="last-name" name="admin_image" class="form-control ">
                                    
                                    </div>
                                    
                                    <div class="form-group form-group-sm">

                                        <label class="control-label " for="cat-name" style="padding-top: 10px;">Admin Password </label>

                                        
                                        <input type="password" name="admin_password" required="required" class="form-control ">
                                        
                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label " for="cat-name" style="padding-top: 10px;">Admin Role </label>

                                        
                                        <select id="cat-name" name="admin_role" class="form-control " required="required">
                                       
                                            <option value="1" required="required">Admin</option>
                                            <option value="2" required="required">Manager</option>
                                            <option value="3" required="required" selected="selected">Salesman</option>
                                        
                                        </select>
                                        
                                    </div>
                                   

                                    <div class="form-group" style="padding-top: 10px;">
                                        <label class="control-label ">Active?</label>

                                        <div><br></div>

                                        <div id="gender" class="btn-group" data-toggle="buttons">
                                            <label class="btn btn-default active" >
                                                <input type="radio"  name="admin_status" value="1" required="required"  checked="checked" /> &nbsp; Yes &nbsp;
                                            </label>

                                            <label class="btn btn-default" >
                                                <input type="radio" name="admin_status" value="0" required="required"> No
                                            </label>
                                        </div>
                                        
                                    </div>

                                    <div class="ln_solid"></div>

                                    <div class="form-group form-group-sm">
                                        
                                        <!-- <a href="<?php echo e(URL::to('customer-list')); ?>" class="btn btn-primary">Back</a>
                                        <button class="btn btn-primary" type="reset">Reset</button> -->
                                        <button type="submit" class="btn btn-success">Save</button>
                                        
                                    </div>

                                <?php echo Form::close(); ?>                                
                                
                            </div>
                        </div>
                        
                    </div>

                    <div class="no_padding col-md-8 col-sm-8 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">User List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                <div class="table-responsive">                                    

                                    <table class="table table-striped bulk_action table-responsive table-bordered">

                                        <thead>
                                            <tr class="headings">
                                                <th class="column-title text-center">ID </th>
                                                <th class="column-title text-center">Name </th>
                                                <th class="column-title text-center">Email </th>
                                                <th class="column-title text-center">Photo </th>
                                                <th class="column-title text-center">Role</th>
                                                <th class="column-title text-center">Status</th>
                                                <th class="column-title text-center"> Action </th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <?php foreach($all_admin_info as $admin) { ?>

                                                <tr class="even pointer">
                                                    <td class="text-center"><?php echo e($admin->admin_id); ?></td>
                                                    <td class="text-center"><?php echo e($admin->admin_name); ?></td>
                                                    <td class="text-center"><?php echo e($admin->admin_email); ?></td>
                                                    <td class="text-center"><img src="<?php echo e($admin->admin_image); ?>" width="70" height="50"></td>
                                                    <td class="text-center"><?php echo e($admin->admin_role); ?></td>
                                                    <td class="text-center">

                                                        <?php if($admin->admin_status==1) { ?>

                                                            <button 
                                                                class="btn btn-success btn-xs"
                                                                ><a style="color:#fff;" href="<?php echo e(URL::to('/unpublish-admin/'.$admin->admin_id)); ?>">
                                                                Publish </a>
                                                            </button>

                                                        <?php } else { ?>

                                                            <button 
                                                                class="btn btn-warning btn-xs">
                                                                <a style="color:#fff;"href="<?php echo e(URL::to('/publish-admin/'.$admin->admin_id)); ?>">
                                                                Unpublish</a>
                                                            </button>

                                                        <?php } ?> 
                                                        
                                                    </td>
                                                    
                                                    <td class="text-center">
                                                        
                                                        <button 
                                                            class="btn btn-dark btn-xs edit_admin"

                                                            value="<?php echo e($admin->admin_id); ?>"
                                                            adminName="<?php echo e($admin->admin_name); ?>"
                                                            adminEmail="<?php echo e($admin->admin_email); ?>"
                                                            adminPassword="<?php echo e($admin->admin_password); ?>"
                                                            adminImage="<?php echo e($admin->admin_image); ?>"
                                                            oldImage="<?php echo e($admin->admin_image); ?>"
                                                            adminRole="<?php echo e($admin->admin_role); ?>"
                                                            adminStatus="<?php echo e($admin->admin_status); ?>"

                                                            ><i class="fas fa-pencil-alt"></i> Edit
                                                        
                                                        </button>
                                                        
                                                    </td>
                                                </tr>

                                            <?php }  ?>
                                                
                                        </tbody>
                                        
                                    </table>
                                    
                                </div>
                        
                                <div class="pagi_box pull-right">
                                    <?php if( $all_admin_info != ''): ?>
                                        <ul class="pagination">
                                            <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/admin-list?page=1')); ?>">First</a> </li>
                                        </ul>
                                            <?php echo e($all_admin_info->links()); ?>

                                        <ul class="pagination">
                                            <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/admin-list?page='.$all_admin_info->lastPage())); ?>">Last</a> </li>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- /page content -->

    <!-- Edit Admin Modal -->
    <div style="z-index:9999999999" class="modal fade edit_admin_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Edit Product <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-admin','method'=>'post','enctype'=>'multipart/form-data']); ?>


                        <div class="form-group form-group-sm">
                            <label class="control-label" > ID </label>
                            <input type="text" id="first-name" class="form-control admin_id" value="" disabled>
                            <input type="hidden" id="last-name"  name="admin_id" value="" class="form-control admin_id">
                            <input type="hidden" class="old_image" name="old_image" >
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" > Admin Name </label>
                            <input type="text"  name="admin_name" value="" required="required" class="form-control admin_name">

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" > Admin Password </label>
                            <input type="password"  name="admin_password" value="" class="form-control admin_password">
                            
                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label class="control-label" for="last-name"> Admin Email </label>
                            <input type="text" name="admin_email" required="required" class="form-control admin_email">
                            
                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label" > Admin Image </label>
                            <input type="file" id="last-name" name="admin_image"  class="clear_image form-control">
                            <img src="" alt="image" class="admin_img top_margin" width="auto" height="60px" >

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label " for="cat-name" style="padding-top: 10px;"> Admin Role </label>

                            
                            <select id="cat-name" name="admin_role" class="form-control" required="required">
                            
                                <option class="role" value=""></option>

                                <option value="1" required="required">Admin</option>
                                <option value="2" required="required">Manager</option>
                                <option value="3" required="required" >Salesman</option>
                            
                            </select>
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" > Active? </label>

                            <br>

                            <div id="gender" class="btn-group" data-toggle="buttons">

                                <label class="edit_admin_type_active btn btn-default" >
                                    <input type="radio" name="admin_status" value="1" required> &nbsp; Yes &nbsp;
                                </label>

                                <label class="edit_admin_type_inactive btn btn-default">
                                    <input type="radio" name="admin_status" value="0"> No
                                </label>

                            </div>
                            
                        </div>

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">

                            <!-- <a href="<?php echo e(URL::to('customer-list')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" class="btn btn-success">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>

                
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>