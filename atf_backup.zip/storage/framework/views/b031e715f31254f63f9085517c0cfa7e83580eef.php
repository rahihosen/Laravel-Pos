  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                    <h3 class="no_padding bottom_padding"><i class="fa fa-money" aria-hidden="true"></i> New Purchase </h3>
                    
                </div>

                <?php 

                    $message = Session::get('message');

                    if ( $message !='') { ?>

                        <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                            <h5 class="text-center">

                                <?php

                                    if(isset($message)) { ?>

                                        <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <strong> <?php echo $message;?> </strong>
                                        </div>
                                        
                                    <?php
                                        Session::put('message','');
                                    }
                                ?>

                            </h5>
                        </div> 
                        
                        <?php 
                    }
                    
                ?>
                
                <?php echo Form::open(['url' => '/save-buyer', 'method'=>'post']); ?>


                    <div class="no_padding col-md-12 col-sm-12 col-xs-12">
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Purchase Description</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                
                                <div class="no_padding col-md-4 col-sm-4 col-xs-12">
                                    
                                    <div class="form-group form-group-sm">
                                        <label for="select-buyer">Select Buyer:</label>
                                        
                                        <select id="select-buyer" class="form-control" name="buyer_id" required>
                                        
                                        <?php
                                        
                                            foreach($all_buyers as $all_buyers) { ?>

                                                <option value="<?= $all_buyers->buyer_id;?>"><?= $all_buyers->buyer_name;?> (<?= $all_buyers->buyer_email;?>)</option>
                                        
                                                <?php 
                                            }
                                        ?>
                                            
                                        </select>
                                        
                                    </div>
                                    
                                </div>	
                
                                <div class="right_no_pad col-md-8 col-sm-8 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label for="income-note">Purchase Note: </label>
                                        
                                        <input id="income-note" type="text" class="form-control" name="purchase_note" placeholder="Note">
                                        
                                        <br>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="no_padding col-md-12 col-sm-12 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Add Medicine</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body add_product_panel">

                                <div class="no_padding col-md-12 col-sm-12 col-xs-12" style="margin-bottom: 2em;">
                                    <div class="form-group form-group-sm">
                                    
                                        <button type="button" value="1" class="bill_remove_field btn btn-danger btn-xs"><i class="fa fa-minus"></i></button>
                                        
                                        <button type="button" value="1" class="bill_add_more_field btn btn-xs btn-primary"><i class="fa fa-plus"></i></button>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center no_padding col-md-1 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label>SL</label>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center no_padding col-md-3 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label>Medicine</label>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label>Purchase Price</label>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center no_padding col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label>Quantity</label>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center no_padding col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label></label>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center no_padding col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                        
                                        <label>Total</label>
                                    
                                    </div>
                                </div>
                                
                                <div class="text-center no_padding col-md-12 col-sm-12 col-xs-12">
                                    <br>
                                </div>
                                
                                <div class="no_padding col-md-1 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                    
                                        <input type="text" class="form-control" value="# 1" disabled>
                                        
                                    </div>
                                </div>
                                
                                <div class="no_padding col-md-3 col-sm-2 col-xs-12">

                                    <div class="form-group-sm">

                                        <input type="text" class="search_allPros form-control" placeholder="Search..." />
                                    
                                        <!-- <select class="allPros get_order_product form-control" name="order_product_id[]" required>
                                        
                                            <option disabled selected>Select Product</option>
                                        
                                            
                                        </select> -->
                                        
                                    </div>
                                </div>
                                
                                <div class="col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                    
                                        <input name="order_product_description[]" type="text" class="form-control" placeholder="Purchase Price" required>
                                        
                                    </div>
                                </div>
                                
                                <div class="no_padding col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                    
                                        <input type="text" class="upProPrice form-control" value="0" placeholder="Product Price" disabled>
                                        
                                        <input type="hidden" name="order_product_price[]" class="upProPrice"> 
                                        
                                    </div>
                                </div>
                                
                                <div class="no_padding col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                    
                                        <input type="text" class="order_product_discount form-control" value="0" name="order_product_discount" pattern="(^[0-9]{1,11})" title="Numbers Only" placeholder="Product Discount" required disabled>
                                        
                                    </div>
                                </div>
                                
                                <div class="no_padding col-md-2 col-sm-2 col-xs-12">
                                    <div class="form-group-sm">
                                    
                                        <input type="text" class="upTotalPrice upTotalPrice_1 form-control" value="0" placeholder="Total" disabled>
                                        
                                        <input type="hidden" name="order_total_price[]" class="upTotalPrice"> 
                                        
                                    </div>
                                </div>
                                
                                
                                <span class="field_to_add_before"></span>
                                
                                <div class="no_padding col-md-12 col-sm-12 col-xs-12">
                                    <hr>
                                </div>
                                
                                
                                
                                <div class="no_padding col-md-7 col-sm-7 col-xs-12">
                                    
                                    
                                    <div class="form-group form-group-sm">
                                    
                                        <h4>Inportant Notes:</h4>
                                        
                                        <p>
                                            <i class="fa fa-check"></i> Once Issued Invoice Can Not Be Changed.<br>
                                            <i class="fa fa-check"></i> Once Issued Invoice Can Not Be Changed.<br>
                                            <i class="fa fa-check"></i> Once Issued Invoice Can Not Be Changed.<br>
                                            <i class="fa fa-check"></i> Once Issued Invoice Can Not Be Changed.
                                        </p>
                                        
                                    </div>
                                    
                                    
                                </div>				
                                
                                
                                <div class="no_padding col-md-5 col-sm-5 col-xs-12">
                                    
                                    <div class="form-group-sm">
                                    
                                        <label>Sub Total</label>
                                        
                                        <input type="text" class="sub_total form-control" value="0" placeholder="Sub Total" disabled> 
                                        
                                        <input type="hidden" name="sub_total" class="sub_total">
                                        
                                        <br>
                                    </div>
                                    
                                    
                                    <div class="form-group-sm">
                                    
                                        <label>Discount</label>
                                        
                                        <input type="text" class="total_discount form-control" value="0" name="total_discount" pattern="(^[0-9]{1,11})" title="Numbers Only" placeholder="Discount" required disabled>
                                        <br>
                                    </div>

                                    <div class="form-group-sm">
                                    
                                        <label>After Discount</label>
                                        
                                        <input type="text" class="total_discount form-control" value="0" name="total_discount" pattern="(^[0-9]{1,11})" title="Numbers Only" placeholder="After Discount" required disabled>
                                        <br>
                                    </div>
                                    
                                    <div class="form-group-sm">
                                    
                                        <label>Vat</label>
                                        
                                        <input type="text" class="total_discount form-control" value="0" name="total_discount" pattern="(^[0-9]{1,11})" title="Numbers Only" placeholder="Vat" required disabled>
                                        <br>
                                    </div>
                                    
                                    
                                    
                                    <div class="form-group-sm">
                                    
                                        <label>Ammount Payable</label>
                                        
                                        <input type="text" class="ammount_payable form-control" value="0" placeholder="Ammount Payable" disabled> 
                                        
                                        <input type="hidden" name="ammount_payable" class="ammount_payable">
                                        
                                        <br>
                                    </div>
                                    
                                </div>
                                
                                <div class="no_padding col-md-12 col-sm-12 col-xs-12">
                                    
                                    <h3>Payment</h3>
                                    <hr>
                                    <div class="text-center no_padding col-md-4 col-sm-4 col-xs-12">
                                        <div class="form-group-sm">
                                            
                                            <label for="income-accounts">Select Account</label>
                                            
                                            <select id="income-accounts" class="form-control active" name="payment_account_id">
                                            
                                                
                                                <?php
                                        
                                                    foreach($all_accounts as $all_accounts) { ?>

                                                        <option value="<?= $all_accounts->account_id;?>"><?= $all_accounts->account_name;?> </option>
                                                
                                                        <?php 
                                                    }
                                                ?>
                                                
                                            </select>
                                            <br>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center col-md-4 col-sm-4 col-xs-12">
                                        <div class="form-group-sm">
                                            
                                            <label for="income-check">Cheque No.</label>
                                            
                                            <input id="income-check" type="text" class="form-control" name="payment_check_no" placeholder="Cheque No." required>
                                            <br>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center no_padding col-md-4 col-sm-4 col-xs-12">
                                        <div class="form-group-sm">
                                            
                                            <label for="income-transaction">Receipt / Transaction No.</label>
                                            
                                            <input id="income-transaction" type="text" class="form-control" name="payment_transaction_no" placeholder="Receipt / Transaction No." required>
                                            <br>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center no_padding col-md-4 col-sm-4 col-xs-12">
                                        <div class="form-group-sm">
                                            
                                            <label for="income-ammount">Ammount</label>
                                            
                                            <input pattern="(^[0-9]{1,11})" title="Numbers Only" id="income-ammount" type="text" class="form-control" name="payment_ammount" placeholder="Ammount" required>
                                            
                                            <br>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center right_no_pad col-md-8 col-sm-8 col-xs-12">
                                        <div class="form-group-sm">
                                            
                                            <label for="income-note">Note</label>
                                            
                                            <input id="income-note" type="text" class="form-control" name="payment_note" placeholder="Note">
                                            
                                            <br>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                </div>
                                
                            </div>

                        </div>                        
                    </div>

                    <div class="text-center box_layout col-md-12 col-sm-12 col-xs-12">
		
                        <button type="submit" class="btn btn-primary">Create</button>
                        
                    </div>

                <?php echo Form::close(); ?>  

            </div>
        </div>
    </div>


   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>