  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<style>
    
 #invoice-POS{
  box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
  padding:2mm;
  margin: 0 auto;
 /* width: 44mm;*/
  width: 90mm;
  background: #FFF;
  
  
::selection {background: #f31544; color: #FFF;}
::moz-selection {background: #f31544; color: #FFF;}
h1{
  font-size: 1.5em;
  color: #222;
}
h2{font-size: .9em;}
h3{
  font-size: 1.2em;
  font-weight: 300;
  line-height: 2em;
}
p{
  font-size: .7em;
  color: #666;
  line-height: 1.2em;
}
 
#top, #mid,#bot{ /* Targets all id with 'col-' */
  border-bottom: 1px solid #EEE;
}

#top{min-height: 100px;}
#mid{min-height: 80px;} 
#bot{ min-height: 50px;}

#top .logo{
  //float: left;
	height: 60px;
	width: 60px;
	/*background: url(http://michaeltruong.ca/images/client.jpg)) no-repeat;*/
	background-size: 60px 60px;
}
.clientlogo{
  float: left;
	height: 60px;
	width: 60px;
	/*background: url(http://michaeltruong.ca/images/client.jpg) no-repeat;*/
	background-size: 60px 60px;
  border-radius: 50px;
}
.info{
  display: block;
  //float:left;
  margin-left: 0;
}
.title{
  float: right;
}
.title p{text-align: right;} 
table{
  width: 100%;
  border-collapse: collapse;
}
td{
  padding: 5px 0 5px 15px;
  border: 1px solid #EEE
}
.tabletitle{
  //padding: 5px;
  font-size: .5em;
  background: #EEE;
}
.service{border-bottom: 1px solid #EEE;}
.item{width: 34mm;}
.itemtext{font-size: .5em;}

#legalcopy{
  margin-top: 5mm;
}

  
  
}
    
</style>


<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                       <div class="x_title hidden-print">
                        <!--<h2> <a href="add-category" class="btn btn-primary"> <i class="fa fa-plus" aria-hidden="true"></i>
                                Create New Category </a> </h2>-->

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>    
                    <div class="x_content"> 
                
           
<div id="invoice-POS">

    <center id="top">
        <div class="logo"></div>
        <div class="info">
            <?php 
            $company=DB::table('settings')
                    ->first();
            ?>
            <img src="<?php echo e(asset($company->company_logo)); ?>" width="60" height="50">
            
            <h3><?php echo $company->company_name; ?></h3>
        </div><!--End Info-->
    </center><!--End InvoiceTop-->

    <div id="mid" style="margin:0 15px;">
        <div class="info">
            <p class="text-center"> 
                <?php echo $company->company_address; ?></br>
                Email:<?php echo $company->company_email;?>, Mob:<?php echo $company->company_mobile;?></br>
            </p>
            
            <div>
                <table class="table" style="margin:0 !important;">
                    <tbody>
                    <tr><?php
            foreach($single_order_info_customer as $order_customer){?>

                <?php
                    $customer_id=$order_customer->customer_id;
                ?>
                        <td style="padding: 3px 0;">Order # <?php echo $order_id=$order_customer->order_id;?></td>
                        <td style="padding: 3px 0;">Date: <?php echo $order_id=$order_customer->order_created_date;?></td> <?php 
               
                }
               ?>
               <?php 
                $order_id=$order_customer->order_id;
               $table_number = DB::table('order_details')
                                ->where('order_id',$order_id)
                                ->first();
               ?>
                        <td style="padding: 3px 0;">Table # <?php echo $table_number->table_number;?></td>
                    </tr>
                    </tbody>
                </table>
               
            </div>
                
                    <?php 
                    $customer = DB::table('customer')
                                ->where('customer_id',$customer_id)
                                ->get();
                    foreach($customer as $cust){ ?>
            
                        <p> 
                           <span class="pull-left">Customer: <?php echo $cust->customer_name;?></span>
                           <span class="pull-right">  
                                Mob: <?php echo $cust->customer_mobile;?>
                               
                            </span>
                        </p>
                        
            
                    <?php  } ?>
            
        </div>
    </div><!--End Invoice Mid-->
    
    <div id="bot" style="margin:0 15px;">
        
        <div id="table">
            <table style="border-top:1px solid lightgray;border-bottom:1px solid lightgray;">
                <tr class="tabletitle">
                    <td class="item" style="width:40%"><h2>Item</h2></td>
                    <td class="Hours" style="width:10%"><h2>Qty</h2></td>
                    <td class="Rate" style="width:15%"><h2 class="text-right">Price</h2></td>
                    <td class="Rate" style="width:20%"><h2 class="text-right">S.Total</h2></td>
                </tr>

              
              <?php $__currentLoopData = $single_order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr class="service">
                    <td class="tableitem"><p class="itemtext"><?php echo e($order->product_name); ?></p></td>
                    <td class="tableitem"><p class="itemtext text-center"><?php echo e($order->product_qty); ?></p></td>
                    <td class="tableitem"><p class="itemtext text-right"><?php echo e($order->product_sale_price); ?></p></td>
                    <td class="tableitem"><p class="itemtext text-right"><?php echo e($order->product_qty*$order->product_sale_price); ?></p></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
                <!--
                <tr class="tabletitle">
                    <td></td>
                    <td class="Rate"><h2>tax</h2></td>
                    <td class="payment"><h2>$419.25</h2></td>
                </tr>-->

                <tr class="tabletitle">
                    <?php $order_id=$order->order_id;?>
                    <td></td>
                    <td class="text-left" colspan="2" ><b>Total</b></td>
                    <td class="text-right"><b>TK.<?php echo e($order = DB::table('order')
                ->where('order_id',$order_id)
                ->sum('order_total')); ?></b></td>
                
                </tr>
                <tr class="tabletitle">
                    
                    <td></td>
                    <td  colspan="2" class="text-left"><b>Discount(%)</b></td>
                            <td class="text-right"><b>
                          <?php 
                $order_id=$order_customer->order_id;
               $discount = DB::table('order')
                                ->where('order_id',$order_id)
                                ->first();
               echo $discount->order_discount;
               ?>
                        </b></td>
                
                </tr>
                <tr class="tabletitle">
                    
                    <td></td>
                    <td class="text-left" colspan="2"><b>Payable</b></td>
                            <td class="text-right"><b>
                          <?php echo $discount->total_amount_payable; ?>
                        </b></td>
                
                </tr>
                <tr class="tabletitle">
                    
                    <td></td>
                    <td class="text-left" colspan="2"><b>Cash</b></td>
                            <td class="text-right"><b>
                          <?php echo $discount->amount_received; ?>
                        </b></td>
                
                </tr>
                <tr class="tabletitle">
                    
                    <td></td>
                    <td class="text-left" colspan="2"><b>Return</b></td>
                            <td class="text-right"><b>
                          <?php echo $discount->amount_return; ?>
                        </b></td>
                
                </tr>
                
                

            </table>
        </div><!--End Table-->
        <br>
        <br>
        <!--<div id="legalcopy">
            <p class="legal"><strong>Thank you for your order!</strong>  Order not refunded after 10 minutes. 
            </p>
        </div>-->

    </div><!--End InvoiceBot-->
    <a href="<?php echo e(url('/order-list')); ?>" class="hidden-print"><button class="btn btn-warning hidden-print" style="margin-left:15px;"><i class="fa fa-arrow-left"></i> Back</button></a>
    <a href="<?php echo e(url('/print-order-page/'.$discount->order_id)); ?>" target="_blank"><button class="btn btn-success hidden-print pull-right" style="margin-right:15px;"><i class="fa fa-print"></i> Print</button></a>
</div><!--End Invoice-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>