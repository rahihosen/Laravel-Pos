  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col right_col_back" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                    <h3 class="no_padding bottom_padding"><i class="fa fa-archive"></i> Food Manu </h3> 

                    <h5 class="text-center" style="color:green;">
                        <?php
                            $message=Session::get('message');
                            if(isset($message))
                            {
                                echo $message;
                                Session::put('message','');
                            }
                        ?>
                    </h5>

                </div>

                <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                    
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Add Food Category</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">        
                            
                            
                            <?php echo Form::open(['url' => '/save-category','method'=>'post']); ?>

                                    
                                <div class="form-group form-group-sm">
                                    <label class="control-label " for="category-name">Category Name </label>                                    
                                    <input type="text" id="last-name" name="category_name" required="required" class="form-control">
                                    
                                </div>

                                <div class="form-group form-group-sm">
                                    <label class="control-label " for="last-name" style="padding-top: 10px;">Category Order </label>
                                    <input type="number" id="last-name" name="category_order" required="required" min="1" class="form-control ">
                                    
                                </div>
                                
                                <div class="form-group form-group-sm">
                                    <label class="control-label" style="padding-top: 5px;">Special Menu?</label>

                                    <div> <br/> </div>

                                    <div id="gender" class="btn-group" data-toggle="buttons">

                                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="special_menu" value="1" required="required"> &nbsp; Yes &nbsp;
                                        </label>

                                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="special_menu" value="0" required="required"> No
                                        </label>

                                    </div>
                                    
                                </div>
                                
                                <div class="form-group form-group-sm">
                                    <label class="control-label" style="padding-top: 5px;">Publication Status: </label>

                                    <div> <br /> </div>

                                    <div id="gender" class="btn-group" data-toggle="buttons">

                                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="category_status" value="1" required="required"> &nbsp; Published &nbsp;
                                        </label>

                                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="category_status" value="0" required="required"> Unpublished
                                        </label>

                                    </div>
                                    
                                </div>
                                
                                <div class="ln_solid"></div>
                                
                                <!-- <a href="<?php echo e(URL::to('category-list')); ?>" class="btn btn-primary">Back</a>
                                <button class="btn btn-primary" type="reset">Reset</button> -->
                                <button type="submit" class="btn btn-success">Save</button>
                                    

                            <?php echo Form::close(); ?>

                            
                        </div>
                    </div>
                </div>
                
                <div class="no_padding col-md-8 col-sm-8 col-xs-12">			
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Food Category List</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>
                        <div class="panel-body">
                            
                            <div class="table-responsive">
                                <table class="table table-striped  bulk_action table-responsive table-bordered">
                                    <thead>
                                        <tr class="headings">
                                            <th class="column-title text-center">ID </th>
                                            <th class="column-title text-center"> Category Name </th>
                                            <th class="column-title text-center"> Order </th>
                                            <th class="column-title text-center"> Special Menu? </th>
                                            <th class="column-title text-center"> Status </th>
                                            <th class="column-title text-center"> Action </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php foreach($all_category_info as $category) {?>

                                            <tr class="even pointer">

                                                <td class="text-center"><?php echo e($category->category_id); ?></td>
                                                <td class="text-center"><?php echo e($category->category_name); ?></td>
                                                <td class="text-center"><?php echo e($category->category_order); ?></td>
                                                <td class="text-center">
                                                    <?php if($category->special_menu == 1 ) { ?>

                                                        <a class="btn btn-success btn-xs">Yes</a>

                                                    <?php } else {
                                                    ?> 
                                                        <a class="btn btn-warning btn-xs">No</a>       
                                                    <?php } ?> 
                                                </td>

                                                <td class="text-center">
                                                    <?php if($category->category_status==1) { ?>
                                                        <a class="btn btn-success btn-xs">Active</a>
                                                    <?php } else {
                                                    ?> 
                                                        <a class="btn btn-warning btn-xs">Inactive</a>       
                                                    <?php } ?> 
                                                </td>
                                                
                                                <td class="last text-center">
                                                    <?php if($category->category_status==1) { ?>

                                                        <!-- <button class="btn btn-success btn-xs"><a style="color:#fff;"href="<?php echo e(URL::to('/unpublish-category/'.$category->category_id)); ?>"><i class="fa fa-hand-o-down"></a></i></button> -->

                                                    <?php } else {
                                                    ?> 
                                                        <!-- <button class="btn btn-warning btn-xs"><a style="color:#fff;"href="<?php echo e(URL::to('/publish-category/'.$category->category_id)); ?>"><i class="fa fa-hand-o-up"></i></a></button> -->

                                                    <?php } ?>

                                                    <button class="btn btn-dark btn-xs edit_category" value="<?php echo e($category->category_id); ?>" 
                                                            data-catName="<?php echo e($category->category_name); ?>" data-catOrder="<?php echo e($category->category_order); ?>"
                                                            data-specialMenu="<?php echo e($category->special_menu); ?>" data-status="<?php echo e($category->category_status); ?>">                                                     
                                                        <i class="glyphicon glyphicon-pencil"></i> Edit Category
                                                    </button>

                                                    <!-- <a href="<?php echo e(URL::to('/edit-category/'.$category->category_id)); ?>" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-pencil"></i> Edit</a> -->

                                                    <!--<a href="URL::to('/delete-category/'.$category->category_id)" class="btn btn-danger btn-xs" onclick="return checkDelete()"> <i class="glyphicon glyphicon-remove"></i> Delete</a>-->
                                                </td>
                                                
                                            </tr>
                                        <?php  } ?>

                                    </tbody>
                                </table>
                            </div>
                            
                        </div>

                        <div class="pull-right">
                            <?php if( $all_category_info != ''): ?>
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/category-list?page=1')); ?>">First</a> </li>
                                </ul>
                                <?php echo e($all_category_info->links()); ?>

                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/category-list?page='.$all_category_info->lastPage())); ?>">Last</a> </li>
                                </ul>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                </div> 

            </div>
        </div>
    </div>
</div>

<!-- /page content -->



    <!-- Modal Edit Category -->
    <div style="z-index:9999999999" class="modal fade edit_category_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Edit Category <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">

                    <?php echo Form::open(['url'=>'/update-category','method'=>'post']); ?>

                            
                        <div class="form-group form-group-sm">

                            <input type="hidden" id="" class="category_id" name="category_id" value="">
                            <label class="control-label " for="Id">ID </label>                                    
                            <input type="text" id="" class="form-control category_id" value="" disabled>
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name">Category Name </label>
                            <input type="text" id="" name="category_name" class="form-control category_name" value="" required="required" >
                            
                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label " for="last-name">Category Order </label>
                            <input type="number" class="form-control category_order" id="last-name" name="category_order" value="" required="required" >
                            
                        </div>
                        
                        <div><br> </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label">Special Menu?</label>  

                            <div id="gender" class="btn-group" data-toggle="buttons">

                                <label class="edit_cat_special_type_active btn btn-default" >
                                    <input type="radio" name="special_menu" value="1" autocomplete="off"> &nbsp; Yes &nbsp;
                                </label>
                                <label class="edit_cat_special_type_inactive btn btn-default" >
                                    <input type="radio" name="special_menu" value="0" autocomplete="off"> No
                                </label>

                            </div>
                            
                        </div>

                        <div><br> </div>

                        <div class="form-group form-group-sm">
                            <label class="control-label" style="padding-top: 5px;">Publication Status: </label>

                            <div id="gender" class="btn-group" data-toggle="buttons">

                                <label class="edit_cat_type_active btn btn-default" >
                                    <input type="radio" name="category_status" value="1" autocomplete="off"> &nbsp; Published &nbsp;
                                </label>

                                <label class="edit_cat_type_inactive btn btn-default" >
                                    <input type="radio" name="category_status" value="0" autocomplete="off"> Unpublished
                                </label>

                            </div>
                            
                        </div>

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">
                            
                            <!-- <a href="<?php echo e(URL::to('category-list')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" class="btn btn-success">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>                    
                        
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>