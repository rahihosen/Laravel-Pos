  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <h3 class="no_padding bottom_padding"><i class="fa fa-money" aria-hidden="true"></i> Transaction History </h3>
                        
                    </div>

                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>

                    <div class="no_padding col-md-12 col-sm-12 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Transation List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                <div class="table-responsive">                                    

                                    <table class="table table-striped bulk_action table-responsive table-bordered">

                                        <?php

                                            $data = count($transactions);
                                            
                                            if ( $data !='' ) { ?>
                                                
                                                <thead>
                                                    <tr class="headings">
                                                        <th class="column-title text-center">ID </th>
                                                        <th class="column-title text-center">Name </th>
                                                        <th class="column-title text-center">Branch </th>
                                                        <th class="column-title text-center">Account No. </th>
                                                        <th class="column-title text-center">Ammount</th>
                                                        <th class="column-title text-center">Note</th>
                                                        <th class="column-title text-center">Transaction Type</th>
                                                        <th class="column-title text-center">Created By</th>
                                                        <th class="column-title text-center">Created Date / Time</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    
                                                    <?php  foreach ( $transactions as $transaction) { ?>

                                                        <tr class="even pointer">
                                                        
                                                            <td class="text-center"><?php echo e($transaction->account_id); ?></td>
                                                            <td class="text-center"><?php echo e($transaction->account_name); ?></td>
                                                            <td class="text-center"><?php echo e($transaction->account_branch); ?></td>
                                                            <td class="text-center"><?php echo e($transaction->account_no); ?></td>
                                                            <td class="text-center"><?php echo e($transaction->ammount); ?></td>
                                                            <td class="text-center"><?php echo e($transaction->note); ?></td>
                                                            <td class="text-center">

                                                                <?php if($transaction->balance_type==1) { ?>

                                                                    <span class="label label-success">Investment</span>

                                                                <?php } else { ?> 

                                                                    <span class="label label-warning">Loan</span>

                                                                <?php } ?>

                                                            </td>
                                                            
                                                            <td class="text-center"><?php echo e($transaction->admin_name); ?></td>
                                                            <td class="text-center"><?php echo e($transaction->balance_created_date); ?> / <?php echo e($transaction->balance_created_time); ?></td>
                                                            
                                                        </tr>

                                                        <?php
                                                    }
                                                    ?>
                                                    
                                                        
                                                </tbody>

                                                <?php
                                            }
                                        
                                        ?>
                                        
                                    </table>
                                    
                                </div>
                            </div>

                            <div class=" pull-right">

                                <?php if( $transactions != ''): ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/transaction-list?page=1')); ?>">First</a> </li>
                                    </ul>

                                    <?php echo e($transactions->links()); ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/transaction-list?page='.$transactions->lastPage())); ?>">Last</a> </li>
                                    </ul>

                                <?php endif; ?>

                            </div>

                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>