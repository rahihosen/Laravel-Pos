  
<?php $__env->startSection('admin_main_content'); ?>
    <!-- page content -->
   
        <div class="right_col right_col_back" role="main">
             
          <!-- top tiles -->
          <?php date_default_timezone_set("Asia/Dhaka");
            $today = date("Y-m-d");
          ?>
          <div class="row tile_count">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-money"></i> Today Sales </span>
                <div class="count" style="color:#00264d;"><?php echo e($order = DB::table('order')
                                        ->where('order_created_date',$today)
                                        ->where('order_status',0)
                                        ->sum('order_total')); ?>

              </div>
              <span class="count_bottom"><i class="green">TK. </i> Today Sold</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-shopping-bag"></i> Today Order</span>
              <div class="count" style="color:#00264d;"><?php echo e($order = DB::table('order')
                                        ->where('order_created_date',$today)
                                        ->where('order_status',0)
                                        ->count()); ?>

              </div>
              <span class="count_bottom"><i class="green">Qty. </i> Order Placed</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-at"></i> Today Sales Qty</span>
              <div class="count" style="color:#00264d;"><?php echo e($order = DB::table('order_details')
                                      ->where('order_details_created_date',$today)
                                      ->where('order_status',0)
                                      ->sum('product_qty')); ?>

              </div>
              <span class="count_bottom"><i class="green">Qty. </i> Qty Sold</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-money"></i> Total Sales</span>
              <div class="count" style="color:#0354A6;"><?php echo e($order = DB::table('order')
                         ->where('order_status',0)
                        ->sum('order_total')); ?>

              </div>
              <span class="count_bottom"><i class="red">TK. </i> Total Sold</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-shopping-bag"></i> Total Orders</span>
              <div class="count" style="color:#0354A6;"><?php echo e($order = DB::table('order')
                            ->where('order_status',0)
                            ->count()); ?>

              </div>
              <span class="count_bottom"><i class="red">Qty. </i> Order Placed</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-at"></i> Total Sales Qty</span>
              <div class="count" style="color:#0354A6;"><?php echo e($order = DB::table('order_details')
                                  ->where('order_status',0)
                                  ->sum('product_qty')); ?>

              </div>
              <span class="count_bottom"><i class="red">Qty. </i> Qty Sold</span>
            </div>
          </div>
          <!-- /top tiles -->
          <hr>
          <hr>
          <!-- top tiles -->
          
          <div class="row tile_count">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-money"></i> Total Stock Qty </span>
              <div class="count" style="color:#00264d;"><?php echo e($stock = DB::table('stock')
                                        ->sum('total_in_qty')); ?>

              </div>
              <span class="count_bottom"><i class="green">Qty. </i> Have Stocked</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-shopping-bag"></i> Total Stock Item</span>
              <div class="count" style="color:#00264d;"><?php echo e($stock = DB::table('stock')
                                        ->count('product_id')); ?>

              </div>
              <span class="count_bottom"><i class="green">Item </i> Have Stocked</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-archive"></i> Total Menu</span>
              <div class="count" style="color:#00264d;"><?php echo e($menu = DB::table('category')
                                        ->count('category_id')); ?>

              </div>
              <span class="count_bottom"><i class="green">Menu </i> Added</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-archive"></i> Total Item</span>
              <div class="count" style="color:#0354A6;"><?php echo e($item = DB::table('product')
                                        ->count('product_id')); ?>

              </div>
              <span class="count_bottom"><i class="green">Item </i> Added</span>
            </div>
              <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-users"></i> Total Customer </span>
              <div class="count" style="color:#0354A6;"><?php echo e($customer = DB::table('customer')
                                        ->count('customer_id')); ?>

              </div>
              <span class="count_bottom"><i class="green">Customer </i> Have Purchase</span>
            </div>
            
            
           
            
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user-plus"></i> Total Admin</span>
              <div class="count" style="color:#0354A6;"><?php echo e($total_admin = DB::table('admin')
                                  ->count('admin_id')); ?>

              </div>
              <span class="count_bottom"><i class="red">Person </i> Have Admin</span>
            </div>
            
          </div>
          <!-- /top tiles -->
          <hr>
          <hr>
          <!-- top tiles -->
          
          <div class="row tile_count">
              
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-shopping-bag"></i> Dued Order </span>
              <div class="count red"><?php echo e($return = DB::table('due')
                                        ->count('due_id')); ?>

              </div>
              <span class="count_bottom"><i class="green">Order </i> Have Dued</span>
            </div>
              <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-money"></i> Due Amount </span>
              <div class="count red"><?php echo e($return = DB::table('order')
                                        ->sum('amount_due')); ?>

              </div>
              <span class="count_bottom"><i class="green">Tk. </i> Have Dued</span>
            </div>
              
              
              <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-shopping-bag"></i> Canceled Order </span>
              <div class="count red"><?php echo e($return = DB::table('order')
                                        ->where('order_status',1)
                                        ->count('order_id')); ?>

              </div>
              <span class="count_bottom"><i class="green">Order </i> Have Canceled</span>
            </div>
              
             <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                <span class="count_top"><i class="fa fa-money"></i> Canceled Order Amount </span>
              <div class="count red"><?php echo e($return = DB::table('order')
                                        ->where('order_status',1)
                                        ->sum('order_total')); ?>

              </div>
              <span class="count_bottom"><i class="green">Order </i> Have Returned</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-trash"></i> Total Wastage Qty</span>
              <div class="count red"><?php echo e($wastage_qty = DB::table('wastage')
                                   ->sum('total_in_wastage_qty')); ?>

              </div>
              <span class="count_bottom"><i class="red">Qty. </i> Product Wastage</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-trash-o"></i> Total Wastage Item</span>
              <div class="count red"><?php echo e($wastage_item = DB::table('wastage')
                                  ->count('product_id')); ?>

              </div>
              <span class="count_bottom"><i class="red">Item </i> Wastage</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-trash"></i> Last In Wastage Qty</span>
              <div class="count red"><?php echo e($last_wastage_qty = DB::table('wastage')
                                  ->sum('last_in_wastage_qty')); ?>

              </div>
              <span class="count_bottom"><i class="red">Qty. </i> Product Wastage</span>
            </div>
              
            
          </div>
          <!-- /top tiles -->

        </div>
        <!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>