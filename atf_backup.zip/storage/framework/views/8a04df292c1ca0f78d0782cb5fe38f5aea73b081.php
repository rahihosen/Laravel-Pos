  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col right_col_back" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                    <h3 class="no_padding bottom_padding"><i class="fa fa-users"></i> Group </h3> 

                    <h5 class="text-center" style="color:green;">
                        <?php
                            $message=Session::get('message');
                            if(isset($message))
                            {
                                echo $message;
                                Session::put('message','');
                            }
                        ?>
                    </h5>

                </div>

                <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                    
                    <div class="panel panel-amin">

                        <div class="panel-heading">
                            <h3 class="panel-title">Add Group</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">        
                            
                            
                            <?php echo Form::open(['url' => '/save-customer-group', 'method'=>'post']); ?>

                            
                                <div class="form-group form-group-sm">

                                    <label class="control-label" for="last-name">Group Name </label>
                                    <input type="text" id="last-name" name="group_name" required="required" class="form-control">
                                    
                                </div>

                                <div class="ln_solid"></div>

                                <div class="form-group form-group-sm">
                                    
                                    <!-- <a href="<?php echo e(URL::to('customer-list')); ?>" class="btn btn-primary">Back</a>
                                    <button class="btn btn-primary" type="reset">Reset</button> -->
                                    <button type="submit" class="btn btn-success">Save</button>
                                    
                                </div>

                            <?php echo Form::close(); ?>

                            
                            
                        </div>
                    </div>
                    
                </div>

                <div class="no_padding col-md-8 col-sm-8 col-xs-12">			
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Group List</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

                                <table class="table table-striped bulk_action table-responsive table-bordered">
                                    <thead>
                                        <tr class="headings">
                                            <th class="column-title text-center">ID </th>
                                            <th class="column-title text-center">Group Name </th>
                                            <th class="column-title text-center">Created By </th>
                                            <th class="column-title text-center">Created</th>
                                            <th class="column-title text-center">Updated </th>
                                            <th class="column-title"> Action </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php

                                            $customer_group = DB::table('customer_group')->join('admin', 'customer_group.created_by', '=', 'admin.admin_id', 'left')->get();

                                            foreach($customer_group as $customer_group) { ?>

                                                <tr class="even pointer">
                                                    <td class="text-center"><?php echo e($customer_group->group_id); ?></td>
                                                    <td class="text-center"><?php echo e($customer_group->group_name); ?></td>
                                                    <td class="text-center"><?php echo e($customer_group->admin_name); ?></td>
                                                    <td class="text-center"><?php echo e($customer_group->created_date); ?> / <?php echo e($customer_group->created_time); ?></td>
                                                    <td class="text-center"><?php echo e($customer_group->updated_date); ?> / <?php echo e($customer_group->updated_time); ?></td>
                                                    <td class=" last">

                                                        <button
                                                            class="btn btn-dark btn-xs edit_customer_group"

                                                            value="<?php echo e($customer_group->group_id); ?>"
                                                            groupName="<?php echo e($customer_group->group_name); ?>">

                                                            <i class="glyphicon glyphicon-pencil"></i> Edit
                                                        
                                                        </button>

                                                    </td>
                                                </tr>

                                            <?php   } 
                                        ?>                                            
                                            
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>                        
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->

    <!-- Edit Customer Modal -->
    <div style="z-index:9999999999" class="modal fade edit_customer_group_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Edit Product <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-customer-group', 'method'=>'post']); ?>


                        <div class="form-group form-group-sm">

                            <label class="control-label" for="first-name">ID </label>
                            <input type="text" id="first-name" class="form-control group_id" value="" disabled>
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="last-name">Group Name </label>
                            <input type="text" id="last-name" name="group_name" value="" required="required" class="form-control group_name">
                            <input type="hidden" class="group_id" name="group_id">
                            
                        </div>

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">

                            <a href="<?php echo e(URL::to('customer-group-list')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button>
                            <button type="submit" class="btn btn-success">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>

                        
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>