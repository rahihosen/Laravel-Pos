  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2> <a href="add-category" class="btn btn-primary"> <i class="fa fa-plus" aria-hidden="true"></i>
                                Create Menu </a> </h2>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 

                        <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>


                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        <th class="column-title text-center">ID </th>
                                        <th class="column-title text-center"> Category Name </th>
                                        <th class="column-title text-center"> Order </th>
                                        <th class="column-title text-center"> Special Menu? </th>
                                        <th class="column-title text-center"> Status </th>
                                        <th class="column-title text-center"> Action </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach($all_category_info as $category) {?>

                                        <tr class="even pointer">
                                            <td class="text-center"><?php echo e($category->category_id); ?></td>
                                            <td class="text-center"><?php echo e($category->category_name); ?></td>
                                            <td class="text-center"><?php echo e($category->category_order); ?></td>
                                            <td class="text-center">
                                                <?php if($category->special_menu==1) { ?>
                                                    <a class="btn btn-success btn-xs">Yes</a>
                                                <?php } 
                                                else
                                                {
                                                 ?> 
                                                    <a class="btn btn-warning btn-xs">No</a>       
                                                <?php } ?> 
                                            </td>
                                            <td class="text-center">
                                                <?php if($category->category_status==1) { ?>
                                                    <a class="btn btn-success btn-xs">Active</a>
                                                <?php } 
                                                else
                                                {
                                                 ?> 
                                                    <a class="btn btn-warning btn-xs">Inactive</a>       
                                                <?php } ?> 
                                            </td>
                                          
                                            
                                            <td class="last text-center">
                                                <?php if($category->category_status==1) { ?>
                                                <button class="btn btn-success btn-xs"><a style="color:#fff;"href="<?php echo e(URL::to('/unpublish-category/'.$category->category_id)); ?>"><i class="fa fa-hand-o-down"></a></i></button>
                                            <?php } 
                                            else
                                            {
                                             ?> 
                                                <button class="btn btn-warning btn-xs"><a style="color:#fff;"href="<?php echo e(URL::to('/publish-category/'.$category->category_id)); ?>"><i class="fa fa-hand-o-up"></i></a></button>       
                                            <?php } ?> 
                                                <a href="<?php echo e(URL::to('/edit-category/'.$category->category_id)); ?>" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-pencil"></i> Edit</a>
                                                <!--<a href="URL::to('/delete-category/'.$category->category_id)" class="btn btn-danger btn-xs" onclick="return checkDelete()"> <i class="glyphicon glyphicon-remove"></i> Delete</a>-->
                                            </td>
                                        </tr>
                                    <?php  } ?>

                                </tbody>
                            </table>
                        </div>
                        <div class="pull-right">
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/category-list?page=1')); ?>">First</a> </li>
                            </ul>
                            <?php echo e($all_category_info->links()); ?> 
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/category-list?page='.$all_category_info->lastPage())); ?>">Last</a> </li>
                            </ul>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>