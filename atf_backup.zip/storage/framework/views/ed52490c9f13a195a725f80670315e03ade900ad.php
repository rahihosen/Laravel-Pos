  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                
                
                <div class="x_panel">
                    <div class="x_title">
                        <h2> Due List</h2>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 
                        
                        <!-- form date pickers -->
                      
                        <form>  
                        <div class="form-group col-md-4">
                            <div class="input-group date">
                                <input type="text" class="date_from datepicker form-control" value="<?php echo e(date("Y-m-d")); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input-group date">
                                <input type="text" class="date_to datepicker form-control" value="<?php echo e(date("Y-m-d")); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-2">
                            <button type="button" class="date_from_to_due btn btn-success">Go!</button>
                        </div>
                         </form>
                 
                <!-- /form datepicker -->
                
                

                        <h5 class="text-center" style="color:green;">
                  <?php
                  $message=Session::get('message');
                  if(isset($message))
                  {
                      echo $message;
                      Session::put('message','');
                  }
                  ?>
              </h5>


                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        
                                        <th class="column-title text-center">Issue Date </th>
                                        <th class="column-title text-center">Due ID </th>
                                        <th class="column-title text-center">Order ID </th>
                                        <th class="column-title text-center">Customer Name </th>
                                        <th class="column-title text-center"> Total</th>
                                        <th class="column-title text-center"> Received</th>
                                        <th class="column-title text-center"> Due</th>
                                        <th class="column-title text-center"> Action </th>
                                    </tr>
                                </thead>

                                <tbody class="order_list_table">
                                    <?php foreach($all_due_info as $due) {?>

                                        <tr class="even pointer">
                                            <td class="text-center"><?php echo e($due->due_created_date); ?></td>
                                            <td class="text-center"><?php echo e($due->due_id); ?></td>
                                            <td class="text-center"><?php echo e($due->order_id); ?></td>
                                            <td class="text-center"><?php echo e($due->customer_name); ?></td>
                                            <td class="text-center"><?php echo e($due->order_total); ?></td>
                                            <td class="text-center"><?php echo e($due->amount_received); ?></td>
                                            <td class="text-center" style="color:red;"><b><?php echo e($due->amount_due); ?></b></td>
                                           <td class="last text-center">
                                                <a href="<?php echo e(URL::to('/print-order-page/'.$due->order_id)); ?>" target="_blank" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-print"></i> Print</a>
                                                <a href="<?php echo e(URL::to('/view-order/'.$due->order_id)); ?>" class="btn btn-info btn-xs"> <i class="glyphicon glyphicon-eye-open"></i> View</a>

                                            </td>
                                        </tr>
                                    <?php  } ?>
                                        <tr>
                                            
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                          
                                            <td class="text-center">
                                                <b>
                                                   Total:TK. <?php
                                                     echo $due_total= DB::table('order')
                                                                ->sum('amount_due');
                                                    ?>
                                                </b>
                                            </td>
                                            <td></td>
                                        </tr>

                                </tbody>
                            </table>
                        </div>
                        <div class="pull-right hide_pagi">
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/due-list?page=1')); ?>">First</a> </li>
                            </ul>
                            <?php echo e($all_due_info->links()); ?> 
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/due-list?page='.$all_due_info->lastPage())); ?>">Last</a> </li>
                            </ul>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>