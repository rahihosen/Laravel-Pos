  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <h3 class="no_padding bottom_padding"><i class="fa fa-money" aria-hidden="true"></i> Loan </h3>
                        
                    </div>


                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                    

                    <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Loan</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">        
                                
                                
                                <?php echo Form::open(['url' => '/save-loan','method'=>'post']); ?>


                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="account-name">Loan Description </label>
                                        <textarea class="form-control" aria-label="" name="loan_description" required="required"></textarea>

                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label " for="account-no" style="padding-top: 10px;">Loan Ammount </label>
                                        <input type="number" name="loan_ammount" required="required" class="form-control ">
                                        
                                    </div> 
                                                                        
                                    <div class="form-group form-group-sm" >

                                        <label class="control-label" for="account-name" style="padding-top: 10px;"> Select Account </label>

                                        <select id="" name="account_id" class="form-control " required="required">
                                            
                                            <?php
                                                $accounts = DB::table('accounts')->get();
                                                foreach($accounts as $accounts ) {  ?>
                                                
                                                <option value="<?= $accounts->account_id;?>" required="required"><?= $accounts->account_name;?></option>
                                            
                                            <?php } ?>
                                                
                                        </select>
                                    </div>
                                    

                                    <div class="ln_solid"></div>

                                    <div class="form-group form-group-sm">

                                        <button type="submit" class="btn btn-success">Save</button>
                                        
                                    </div>

                                <?php echo Form::close(); ?>                                
                                
                            </div>
                        </div>
                        
                    </div>

                    <div class="no_padding col-md-8 col-sm-8 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Loan List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                <div class="table-responsive">                                    

                                    <table class="table table-align table-striped bulk_action table-responsive table-bordered">
                                        
                                        <?php 
                                            $value = count($loans);
                                        
                                            if ( $value !='') { ?>
                                                
                                                <thead>
                                                    <tr class="headings">
                                                        <th class="column-title text-center">ID </th>
                                                        <th class="column-title text-center">Description </th>
                                                        <th class="column-title text-center">Ammount</th>
                                                        <th class="column-title text-center">Refund</th>
                                                        <th class="column-title text-center">Account</th>
                                                        <th class="column-title text-center">Created By </th>
                                                        <th class="column-title text-center">Date</th>
                                                        <th class="column-title text-center">Actions</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    
                                                    <?php foreach ($loans as $loan) { ?>

                                                        <tr class="even pointer">

                                                            <td class="text-center"><?php echo e($loan->loan_id); ?></td>
                                                            <td class="text-center"><?php echo e($loan->loan_description); ?></td>
                                                            <td class="text-center"><?php echo e($loan->loan_ammount); ?></td>
                                                            
                                                            <?php 
                                                                $data = DB::table('refund_table')->where('loan_id', $loan->loan_id)->sum('refund_ammount');

                                                                $result = ($loan->loan_ammount) - $data;
                                                            ?>
                                                            
                                                            <?php 
                                                                if ( $data !='' ) { ?>

                                                                    <td class="text-center"><?= $result; ?> </td>

                                                                    <?php 
                                                                } else { ?>
                                                            
                                                                    <td class="text-center"> </td>  
                                                                    <?php
                                                                }
                                                            ?>
                                                            
                                                            <td class="text-center"><?php echo e($loan->account_name); ?></td>
                                                            <td class="text-center"><?php echo e($loan->admin_name); ?></td>
                                                            <td class="text-center"><?php echo e($loan->loan_created_date); ?> </td>

                                                            <td class="text-center">

                                                                <button
                                                                    class="btn btn-primary btn-xs refund"
                                                                    
                                                                    value="<?php echo e($loan->loan_id); ?>"
                                                                    refundAmmount="<?php echo e($result = ($loan->loan_ammount) - $data); ?>"

                                                                    ><i class="fa fa-edit"></i> Refund 
                                                                </button>

                                                                <button
                                                                    class="btn btn-info btn-xs view_refund"

                                                                    value="<?php echo e($loan->loan_id); ?>"
                                                                    ><i class="fas fa-eye"></i> View
                                                                </button>
                                                            </td>
                                                        </tr>

                                                        <?php
                                                    }
                                                    ?>
                                                    
                                                        
                                                </tbody>
                                            
                                                <?php 
                                            }
                                        ?>
                                    </table>
                                </div>
                            </div>

                            <div class=" pull-right">

                                <?php if( $loans != ''): ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/loan-list?page=1')); ?>">First</a> </li>
                                    </ul>

                                    <?php echo e($loans->links()); ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/loan-list?page='.$loans->lastPage())); ?>">Last</a> </li>
                                    </ul>

                                <?php endif; ?>

                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Add Refund loan -->
    <div style="z-index:9999999999" class="modal fade add_refund_modal" id="" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">
                <div class="modal-header">
                    
                    <h4 class="modal-title">Refund Loan <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>
                <div class="modal-body">
                
                    <?php echo Form::open(['url' => '/add-refund', 'method'=>'post']); ?>

                        
                        <div class="form-group form-group-sm">

                            <label for="due" style="padding-top: 10px;">Loan:</label>
                            <input type="text" class="refund form-control" value="" name="refund_ammount" placeholder="Loan Ammount" id="" disabled="">
                            
                            <input type="hidden" name="loan_id" class="loan_id" value="">
                            

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="account-name" style="padding-top: 10px;">Refund Loan Description </label>
                            <textarea class="form-control"  name="refund_note" required="required"></textarea>

                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label  class="control-label" for="payment" style="padding-top: 10px;">Refund Ammount:</label>
                            <input type="number" class="max_refund form-control" value="" name="refund_ammount" min="1" placeholder="Refund Ammount" />
                                                    
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="account-name" style="padding-top: 10px;"> Select Account </label>

                            <select id="" name="account_id" class="form-control active" required="required">
                                
                                <?php
                                    $accounts = DB::table('accounts')->get();
                                    
                                    foreach($accounts as $accounts ) {  ?>
                                    
                                        <option value="<?= $accounts->account_id;?>" required="required" ><?= $accounts->account_name;?></option>
                                
                                    <?php 
                                    }
                                ?>
                                    
                            </select>
                        </div>

                        <div class="form-group form-group-sm" style="margin-top: 20px;">
                            <button type="submit" class="btn btn-primary"  class="control-label">Add Payment</button>
                        </div>
                    <?php echo Form::close(); ?>

                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div> 


    <!-- Modal view loan-->
    <div style="z-index:9999999999" class="modal fade view_refund_modal" id="" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">
                <div class="modal-header">
                    
                    <h4 class="modal-title">View Refund <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">Date / Time</th>
                                    <th class="text-center">Create By</th>
                                    <th class="text-center">Account</th>
                                    <th class="text-center">Refund Description</th>
                                    <th class="text-center">Amount</th>
                                </tr>
                            </thead>
                            <tbody class="return_refund">
                                
                                
                                                                        
                            </tbody>
                        </table>
                    </div> 

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>