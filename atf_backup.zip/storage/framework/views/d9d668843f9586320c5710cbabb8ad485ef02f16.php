  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <div class="col-md-4 col-sm-12 col-xs-12">

                            <h3 class="no_padding bottom_padding"><i class="fa fa-money" aria-hidden="true"></i> Expenses </h3>

                        </div>

                        <!-- date Search list -->
                        <div class="col-md-8 col-sm-8 col-xs-12">

                            <div class="form-group form-inline pull-right">
                                <button type="button" class="date_from_to_expenses btn btn-success">Go!</button>
                            </div>

                            <div class="form-group form-inline pull-right">
                                <div class="input-group date no_margin">
                                    <input type="text" class="date_to datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                    <div class="input-group-addon">
                                        <span class="fa fa-calendar"></span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group form-inline pull-right no_margin">
                                <div class="input-group date no_margin">
                                    <input type="text" class="date_from datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                    <div class="input-group-addon">
                                        <span class="fa fa-calendar"></span>
                                    </div>
                                </div>
                            </div>

                            <div class="clearfix"></div>
                        </div>
                        <!-- /date Search list -->
                        
                    </div>

                    <!-- All Success Messages -->
                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                    

                    <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Expenses Head</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">        
                                
                                
                                <?php echo Form::open(['url' => '/save-expenses','method'=>'post']); ?>


                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="expenses-head">Expenses Head </label>

                                        <select id="" name="expenses_head_id" class="form-control active expenses_head" required="required">
                                            
                                            <?php 
                                                $expenses = DB::table('expenses_head')->get();

                                                foreach($expenses as $expenses ) {  ?>
                                                
                                                    <option value="<?= $expenses->expenses_head_id; ?>"  required="required"><?= $expenses->expenses_head_name;?></option>
                                            
                                                    <?php
                                                } 
                                            ?>
                                                
                                        </select>

                                    </div>


                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="expenses-sub-head-name">Expenses Sub Head </label>

                                        <select id="" name="expenses_sub_head_id" class="form-control search_results_expenses">
                                                
                                        </select>

                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="account-name">Account Name </label>

                                        <select id="" name="account_id" class="form-control active" required="required">
                                            
                                            <?php 
                                                $accounts = DB::table('accounts')->get();
                                                foreach($accounts as $accounts ) {  ?>
                                                
                                                <option value="<?= $accounts->account_id;?>" required="required"><?= $accounts->account_name;?></option>
                                            
                                            <?php } ?>
                                                
                                        </select>
                                    
                                    </div>     

                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="ammount"> Ammount </label>

                                        <input type="number" class="form-control" name="expenses_ammount" required="required">

                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="expenses_note">Note </label>
                                        <textarea class="form-control" name="expenses_note" required="required"></textarea>
                                        
                                    </div>

                                    <div class="ln_solid"></div>

                                    <div class="form-group form-group-sm">

                                        <button type="submit" class="btn btn-success">Save</button>
                                        
                                    </div>

                                <?php echo Form::close(); ?>                                
                                
                            </div>
                        </div>
                        
                    </div>

                    <div class="no_padding col-md-8 col-sm-8 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Expenses List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                <div class="table-responsive">                                    

                                    <table class="table table-align table-striped bulk_action table-responsive table-bordered">
                                        
                                        <?php $data = count($all_expenses); ?>
                                            
                                        <?php if( $data !='' ): ?>

                                            <thead>
                                                <tr class="headings">
                                                    <th class="column-title text-center">Date / Time </th>
                                                    <th class="column-title text-center">Ammount </th>
                                                    <th class="column-title text-center">Note </th>
                                                    <th class="column-title text-center">Head </th>
                                                    <th class="column-title text-center">Sub Head </th>
                                                    <th class="column-title text-center">Account Name </th>
                                                    <th class="column-title text-center">Created By </th>
                                                </tr>
                                            </thead>

                                            <tbody class="return_expenses">
                                                
                                                <?php $__currentLoopData = $all_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                                    <tr class="even pointer">

                                                        <td class="text-center"><?php echo e($expenses->expenses_created_date); ?> / <?php echo e($expenses->expenses_created_time); ?></td>
                                                        <td class="text-center"><?php echo e($expenses->expenses_ammount); ?></td>
                                                        <td class="text-center"><?php echo e($expenses->expenses_note); ?></td>
                                                        <td class="text-center"><?php echo e($expenses->expenses_head_name); ?></td>
                                                        <td class="text-center"><?php echo e($expenses->expenses_sub_head_name); ?></td>
                                                        <td class="text-center"><?php echo e($expenses->account_name); ?></td>
                                                        <td class="text-center"><?php echo e($expenses->admin_name); ?></td>
                                                        
                                                    </tr>

                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                                
                                                    
                                            </tbody>
                                            
                                        <?php endif; ?>

                                    </table>
                                </div>
                            </div>

                            <div class=" pull-right">

                                <?php if( $all_expenses != ''): ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/expenses-list?page=1')); ?>">First</a> </li>
                                    </ul>

                                    <?php echo e($all_expenses->links()); ?>

                                    
                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/expenses-list?page='.$all_expenses->lastPage())); ?>">Last</a> </li>
                                    </ul>

                                <?php endif; ?>

                            </div>

                            
                        </div>                        
                    </div>

                    
                </div>
            </div>
        </div>
    </div>


    <!-- Edit Expenses head Modal -->
    <div style="z-index:9999999999" class="modal fade edit_expenses_head_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Edit Expenses Head <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-expenses-head', 'method'=>'post']); ?>


                        <div class="form-group form-group-sm">
                            <label class="control-label" > ID </label>
                            <input type="text" id="" class="form-control expenses_head_id" value="" disabled>
                            <input type="hidden" id=""  name="expenses_head_id" value="" class="form-control expenses_head_id">
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label"> Expenses Head Name </label>
                            <input type="text"  name="expenses_head_name" value="" required="required" class="form-control expenses_head_name ">

                        </div>
                        

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">

                            <button type="submit" class="btn btn-primary">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>

                
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    <!-- Edit Expenses Sub haad Modal -->
    <div style="z-index:9999999999" class="modal fade edit_expenses_sub_head_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Edit Expenses Sub Head <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-expenses-sub-head', 'method'=>'post']); ?>


                        <div class="form-group form-group-sm">
                            <label class="control-label" > ID </label>
                            <input type="text" id="" class="form-control expenses_sub_head_id" value="" disabled>
                            <input type="hidden" id=""  name="expenses_sub_head_id" value="" class="form-control expenses_sub_head_id">
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label"> Expenses Head Name </label>
                            <input type="text"  name="expenses_sub_head_name" value="" required="required" class="form-control expenses_sub_head_name ">

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="account-name">Expenses Head Name </label>

                            <select id="" name="expenses_head_id" class="form-control active" required="required">
                                
                                <option class="expansesHeadId" value="" ></option>
                                
                                <?php

                                    $expenses = DB::table('expenses_head')->get();
                                    foreach($expenses as $expenses ) {  ?>
                                        
                                        <option value="<?= $expenses->expenses_head_id;?>" required="required"><?= $expenses->expenses_head_name;?></option>
                                
                                        <?php 
                                    } 
                                ?>
                                    
                            </select>
                        
                        </div>
                        

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">

                            <button type="submit" class="btn btn-primary">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>

                
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>