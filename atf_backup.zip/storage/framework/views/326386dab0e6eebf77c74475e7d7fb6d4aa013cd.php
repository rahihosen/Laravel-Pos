  
<?php $__env->startSection('admin_main_content'); ?>
    
    <div class="right_col right_col_back" role="main">
    
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="box_layout col-md-12 col-sm-12 col-xs-12">

                    <div class="col-md-4 col-sm-12 col-xs-12">
                        <h3 class="no_padding"><i class="fa fa-shopping-bag"></i> Order Reports </h3>
                    </div>

                    <!-- date Search list -->
                    <div class="col-md-8 col-sm-8 col-xs-12">

                        <div class="form-group form-inline pull-right">
                            <button type="button" class="date_from_to_order_reports btn btn-success">Go!</button>
                        </div>

                        <div class="form-group form-inline pull-right">
                            <div class="input-group date no_margin">
                                <input type="text" class="date_to datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group form-inline pull-right no_margin">
                            <div class="input-group date no_margin">
                                <input type="text" class="date_from datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                <div class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="clearfix"></div>
                    </div>
                    <!-- /date Search list -->

                    
                    
                    
                </div>

                <!-- Flash Messages -->
                <?php 

                    $message = Session::get('message');

                    if ( $message !='') { ?>

                        <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                            <h5 class="text-center">

                                <?php

                                    if(isset($message)) { ?>

                                        <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <strong> <?php echo $message;?> </strong>
                                        </div>
                                        
                                    <?php
                                        Session::put('message','');
                                    }
                                ?>

                            </h5>
                        </div> 
                        
                        <?php 
                    }
                    
                ?>

                
                <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">
                    <div class="panel panel-amin">
                        <div class="panel-heading">
                            <h3 class="panel-title">Order Reports</h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">

                            <div class="table-responsive">
                                <table class="table table-striped bulk_action table-responsive table-bordered">
                                    <thead>
                                        <tr class="headings">
                                            
                                            <th class="column-title text-center"> Date </th>
                                            <th class="column-title text-center"> Total Order </th>
                                            <th class="column-title text-center"> Total Ammount </th>
                                            <th class="column-title text-center"> Total Received </th>
                                            <th class="column-title text-center"> Total Due </th>
                                            <th class="column-title text-center"> Total Cancelled Orders </th>
                                            <th class="column-title text-center"> Total Cancelled Ammount </th>
                                            <th class="column-title text-center"> Action </th>

                                        </tr>
                                    </thead>

                                    <tbody class="return_order_reports">
                                        
                                        <?php $__currentLoopData = $orders_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php $date = $orders->order_created_date; ?>

                                            <?php $orderId = DB::table('order')->where('order_id', $date)->where('order_status', 1)->get(); ?>
                                            
                                            <tr class="even pointer">
                                                
                                                <td class="text-center"><?php echo e($orders->order_created_date); ?></td>
                                                <td class="text-center">

                                                    <?= $total = DB::table('order')->where('order_created_date', $date)->where('order_status', 1)->count('order_id'); ?>

                                                </td>
                                                
                                                <td class="text-center"> 

                                                    <?= $active_data = DB::table('order')->where('order_created_date', $date)->where('order_status', 1)->sum('total_amount_payable'); ?>

                                                </td>
                                                
                                                <td class="text-center">

                                                    <?= $total = DB::table('order')
                                                                ->join('pament_details','order.order_id','=','pament_details.order_id', 'left')
                                                                ->where('order_created_date', $date)
                                                                ->where('order_status', 1)
                                                                ->sum('amount'); ?>
                                                </td>

                                                <td class="text-center">
                                                
                                                    <?= $result = $active_data - $total; ?>

                                                </td>

                                                <td class="text-center">
                                                    <?php
                                                        $total = DB::table('order')->where('order_created_date', $date)->where('order_status', 0)->count('order_id');
                                                        echo $total;
                                                    ?>
                                                </td>

                                                <td class="text-center"> 
                                                    <?= $inactive_data = DB::table('order')->where('order_created_date', $date)->where('order_status', 0)->sum('total_amount_payable'); ?>
                                                </td>   
                                                
                                                <td class="last text-center">
                                                    
                                                    <button 
                                                        class="btn btn-info btn-xs view_order_report"
                                                        value="<?php echo e($date); ?>" 
                                                        ><i class="glyphicon glyphicon-eye-open "></i> View Orders
                                                    </button>

                                                    <button 
                                                        class="btn btn-primary btn-xs view_cancelled_order" 
                                                        value="<?php echo e($date); ?>" 
                                                        ><i class="glyphicon glyphicon-eye-open"></i> View Cancelled Orders
                                                    </button>

                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                            
                        <!-- <div class="hide_pagi pull-right">
                            
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="">First</a> </li>
                                </ul>

                                

                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link" href="">Last</a> </li>
                                </ul>
                           
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal View Order's Report's -->
    <div style="z-index:9999999999" class="modal fade view_order_report_modal" id="" role="dialog">
        <div class="modal-dialog modal-lg"style="width: 105em;">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">View Order Report <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body" id="customer_details">
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>                                    
                                    <th class="text-center"> Date / Time</th>
                                    <th class="text-center"> Added By</th>
                                    <th class="text-center"> Table Number</th>
                                    <th class="text-center"> Order Id</th>
                                    <th class="text-center"> Order Total</th>
                                    <th class="text-center"> Discount</th>
                                    <th class="text-center"> After Discount</th>
                                    <th class="text-center"> Vat</th>
                                    <th class="text-center"> Amount Payable</th>
                                    <th class="text-center"> Paid</th>
                                    <th class="text-center"> Due</th>
                                    <th class="text-center"> Payment</th>
                                    <th class="text-center"> Action</th>
                                </tr>
                            </thead>
                            <tbody class="return_results">
                                
                                
                                                                        
                            </tbody>
                        </table>
                    </div> 

                </div>
                <div class="modal-footer">
                    <button type="button" class="print_customer_details btn btn-default" style="float: left;">Print</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    <!-- Modal View Cancelled Order's Report's -->
    <div style="z-index:9999999999" class="modal fade view_cancelled_order_report_modal" id="" role="dialog">
        <div class="modal-dialog modal-md"style="width: 105em;">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">View Cancelled Order Report <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                        <thead>
                                <tr>                                    
                                    <th class="text-center"> Date / Time</th>
                                    <th class="text-center"> Added By</th>
                                    <th class="text-center"> Table Number</th>
                                    <th class="text-center"> Order Id</th>
                                    <th class="text-center"> Order Total</th>
                                    <th class="text-center"> Discount</th>
                                    <th class="text-center"> After Discount</th>
                                    <th class="text-center"> Vat</th>
                                    <th class="text-center"> Amount Payable</th>
                                    <th class="text-center"> Paid</th>
                                    <th class="text-center"> Due</th>
                                    <th class="text-center"> Payment</th>
                                    <th class="text-center"> Action</th>
                                </tr>
                            </thead>
                            <tbody class="return_results">
                                
                                
                                                                        
                            </tbody>
                        </table>
                    </div> 

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    <!-- Modal Add due Payment for report's-->
    <div style="z-index:9999999999" class="modal fade add_payment_order_report_modal" id="" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">
                <div class="modal-header">
                    
                    <h4 class="modal-title">Add Payment <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>
                <div class="modal-body">
                
                    <?php echo Form::open(['url' => '/add-payment-order-report', 'method'=>'post']); ?>

                        
                        <div class="form-group form-group-sm">

                            <input type="hidden" name="order_id" class="order_id" value="">
                            <label for="due">Due:</label>
                            <input type="text" class="amount form-control" value="" name="amount" placeholder="Due" id="amount" disabled="">
                                                    
                        </div>

                        <div class="form-group form-group-sm">
                        
                            <label for="payment">Add Payment:</label>
                            <input type="number" class="due_payment form-control" value="" name="order_payment" min="1" placeholder="Payment" id="table-name" >
                                                    
                        </div>                    
                        
                        <button type="submit" class="btn btn-primary">Add Payment</button>
                    <?php echo Form::close(); ?>

                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>

    <!-- Modal view Payment report's-->
    <div style="z-index:9999999999" class="modal fade view_payment_modal" id="" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">
                <div class="modal-header">
                    
                    <h4 class="modal-title">View Payment <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">Date / Time</th>
                                    <th class="text-center">Create By</th>
                                    <th class="text-center">Amount</th>
                                </tr>
                            </thead>
                            <tbody class="return_due">
                                
                                
                                                                        
                            </tbody>
                        </table>
                    </div> 

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div> 


    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>