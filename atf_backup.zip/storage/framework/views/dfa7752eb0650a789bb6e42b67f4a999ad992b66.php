  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->

<div class="right_col right_col_back" role="main">

    <div class="">
        <div class="clearfix"></div>
        <div class="row">
		
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				
				<div class="box_layout col-md-12 col-sm-12 col-xs-12">

					<h3 class="no_padding"><i class="fa fa-plus"></i> New Order</h3>

				</div>
				<?php 

					$message = Session::get('message');

					if ( $message !='') { ?>

						<div class="no_padding col-md-12 col-sm-12 col-xs-12">

							<h5 class="text-center">

								<?php

									if(isset($message)) { ?>

										<div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
											<strong> <?php echo $message;?> </strong>
										</div>
										
									<?php
										Session::put('message','');
									}
								?>

							</h5>
						</div> 
						
						<?php 
					}
					
				?>
				
				<?php 

					$message = Session::get('error');

					if ( $message !='') { ?>

						<div class="no_padding col-md-12 col-sm-12 col-xs-12">

							<h5 class="text-center">

								<?php

									if(isset($message)) { ?>

										<div class="alert alert-danger alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
											<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
											<strong> <?php echo $message;?> </strong>
										</div>
										
									<?php
										Session::put('error','');
									}
								?>

							</h5>
						</div> 
						
						<?php 
					}
					
				?>

			
                <div class="x_panel">   
				
                    <div class="x_content">
                        
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12" style="padding-top:10px; background:#8d8d8d;height:945px;overflow-y:scroll;">
						
                            <p class="cat_list_tag cat_list_tag_active" data-cat-id="all" data-cat-name="ALL ITEMS">All Generics</p>
							
                            <?php $__currentLoopData = $all_cat_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_cat_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
                                <p data-cat-id="<?php echo e($all_cat_info->category_id); ?>" data-cat-name="<?php echo e($all_cat_info->category_name); ?>" class="cat_list_tag" ><?php echo e($all_cat_info->category_name); ?></p>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
						
                        <div class="col-lg-5 col-md-4 col-sm-3 col-xs-12" style="background:#e1e1e1;height:945px;overflow-y:scroll;">

                            <h4 class="show_pro_small_cat" style="padding:7px;text-align:center;margin:10px 0 0 0;">ALL ITEMS</h4>
							
							<input type="text" class="search_sales_pro form-control" placeholder="Search..." style="margin:10px 0;">
                           
                            <div class="table-responsive show_pro_all">
							
                                <?php $__currentLoopData = $all_product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                    <div class="col-md-4 col-sm-12 col-xs-6 product_block" align="center">
                                        
                                        <a style="cursor:pointer;position:relative;" class="add_cart" data-productid="<?php echo e($products->product_id); ?>">
											
											<img src="<?php echo e($products->product_image); ?>" class="img-thumbnail" style="height:70px; width:100px;"/>
											<span class="type_name_show"><?php echo e($products->type_name); ?></span>
											
                                        </a>
										
										<br>
                                        
                                        <h4 style="padding:5px 0 0 0;margin:0;"><a style="cursor:pointer;" class="add_cart" data-productid="<?php echo e($products->product_id); ?>"><?php echo e($products->product_name); ?></a></h4>
										
										<div class="purchase_prc_div">
										
											<label>P. Prc:</label>
											
											<?php
											
												$purchase_prc = DB::table('purchase_details')->where('product_id',$products->product_id)->get(); 
												
												
												
											?>
											
											<select class="pro_prc_select pur_pro_id_<?php echo e($products->product_id); ?>">
											
												
											<?php 
											
											$pages_printed = array();
											
											foreach($purchase_prc as $purchase_prc){
												
												$pprice = $purchase_prc->product_purchase_price.'';
												
												if (!isset($pages_printed[$pprice])) {
													$pages_printed[$pprice] = true;	
											
											?>
												<option value="<?php echo e($pprice); ?>"><?php echo e($pprice); ?></option>
												
											<?php }} ?>
												
												
												<option value="0">0.00</option>
											</select>
											
											<p><b>In Stock:</b> 
											
											<?php 
												$total = DB::table('stock')->where('product_id', $products->product_id)->sum('stock_quantity');
												
												$total2 = DB::table('wastage')->where('product_id', $products->product_id)->sum('wastage_quantity');

												$total3 = DB::table('order_details')->where('product_id', $products->product_id)->where('order_details_status', 1)->sum('product_qty');
												
												$result = ($total - $total2 - $total3);

												echo $result;
											?>
											
											</p>
											
										</div>
                                    </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            
                        </div>
                        
                        <div class="no_padding col-lg-5 col-md-6 col-sm-7 col-xs-12 payment_board" >
                            <div style="padding:10px 0 10px 15px;" class="res_marginTP15 res_no_padding" id="cart_details">
                                
                                <?php 
                                    $data=Cart::content();
                                ?>
								
								<div class="table-responsive">

									<table id="cart" class="table table-responsive">
										<thead>
											<tr class="text-center" style="background:#023264;color:#fff;">
												<!--<th class="text-center">Image</th>-->
												<th class="text-center">Name</th>
												<th class="text-center">P.Prc</th>
												<th class="text-center">Prc</th>
												<th class="text-center">Quantity</th>
												<th class="text-center">Total</th>
												<th class="text-center">Del</th>
											</tr>
										</thead>
						
										<tbody class="cart_list_table">
											<?php if(Cart::count() != "0"): ?>
												
												<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

													<tr class="rem_row_<?php echo e($products->rowId); ?>">
														<!--<td>
															<img src="<?php echo e($products->options['image']); ?>" alt="Product Image" width="50px" height='40px'/>
														</td>-->
														<td><h5><?php echo e($products->name); ?></h5></td>
														<td><?php echo e($products->options['purchase_prc']); ?></td>
														<td><?php echo e($products->price); ?></td>
														<td>
															<div style="width:95px;" class="q_input_fields">
																<button onclick ="minusFunction('product_id_<?php echo e($products->rowId); ?>','<?php echo e($products->price); ?>')" class="q_minus"><i class="fa fa-minus"></i></button><input value="<?php echo e($products->qty); ?>" class="product_id_<?php echo e($products->rowId); ?> q_input" type="text" data-rID="<?php echo e($products->rowId); ?>" data-prc="<?php echo e($products->price); ?>" ><button onclick ="plusFunction('product_id_<?php echo e($products->rowId); ?>','<?php echo e($products->price); ?>')" class="q_plus"><i class="fa fa-plus"></i></button>
															</div>
														</td>
														
														<td class="shwTotal_<?php echo e($products->rowId); ?> text-center"><?php echo e($products->price*$products->qty); ?>

														</td>

														<td class="actions">	
															<button type="button" onclick="removeFunction('<?php echo $products->rowId; ?>')" class="btn btn-danger btn-xs"><i class="fa fa-remove"></i></button>
														</td>
														
													</tr>
													
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<tr>
													<td colspan="6">
														<h2>Cart is Empty!</h2>
													</td>
												</tr>
											<?php endif; ?>   
											
										</tbody>
									</table>
								
								</div>
				
                                <?php echo Form::open(['url'=>'/save-order','method'=>'post']); ?>

								
                                    <table class="table">
                            
                                        <tr>
                                            <td colspan="2">
                                                <h3 data-total-dis="<?php echo e(Cart::total()); ?>" class="get_total_for_dis text-right">Total TK.  <?php echo e(Cart::total()); ?></h3>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>Discount:</b>
											</td>
											<td class="form-group-sm" style="position:relative;">
											
                                                <input type="text" pattern="^(0|[1-9][0-9]*)$" title="Numbers only" value="0" class="discount_input form-control" name="order_discount" required>
												
												<select name="order_discount_type" class="order_discount_type form-control">
													
													<option value="1">৳</option>
													<option value="2">%</option>
													
                                                </select>
												
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>After Discount: </b>
											</td>
											<td class="form-group-sm">
                                                <input type="text" class="after_discount_input form-control" disabled>
                                                <input type="hidden" name="after_discount" class="after_discount_input form-control">
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>Vat: </b>
											</td>
											<td class="form-group-sm">
                                                <select id="" name="order_vat" class="vat_input form-control">                                                

                                                    <?php  $vat = DB::table('vat')->where('vat_status', 1)->get(); ?>

                                                    <?php $__currentLoopData = $vat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($vat->vat_amount); ?>"><?php echo e($vat->vat_name); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>Ammount Payable: </b>
											</td>
											<td class="form-group-sm">
                                                <input type="text" class="after_vat_input form-control" disabled>
                                                <input type="hidden" name="total_amount_payable" class="after_vat_input form-control">
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>Ammount Received: </b>
											</td>
											<td class="form-group-sm">
                                                <input type="text" pattern="(^[0-9]{1,11})+(\.[0-9]{0,2})?" title="Numbers only" name="amount_received" placeholder="Ammount Received" class="ammount_received form-control" required>
                                            </td>
                                        </tr>
										
										<tr>
                                            <td style="text-align:right;"><b>Transaction No: </b>
											</td>
											<td class="form-group-sm">
                                                <input type="text" name="transaction_no" placeholder="Transaction No" class="form-control">
                                            </td>
                                        </tr>
										
                                        <tr>
                                            <td style="text-align:right;"><b>Select Account: </b>
											</td>
											<td class="form-group-sm">
                                                <select class='form-control' name="account_id" required>
                                            
													<?php 
														$accounts = DB::table('accounts')->get();
														foreach($accounts as $accounts ) {  ?>
														
														<option value="<?= $accounts->account_id;?>"><?= $accounts->account_name;?></option>
													
													<?php } ?>
													
												</select>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>Ammount Return: </b>
											</td>
											<td class="form-group-sm">
                                            <input type="text" placeholder="Ammount Return" class="ammount_return form-control" disabled>
                                            <input name="amount_return" type="hidden" class="ammount_return form-control"></td>
                                        </tr>

                                        <tr>
                                            <td style="text-align:right;"><b>Due: </b>
											</td>
											<td class="form-group-sm">
                                            <input type="text" placeholder="Due" class="ammount_due form-control" disabled>
                                            <input name="amount_due" type="hidden" class="ammount_due form-control"> </td>
                                        </tr>

                                    </table>

                                    <!--<label for="inputCity">Order Type:</label>

									<select name="order_type" class="form-control" >
										<option value="1">Non Parcel</option>
										<option value="2">Parcel</option>
									</select>-->
									
                                    <br>

                                    <!--<label for="inputCity">Table Number:</label>
                                            
                                        <div style="height:150px;overflow-y:scroll;border:1px solid lightgray;padding:15px;" class="checkbox">
                                            
                                            <?php $__currentLoopData = $all_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                                <label style="width:50%;float:left;font-size:13px;">
                                                    <input type="checkbox" name="fk_table_id[]" value="<?= $all_table->table_id; ?>"> <?= $all_table->table_name; ?>
                                                </label>	
                                                    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <span style="clear:both;"></span>
                                        </div>-->
                                    <br/>

                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                    
                                        <label for="cus_1"><input id="cus_1" type="radio" class="check_cust" name="default_customer" value="1" checked> Default &nbsp;&nbsp;</label>
                                        
                                        <label for="cus_2"><input id="cus_2" type="radio" class="check_cust" name="default_customer" value="2"> Add Customer &nbsp;&nbsp;</label>

                                        <label for="cus_3"><input id="cus_3" type="radio" class="check_cust" name="default_customer" value="3"> Exist Customer </label>                     
                                    
                                    </div>

                                    <div><br></div>
                    
                                    <div style="display:none;" class="collapse_hide form-group-sm">
									
                                        <label for="Name">Customer Name:</label>
                                        <input type="text" name="customer_names" class="form-control" placeholder="Name" id="Name">
										
                                        <br>
                                        <label for="Mobile">Customer Mobile:</label>
                                        <input type="text" name="customer_mobile" class="form-control" placeholder="Mobile" id="Mobile">
										
                                        <br>
                                        <label for="Email">Customer E-mail:</label>
                                        <input type="email" name="customer_email" class="form-control" placeholder="E-mail" id="Email">
										<br>
										<label for="Customer-nid">Customer NID</label>
										
                                        <input type="text" id="Customer-nid" name="customer_nid" placeholder="Customer NID" class="form-control">
										
                                        <br>
										
                                        <label for="Group">Customer Group:</label>

                                        <select id="Group" name="customer_group_id" class="form-control">
                                        
                                            <?php 
                                                $cusromer_group = DB::table('customer_group')->get();
                                                foreach($cusromer_group as $cusromer_group ) {  ?>
                                                
                                                <option value="<?= $cusromer_group->group_id;?>"><?= $cusromer_group->group_name;?></option>
                                            
                                            <?php } ?>
                                            
                                        </select>
                                    
                                    </div>
									
                                    <br>

                                    <div style="display:none;" class="collapse_hide_exist">

                                        <label for="exist_cus">Customer:</label>
										
                                        <select id="exist_cus" name="customer_name" class="form-control">
										
											<option value="1" disabled selected>Away Customer (Default Customer)</option>

                                            <?php  $customer = DB::table('customer')->where('customer_id', '!=', 1 )->get();
											
											
                                            
                                            foreach ( $customer as $customer ){
												
												$order_payable = DB::table('order')->where('customer_id', $customer->customer_id)->SUM('total_amount_payable');
												
												$orderr = DB::table('order')->where('customer_id', $customer->customer_id)->get();
												
												$paid = 0;
												
												foreach($orderr as $orderr){
													
													$paid += DB::table('pament_details')->where('order_id', $orderr->order_id)->sum('amount');
													
												}
												
												
												$customer_due = $order_payable - $paid;
												
												if($customer_due > $customer->credit_limit){
													
													$dis = 'disabled';
													$limit_reached = ' (Limit Reached)';
													
												}else{
													$dis = '';
													$limit_reached = '';
												}
												
											?>

                                                <option value="<?php echo e($customer->customer_id); ?>" <?php echo e($dis); ?>><?php echo e($customer->customer_name.$limit_reached); ?></option>

                                            <?php }?>

                                        </select>
										
                                        <br>                                        
                                    
                                    </div>
                                    <br>

                                    <div style="margin:0 auto; width:212px;" >
                                        <button type="submit" name="save_or_print" value="1" class="btn btn-primary">Save Order</button>

                                        <button type="submit" name="save_or_print" value="2" class="btn btn-success">Save & Print</button>
                                    </div>

                                <?php echo Form::close(); ?>


                                <br>

                                <?php echo Form::open(['url'=>'/destoryCart','method'=>'POST']); ?>


                                    <button type="submit" style="margin:0 auto; width:100px;" class="btn btn-block btn-danger">Clear All</button> 

                                <?php echo Form::close(); ?>

								
                            </div>
                        </div>

                    </div>
                </div>
            </div>           
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>