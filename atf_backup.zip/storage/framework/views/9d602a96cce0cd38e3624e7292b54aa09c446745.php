  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->

          
                         
                         
<div class="right_col" role="main">             
                         
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        
                        
                       
                        <div class="col-lg-7 col-md-7">
                            
                            <div class="row">
                               ccc
                            </div>
                            
                            <hr>
                             <div class="row">
                             
                                
                                
                                      <?php $__currentLoopData = $sales_product_show1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                              <div class="col-md-3" style="padding:16px; background-color:#fff; border:1px solid #ccc; margin-bottom:6px; height:140px" align="center">
                                  <a href=""type="submit" name="add_cart" class="btn-xs add_cart" data-productid="<?php echo e($products->product_id); ?>" />
                                <img src="<?php echo e($products->product_image); ?>" class="img-thumbnail" style="height:70px; width:100px;"/><br />
                               <h4><?php echo e($products->product_name); ?></h4>
                              <!-- <h3 class="text-danger">Tk.<?php echo e($products->product_sale_price); ?></h3>-->
                              <!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">-->
                              
                              </a>
                  
                              </div>
    
                             
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </div>
                            
                    
                            
                            
                            
                        </div>
                        
                        <div class="col-lg-5 col-md-5">
                            <div id="cart_details">
                                 
                                <h3 align="center">Cart Details</h3>
                               
                                
                                
                                <?php 
                        $data=Cart::content();
                        ?>
                         <table id="cart" class="table table-hover table-condensed">
    				<thead>
						<tr>
							<th>Image</th>
                                                        <th style="width:100%">Name</th>
							<th>Price</th>
							<th>Quantity</th>
							<th class="text-center">Subtotal</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
                                           <?php if(Cart::count() != "0"): ?> 
                                       
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td data-th="Product">
                                                            <img src="<?php echo e($products->options['image']); ?>" alt="Product Image" width="50"/>
							</td>
                                                        <td data-th="Name"><h4 class="nomargin"><?php echo e($products->name); ?></h4></td>
							<td data-th="Price">Tk.<?php echo e($products->price); ?></td>
                                                        
							<td data-th="Quantity">              
                                                            <input type="number" min="1" max="50" class="form-control text-center" value="<?php echo e($products->qty); ?>" id="upCart<?php echo e($products->id); ?>">
                                                            <input type="hidden" class="form-control text-center" value="<?php echo e($products->rowId); ?>" id="rowId<?php echo e($products->id); ?>">
							</td>
                                                        
							<td data-th="Subtotal" class="text-center"><?php echo e($products->price*$products->qty); ?></td>
							<td class="actions" data-th="">	
                                                            <a href="<?php echo e(url('cart/remove/'.$products->rowId)); ?>" class="btn btn-danger btn-xs"><i class="fa fa-remove"></i></a>								
							</td>
						</tr>
                                                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php else: ?>
                                        <tr>
                                          <td>
                                              <h2>Cart is Empty!</h2>
					   </td>
                                        </tr>
                                        <?php endif; ?>   
					</tbody>
                                        <tfoot>
                                            <tr>
                                               
                                                    <strong>Total TK. <?php echo e(Cart::total()); ?></strong>
                                                
                                                
                                            </tr>
                                        </tfoot>
				</table>
                                
                                
                                
                                             
                                                    <?php echo Form::open(['url'=>'/save-order','method'=>'post']); ?>

                                                    <!--<a href="<?php echo e(URL::to('save-order')); ?>" class="btn btn-success btn-block"> Save Order <i class="fa fa-angle-right"></i></a>-->
                                                    
                                                    
                                                    
                                                     <label for="inputCity">Customer Name:</label>
                                                      <input type="text" name="customer_name" class="form-control" id="inputCity">
                                                      
                                                      <label for="inputCity">Customer Mobile:</label>
                                                      <input type="text" name="customer_mobile" class="form-control" id="inputCity">
                                                    
                                                      <label for="inputCity">Customer Email:</label>
                                                      <input type="text" name="customer_email" class="form-control" id="inputCity">
                                                 
                                                    <br>
                                                    <button type="submit" class="btn btn-success pull-right">Save Order</button>
                                                    
                                                    <?php echo Form::close(); ?>

                                                
                                                    <?php echo Form::open(['url'=>'/destoryCart','method'=>'POST']); ?>              
                                                    <button type="submit" class="btn btn-warning pull-left">Clear All</button>                                
                                                    <?php echo Form::close(); ?>

                                                    
                                                    
                            </div>
                        </div>
                        
                     

                    </div>
                </div>
            </div>
            
           
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>