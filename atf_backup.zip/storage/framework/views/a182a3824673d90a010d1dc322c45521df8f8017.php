  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <h3 class="no_padding bottom_padding"><i class="fas fa-user-tag"></i> Buyer </h3>
                        
                    </div>


                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                    

                    <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Add Buyer</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">        
                                
                                
                                <?php echo Form::open(['url' => '/save-buyer', 'method'=>'post']); ?>

                                
                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="buyer-name">Buyer Name </label>
                                        <input type="text" id="buyer-name" name="buyer_name" required="required" class="form-control">
                                        
                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="buyer-mobile">Buyer Mobile</label>
                                        <input type="number" id="" name="buyer_mobile" required="required" class="form-control ">
                                        
                                    </div>
                                    
                                    <div class="form-group form-group-sm">

                                        <label class="control-label " for="buyer-email" style="padding-top: 10px;">Buyer Email </label>
                                        <input type="email" name="buyer_email" required="required" class="form-control ">
                                        
                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label " for="buyer-address" style="padding-top: 10px;">Buyer Address </label>
                                        <textarea type="text" name="buyer_address" required="required" class="form-control "></textarea>
                                        
                                    </div>

                                    <div class="ln_solid"></div>

                                    <div class="form-group form-group-sm">
                                        
                                        <button type="submit" class="btn btn-success">Save</button>
                                        
                                    </div>

                                <?php echo Form::close(); ?>                                
                                
                            </div>
                        </div>
                    </div>

                    <div class="no_padding col-md-8 col-sm-8 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Buyer List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                <div class="table-responsive"> 
                                    
                                    <input type="text" class="search_buyer form-control" placeholder="Search..." style="border-color: #023264;border-radius: 3px;">
                                    <div><br></div>

                                    <p class="search_key" type="hidden"></p>

                                    <table class="table table-striped bulk_action table-responsive table-bordered table-align">

                                        <?php

                                             ?>

                                                <thead>
                                                    <tr class="headings">
                                                        <th class="column-title text-center">ID </th>
                                                        <th class="column-title text-center">Name </th>
                                                        <th class="column-title text-center">Moile </th>
                                                        <th class="column-title text-center">Email </th>
                                                        <th class="column-title text-center">Address </th>
                                                        <th class="column-title text-center">Created By </th>
                                                        <th class="column-title text-center">Created Date / Time</th>
                                                        <th class="column-title text-center">Updated By </th>
                                                        <th class="column-title text-center">Update Date / Time</th>
                                                        <th class="column-title text-center"> Action </th>
                                                    </tr>
                                                </thead>

                                                <tbody class="search_buyer_results">
                                                    
                                                    <?php foreach($all_buyers as $buyers) { ?>

                                                        <tr class="even pointer">
                                                            <td class="text-center"><?php echo e($buyers->bid); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->bname); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->bmobile); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->bemail); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->baddress); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->created_admin_name); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->bcreated_date); ?> / <?php echo e($buyers->bcreated_time); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->updated_admin_name); ?></td>
                                                            <td class="text-center"><?php echo e($buyers->bupdated_date); ?> / <?php echo e($buyers->bupdated_time); ?></td>
                                                            
                                                            
                                                            <td class="text-center">

                                                                <button
                                                                    class="btn btn-dark btn-xs edit_buyer"

                                                                    value="<?php echo e($buyers->bid); ?>"
                                                                    buyerName="<?php echo e($buyers->bname); ?>"
                                                                    buyerMobile="<?php echo e($buyers->bmobile); ?>"
                                                                    buyerEmail="<?php echo e($buyers->bemail); ?>"
                                                                    buyerAddress="<?php echo e($buyers->baddress); ?>"

                                                                    ><i class="fas fa-pencil-alt"></i> Edit
                                                                
                                                                </button>
                                                                
                                                            </td>
                                                        </tr>

                                                        <?php
                                                    }
                                                    ?>
                                                    
                                                        
                                                </tbody>

                                                <?php 
                                            
                                        ?>
                                                
                                    </table>
                                    
                                </div>
                            </div>

                            

                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Edit Buyer Modal -->
    <div style="z-index:9999999999" class="modal fade edit_buyer_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Edit Buyer <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-buyer', 'method'=>'post']); ?>


                        <div class="form-group form-group-sm">
                            <label class="control-label" > ID </label>
                            <input type="text" id="buyer-id" class="form-control buyer_id" value="" disabled>
                            <input type="hidden" id=""  name="buyer_id" value="" class=" buyer_id">
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="buyer-name"> Buyer Name </label>
                            <input type="text"  name="buyer_name" value="" required="required" class="form-control buyer_name">

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="buyer-mobile">Buyer Mobile</label>
                            <input type="number" id="" name="buyer_mobile" required="required" class="form-control buyer_mobile">
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="buyer-email">Buyer Email</label>
                            <input type="email" id="" name="buyer_email" required="required" class="form-control buyer_email">
                            
                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label " for="buyer-address" style="padding-top: 10px;">Buyer Address </label>
                            <textarea type="text" name="buyer_address" required="required" class="form-control buyer_address"></textarea>
                            
                        </div>

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">
                           
                            <button type="submit" class="btn btn-success">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>

                
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>