<?php if(session()->has('msg')): ?>
    <div><br/></div>
    <div class="alert alert-success alert-dismissible fade in">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong><?php echo e(session()->get('msg')); ?></strong> 
    </div>
<?php endif; ?>