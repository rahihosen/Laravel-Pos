  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col right_col_back" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                
                <div class="box_layout col-md-12 col-sm-12 col-xs-12">

                    <h3 class="no_padding bottom_padding"><i class="glyphicon glyphicon-plus"></i> Add Item  </h3>

                    <h5 class="text-center" style="color:green;">

                        <?php
                            $message=Session::get('message');

                            if(isset($message)) {
                                echo $message;
                                Session::put('message','');
                            }
                        ?>

                    </h5>

                </div>                    

                <div class="no_padding right_padding col-md-6 col-sm-6 col-xs-12">				
                    
                    <div class="panel panel-amin">

                        <div class="panel-heading">
                            <h3 class="panel-title">Add Item Description </h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">        
                            
                            <?php echo Form::open(['url' => '/save-product','method'=>'post','enctype'=>'multipart/form-data']); ?>

                        
                                <div class="form-group">

                                    <label class="control-label" for="last-name"> Name </label>
                                    <input type="text" id="last-name" name="product_name" required="required" class="form-control">
                                    
                                </div>
                                
                                <div class="form-group">

                                    <label class="control-label" for="cat-name"> Category</label>
                                    <select id="cat-name" name="fk_category_id" class="form-control" required="required">
                                        
                                        <?php $__currentLoopData = $published_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->category_id); ?>" required="required"><?php echo e($category->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                    
                                </div>
                                
                                <div class="form-group">

                                    <label class="control-label" for="product-image"> Image </label>
                                    <input type="file" id="product-image" name="product_image" required="required" class="form-control">

                                    <div><br></div>
                                    
                                </div> 

                        </div>

                    </div>
                </div>

                
                <div class="no_padding col-md-6 col-sm-6 col-xs-12">				
                    
                    <div class="panel panel-amin">

                        <div class="panel-heading">
                            <h3 class="panel-title">Add Item Price </h3>
                            <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                        </div>

                        <div class="panel-body">

                            <!-- <div class="form-group">

                                <label class="control-label" for="last-name"> Purchase Price </label>
                                <input type="number" id="" name="product_purchase_price" min="1"  required="required" class="form-control">

                            </div> -->

                            <div class="form-group">

                                <label class="control-label" for="last-name">Sell Price </label>
                                <input type="number" id="" name="product_sell_price"  min="1" required="required" class="form-control">

                            </div>

                            <div><br></div>

                            <div class="form-group" >

                                <label class="control-label">Publication Status</label> <br />
                                <div id="gender" class="btn-group" data-toggle="buttons">

                                    <label class="btn btn-default" >
                                        <input type="radio" name="product_status" value="1" required="required"> &nbsp; Published &nbsp;
                                    </label>
                                    
                                    <label class="btn btn-default" >
                                        <input type="radio" name="product_status" value="0" required="required"> Unpublished
                                    </label>
                                    
                                </div>

                                <div><br></div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div style="margin-left: 10px;">
                <button type="submit" class="btn btn-success btn-lg">Save Item</button>
            </div>

            <?php echo Form::close(); ?>


        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>