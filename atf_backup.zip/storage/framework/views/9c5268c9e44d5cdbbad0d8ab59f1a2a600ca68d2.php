  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col right_col_back" role="main">
    
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="box_layout col-md-12 col-sm-12 col-xs-12" >

                <div class="col-md-4 col-sm-12 col-xs-12">
                    <h3 style="padding-top: 4px;"><i class="fa fa-money" aria-hidden="true"></i> Purchase List </h3>
                </div>
                
                <!-- form date pickers -->
                <div class="col-md-8 col-sm-8 col-xs-12">
                    
                    <div class="form-group form-inline pull-right">
                        <button type="button" class="date_from_to btn btn-success">Go!</button>
                    </div>

                    <div class="form-group form-inline pull-right">
                        <div class="input-group date no_margin">
                            <input type="text" class="date_to datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </div>
                        </div>
                    </div>

                    <div class="form-group form-inline pull-right no_margin">
                        <div class="input-group date no_margin">
                            <input type="text" class="date_from datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="clearfix"></div>
                </div>
                <!-- /form datepicker -->                    
            </div>

            <?php 

                $message = Session::get('message');

                if ( $message !='') { ?>

                    <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                        <h5 class="text-center">

                            <?php

                                if(isset($message)) { ?>

                                    <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <strong> <?php echo $message;?> </strong>
                                    </div>
                                    
                                <?php
                                    Session::put('message','');
                                }
                            ?>

                        </h5>
                    </div> 
                    
                    <?php 
                }
                
            ?>
                

            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">
                <div class="panel panel-amin">
                    <div class="panel-heading">
                        <h3 class="panel-title">Order</h3>
                        <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                    </div>

                    <div class="panel-body"> 

                        <div class="table-responsive" style="width:100%;">
                            <table class="table table-striped bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        
                                        <th class="column-title text-center">Date/Time</th>
                                        <th class="column-title text-center">Buyer</th>
                                        <th class="column-title text-center">Medicine</th>
                                        <th class="column-title text-center">Price</th>
                                        <th class="column-title text-center">Quantity</th>
                                        <th class="column-title text-center">Total</th>
                                        <th class="column-title text-center">Disc.</th>                                            
                                        <th class="column-title text-center">After Disc.</th>                                            
                                        <th class="column-title text-center">Vat</th>
                                        <th class="column-title text-center">Payable</th>
                                        <th class="column-title text-center">Paid</th>
                                        <th class="column-title text-center">Due</th>
                                        <th class="column-title text-center">Account</th>
                                        <th class="column-title text-center">Cheque</th>
                                        <th class="column-title text-center">Rec/Trans No</th>
                                        <th class="column-title text-center">Note</th>
                                        <th class="column-title text-center">Payment</th>
                                        <th class="column-title text-center" >Action</th>
                                    </tr>
                                </thead>

                                <tbody class="order_list_table">

                                    
                                    

                                </tbody>
                            </table>
                        </div>

                    </div>
                    
                    
                    
                </div>
            </div>    
        </div>
    </div>
    
</div>




<!-- Modal Add due Pament-->
<div style="z-index:9999999999" class="modal fade add_payment_modal" id="" role="dialog">
    <div class="modal-dialog modal-md">

        <div class="modal-content">
            <div class="modal-header">
                
                <h4 class="modal-title">Add Payment <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
            </div>
            <div class="modal-body">
            
                <?php echo Form::open(['url' => '/add-payment', 'method'=>'post']); ?>

                    
                    <div class="form-group form-group-sm">

                        <input type="hidden" name="order_id" class="order_id" value="">
                        <label for="due">Due:</label>
                        <input type="text" class="amount form-control" value="" name="amount" placeholder="Due" id="amount" disabled="">
                                                
                    </div>

                    <div class="form-group form-group-sm">
                    
                        <label for="payment">Add Payment:</label>
                        <input type="number" class="due_payment form-control" value="" name="order_payment" min="1" placeholder="Payment" id="table-name" >
                                                
                    </div>                    
                    
                    <button type="submit" class="btn btn-primary">Add Payment</button>
                <?php echo Form::close(); ?>

                    
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>	  
    </div>
</div> 


<!-- Modal view Pament-->
<div style="z-index:9999999999" class="modal fade view_payment_modal" id="" role="dialog">
    <div class="modal-dialog modal-md">

        <div class="modal-content">
            <div class="modal-header">
                
                <h4 class="modal-title">View Payment <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
            </div>

            <div class="modal-body">
            
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">Date / Time</th>
                                <th class="text-center">Create By</th>
                                <th class="text-center">Amount</th>
                            </tr>
                        </thead>
                        <tbody class="return_due">
                            
                            
                                                                    
                        </tbody>
                    </table>
                </div> 

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>	  
    </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>