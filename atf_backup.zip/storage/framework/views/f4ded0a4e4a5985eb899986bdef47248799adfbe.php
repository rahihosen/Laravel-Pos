  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<style>
    
 #invoice-POS {
    box-shadow: 0 0 1in -0.25in rgba(0, 0, 0, 0.5);
    padding:2mm;
    margin: 0 auto;
    /* width: 44mm;*/
    width: 90mm;
    background: #FFF;

    ::selection {background: #f31544; color: #FFF;}
    ::moz-selection {background: #f31544; color: #FFF;}
    h1{
        font-size: 1.5em;
        color: #222;
    }
    h2{font-size: .9em;}
    h3{
        font-size: 1.2em;
        font-weight: 300;
        line-height: 2em;
    }
    p{
        font-size: .7em;
        color: #666;
        line-height: 1.2em;
    }
    
    #top, #mid,#bot{ /* Targets all id with 'col-' */
        border-bottom: 1px solid #EEE;
    }

    #top{min-height: 100px;}
    #mid{min-height: 80px;} 
    #bot{ min-height: 50px;}

    #top .logo{
        float: left;
        height: 60px;
        width: 60px;
        /*background: url(http://michaeltruong.ca/images/client.jpg)) no-repeat;*/
        background-size: 60px 60px;
    }
    .clientlogo{
        float: left;
        height: 60px;
        width: 60px;
        /*background: url(http://michaeltruong.ca/images/client.jpg) no-repeat;*/
        background-size: 60px 60px;
        border-radius: 50px;
    }
    .info{
        display: block;
        float:left;
        margin-left: 0;
    }
    .title{
        float: right;
    }
    .title p{text-align: right;} 
    table{
        width: 100%;
        border-collapse: collapse;
    }
    td{
        padding: 5px 0 5px 15px;
        border: 1px solid #EEE
    }
    .tabletitle{
        padding: 5px;
        font-size: .5em;
        background: #EEE;
    }
    .service{
        border-bottom: 1px solid #EEE;
    }
    .item{width: 34mm;}
    .itemtext{font-size: .5em;}

    #legalcopy{
        margin-top: 5mm;
    }
}
    
</style>


<div class="right_col right_col_back" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title hidden-print">
                        <!--<h2> <a href="add-category" class="btn btn-primary"> <i class="fa fa-plus" aria-hidden="true"></i>
                            Create New Category </a> </h2>-->

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                                <!--<div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>-->
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>    
                    <div class="x_content"> 
           
                    <div id="invoice-POS">

                        <center id="top">
                            <div class="logo"></div>
                            <div class="info">
                                <?php 
                                $company=DB::table('settings')
                                        ->first();
                                ?>
                                <img src="<?php echo e(asset($company->company_logo)); ?>" width="130px" height="50px">
                                
                                <h3><?= $company->company_name; ?></h3>
                            </div><!--End Info-->
                        </center><!--End InvoiceTop-->

                        <div id="mid" style="margin:0 15px;">
                            <div class="info">
                                <p class="text-center"> 
                                    <?= $company->company_address; ?><br />
                                    Email:<?= $company->company_email;?>, Mob:<?= $company->company_mobile;?><br />
                                </p>
                                
                                <div>
                                    <table class="table" style="margin:0 !important;">
                                        <tbody>
                                            <tr>
                                                  
                                                <td style="width: 6em;font-size: 11px;">Order: <?= $single_order_info_customer->order_id; ?>  </td>
                                                <td style="width: 9em;font-size: 11px;padding-left: 0px;">Date: <?php echo e($single_order_info_customer->order_created_date); ?> </td>
                                                            
                                               <td style="padding-left: 0px;font-size: 11px;">Table: 
                                                <?php
                                                    
                                                    $all_tables = DB::table('tables')->get();

                                                    $result = explode(',',$single_order_info_customer->table_number);

                                                    foreach ($all_tables as $all_tables) {

                                                        if(in_array($all_tables->table_id,$result)){

                                                    ?>
                                                    
                                                        <?= $all_tables->table_name; ?>

                                                    <?php    
                                                        }        
                                                    } 
                                                ?>   
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>               
                                </div>
                                
                                    <p> 
                                        <span class="pull-left">Customer: <?= $single_order_info_customer->customer_name;?></span>
                                        <span class="pull-right">  
                                            Mob: <?= $single_order_info_customer->customer_mobile;?>
                                        </span>
                                    </p>
                                
                            </div>
                        </div><!--End Invoice Mid-->

                        <div><br></div>
                        
                        <div id="bot" style="margin:0 15px;">
                            
                            <div id="table">

                                <table style="border-top:1px solid lightgray;border-bottom:1px solid lightgray;">
                                    <tr class="tabletitle">
                                        <td class="item" style="width:40%"><h2>Item</h2></td>
                                        <td class="Hours" style="width:10%"><h2>Qty</h2></td>
                                        <td class="Rate" style="width:15%"><h2 class="text-right">Price</h2></td>
                                        <td class="Rate" style="width:20%"><h2 class="text-right">S.Total</h2></td>
                                    </tr>

                                
                                    <?php $__currentLoopData = $single_order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr class="service">
                                            <td class="tableitem"><p class="itemtext"><?php echo e($order->product_name); ?></p></td>
                                            <td class="tableitem"><p class="itemtext text-center"><?php echo e($order->product_qty); ?></p></td>
                                            <td class="tableitem"><p class="itemtext text-right"><?php echo e($order->product_sale_price); ?></p></td>
                                            <td class="tableitem"><p class="itemtext text-right"><?php echo e($order->product_qty*$order->product_sale_price); ?></p></td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="tabletitle">
                                        <?php $order_id=$order->order_id;?>
                                        
                                        <td class="text-left" colspan="3" style="padding-left: 8em;"><b>Total:</b></td>
                                        <td class="text-right"><b>TK.<?php echo e($order = DB::table('order')
                                                                    ->where('order_id',$order_id)
                                                                    ->sum('order_total')); ?></b>
                                        </td>
                                        
                                    </tr>

                                    <tr class="tabletitle">
                                        
                                        <td  colspan="3" class="text-left" style="padding-left: 8em;"><b>Discount(%):</b></td>
                                        <td class="text-right"><b>
                                            <?= $single_order_info_customer->order_discount; ?>
                                            </b>
                                        </td>
                                    </tr>

                                    <tr class="tabletitle">
                                        
                                        <td  colspan="3" class="text-left" style="padding-left: 8em;"><b>After Discount:</b></td>
                                        <td class="text-right"><b>TK.
                                            <?= $single_order_info_customer->after_discount; ?>
                                            </b>
                                        </td>
                                    </tr>

                                    <tr class="tabletitle">
                                        
                                        <td  colspan="3" class="text-left" style="padding-left: 8em;"><b>Vat(%):</b></td>
                                        <td class="text-right"><b>
                                            <?= $single_order_info_customer->order_vat; ?>
                                            </b>
                                        </td>
                                    </tr>

                                    <tr class="tabletitle">

                                        <td class="text-left" colspan="3" style="padding-left: 8em;"><b>Amount Payable:</b></td>
                                                <td class="text-right"><b>TK.
                                                <?= $single_order_info_customer->total_amount_payable; ?> 
                                            </b>
                                        </td>
                                    
                                    </tr>
                                    <tr class="tabletitle">
                                        
                                        <td class="text-left" colspan="3" style="padding-left: 8em;"><b>Cash:</b></td>

                                        <td class="text-right"><b>Tk.
                                            <?php
                                                $order_id = $single_order_info_customer->order_id;

                                                $data = DB::table('pament_details')->where('order_id', $order_id)->sum('amount');

                                                echo $data; 
                                            ?> 
                                            </b>
                                        </td>
                                    
                                    </tr>
                                    <tr class="tabletitle">
                                        
                                        <td class="text-left" colspan="3" style="padding-left: 8em;"><b>Due:</b></td>

                                        <td class="text-right"><b>TK.
                                            <?php
                                                $result =  ($single_order_info_customer->total_amount_payable) - $data;
                                                echo $result;  
                                            ?> </b>
                                    
                                        </td>                
                                    </tr>

                                </table>
                            </div><!--End Table-->
                            <br>
                            <br>

                        </div><!--End InvoiceBot-->
                        <a class="btn btn-success" href="<?php echo e(url('/print-order-page/'.$single_order_info_customer->order_id)); ?>" target="_blank"><i class="fa fa-print"></i> Print</a>
                    </div><!--End Invoice-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>