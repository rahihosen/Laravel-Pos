<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Mukto Restaura </title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('public/admin_asset/build/css/custom.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('public/css/custom.css')); ?>" rel="stylesheet">
      
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo e(URL::to('/dashboard')); ?>" class="site_title"> <span>Mukto Restaura</span></a>
            </div>

            <div class="clearfix"></div>
  
            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                  <?php

                    $admin_id = Session::get('admin_id');
                    $admin_image_query = DB::table('admin')->where('admin_id',$admin_id)->first();
                  
                  ?>
                <img src="<?php echo $admin_image_query->admin_image;?>" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo e(Session::get('admin_name')); ?></h2>
              </div>
              <div class="clearfix"></div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">

                  <li><a href="<?php echo e(URL::to('/dashboard')); ?>"><i class="fa fa-home"></i> Dashboard </a></li>
                  
                  
                  <li><a><i class="fa fa-shopping-cart"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/create-sales')); ?>">New Order</a></li>
                      <li><a href="<?php echo e(URL::to('/order-list')); ?>">Order List</a></li>
                      <!-- <li><a href="<?php echo e(URL::to('/create-cancel-order')); ?>">Create Cancel Order</a></li> -->
                      <li><a href="<?php echo e(URL::to('/cancel-order-list')); ?>">Cancel Order List</a></li>                     
                      
                    </ul>
                  </li>

                  <li><a><i class="fa fa-shopping-basket"></i> Food Management <span class="fa fa-chevron-down"></span></a>

                    <ul class="nav child_menu">

                      <li><a href="<?php echo e(URL::to('/category-list')); ?>">Food Menu</a></li>
                      <li><a href="<?php echo e(URL::to('/add-product')); ?>">Add Food</a></li>
                      <!-- <li><a href="<?php echo e(URL::to('/add-category')); ?>">Add Food</a></li> -->
                      <li><a href="<?php echo e(URL::to('/product-list')); ?>">Food List</a></li>
                      <li><a href="<?php echo e(URL::to('/add-stock')); ?>"> Stock</a></li>
                      <li><a href="<?php echo e(URL::to('/add-wastage')); ?>"> Wastage </a></li>

                    </ul>

                  </li>

                  <!-- <li><a><i class="fa fa-list"></i> Food Items <span class="fa fa-chevron-down"></span></a>

                    <ul class="nav child_menu">
                    </ul>

                  </li> -->

                  

                  <!-- <li><a><i class="fa fa-shopping-cart"></i> Due Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    </ul>
                  </li> -->
                  
                  <!-- <li><a><i class="fa fa-hotel"></i> Stock Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/stock-list')); ?>">Stock List</a></li>

                    </ul>
                  </li> -->

                  <!-- <li><a><i class="fa fa-trash"></i> Wastage Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/wastage-list')); ?>">Wastage List</a></li>
                    </ul>
                  </li> -->

                  <li><a><i class="fa fa-users"></i> Customer Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="<?php echo e(URL::to('/customer-list')); ?>">Customer </a></li>
                      <li><a href="<?php echo e(URL::to('/customer-group-list')); ?>">Group</a></li>                     
                      
                    </ul>
                  </li>

                  <li><a><i class="fa fa-pie-chart"></i> Reports <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="<?php echo e(URL::to('/sales-report')); ?>">Sales Reports</a></li>
                      <li><a href="<?php echo e(URL::to('/stock-list-report')); ?>">Order Reports</a></li>
                      <li><a href="<?php echo e(URL::to('/due-list')); ?>">Due Reports</a></li>
                      
                      <!-- <li><a href="<?php echo e(URL::to('/sales-report-by-item')); ?>">Sales Reports By Item</a></li> -->
                      
                    </ul>
                  </li>                 
              
                </ul>
              </div>
              <div class="menu_section">
                <h3>User Panel</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-user-plus"></i> User Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/create-admin')); ?>">Create Admin</a></li>
                      <li><a href="<?php echo e(URL::to('/admin-list')); ?>">Admin List</a></li>
                     
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user-plus"></i> Settings <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/edit-settings')); ?>">Basic Settings</a></li>
                      <li><a href="<?php echo e(URL::to('/edit-role')); ?>">Role Settings</a></li>
                      <li><a href="<?php echo e(URL::to('/table')); ?>">Table Settings</a></li>
                      <li><a href="<?php echo e(URL::to('/vat-list')); ?>">Vat Settings</a></li>
                     
                    </ul>
                  </li>
              
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo e(URL::to('/logout')); ?>">

                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>

              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav hidden-print">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="images/img.jpg" alt=""><?php echo e(Session::get('admin_name')); ?>

                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="<?php echo e(URL::to('/logout')); ?>"><i class="fa fa-sign-out"></i> Log Out</a></li>
                  </ul>
                </li>

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        
        
        <!-- page content -->
        
        <?php echo $__env->yieldContent('admin_main_content'); ?>
        <!-- /page content -->

        <!-- footer content -->
        <footer class="footer_shadow hidden-print">
          <div class="pull-right">
              Developed by: <a href="https://muktodharaltd.com"><b>Muktodhara Technology Ltd.</b></a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/jquery/dist/jquery.min.js')); ?>"></script>

    <!-- Bootstrap -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/nprogress/nprogress.js')); ?>"></script>
      
      
    <!-- Initialize datetimepicker -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="<?php echo e(asset('public/admin_asset/vendors/moment/min/moment.min.js')); ?>"></script>
      
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset('public/admin_asset/build/js/custom.min.js')); ?>"></script>
    



    <?php  $data = Cart::content(); ?>

    <!-- Cart Functions All -->
    <script>

      $(document).ready(function() {

        $('.add_cart').click(function() {

          var product_id = $(this).data("productid");

          var vat_input = $(".vat_input").val();

          $('.cart_list_table').html("<tr><td colspan='6'><h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1><td></tr>");

          $.ajax({

            url:"<?php echo e(URL('/addTo')); ?>",
            method:"get",
            data:{product_id:product_id},

            success: function(data) {

              if(data == "1") {

                $('.cart_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {
                
                var af_splt = data.split("__sep__");

                $('.cart_list_table').html(af_splt[0]);

                $('.get_total_for_dis').html("Total TK. "+af_splt[1]);
                
                $('.get_total_for_dis').attr('data-total-dis', af_splt[1]);

                var after_vat = af_splt[1]*(vat_input/100);
                var tot = parseInt(af_splt[1]);

                after_vat = after_vat + tot;

                // if ( after_vat > .50 ) {
                //   res = after_vat + 1;
                // } else {
                  
                // }

                $(".discount_input").val("0");
                $(".ammount_received").val("");
                $(".ammount_return").val("");
                $(".ammount_due").val("");

                $(".after_discount_input").val(af_splt[1]);
                $(".after_vat_input").val(after_vat);
               
              }
            }
          });
        });
        

        // Page reload functions & Default values.......
        var vat_input = $(".vat_input").val();

        $(".after_discount_input").val("0");
        
        if($(".discount_input").val() == 0 || $(".discount_input").val() < 99.99) {
          
          var dis = parseInt($(".discount_input").val());
          
          var total = parseInt($(".get_total_for_dis").attr('data-total-dis'));
          
          var am_pay = total - ((total*dis)/100);
          
          $(".after_discount_input").val(am_pay);
            
          var after_vat = am_pay*(vat_input/100);
          var tot = parseInt(am_pay);
          after_vat = after_vat + tot;

          $(".after_vat_input").val(after_vat);
        } // else {

          // $(".discount_input").val("0");

          // var total = parseInt($(".get_total_for_dis").attr('data-total-dis'));

          // $(".after_discount_input").val(total);


        //}
          
        
          
        $(".discount_input").on('change keyup',function() {
              
          $(".ammount_received").val("");
          $(".ammount_return").val("");
          $(".ammount_due").val("");

          var vat_input = $(".vat_input").val();
          
          if($(this).val() != "") {
              
            if($(".discount_input").val() == 0 || $(".discount_input").val() < 99.99) {
              
              var dis = parseInt($(this).val());
              
              var total = parseInt($(".get_total_for_dis").attr('data-total-dis'));
              
              var am_pay = total - ((total*dis)/100);

              var after_vat = am_pay*(vat_input/100);

              var tot = parseInt(am_pay);

              after_vat = after_vat + tot;

              $(".after_discount_input").val(am_pay);
              $(".after_vat_input").val(after_vat);
              
            } else {

              $(".after_discount_input").val("");
              $(".after_vat_input").val("");

            }

          } else {

            $(".after_discount_input").val("");
            $(".after_vat_input").val("");

          }

        });


        $(".vat_input").on('change keyup',function() {
              
          $(".ammount_received").val("");
          $(".ammount_return").val("");
          $(".ammount_due").val("");

          var vat_input = $(".vat_input").val();
          
          if($(this).val() != "") {
              
            if($(".after_discount_input").val() == 0 && $(".after_discount_input").val("") ) {
              
              $(".after_vat_input").val("");
              
            } else {

              var dis = parseInt($(this).val());
              
              var total = parseInt($(".get_total_for_dis").attr('data-total-dis'));
              
              // var am_pay = total - ( (total*dis)/100);

              var after_vat = total*(vat_input/100);
              // var tot = Math.floor(parseInt(am_pay));
              // var tot = Math.ceil(parseInt(am_pay));
              // var tot = Math.round(parseInt(total));
              var tot = parseInt(total);
              
              
              after_vat = after_vat + tot;

              $(".after_vat_input").val(after_vat);
              
            }
            
          } 
        });


        // $(".after_discount_input").val("0");
        

        $(".ammount_received").on('change keyup',function() {
              
          if (!$(this).val()) {
              
            $(".ammount_return").val("");
            $(".ammount_due").val("");
            
          } else {
              
            // var payabl = parseInt($(".after_discount_input").val());
            var payabl_vat = parseInt($(".after_vat_input").val());
            var recv = parseInt($(this).val());
            
            if(recv > 0) {
              
              if(recv > payabl_vat) {
               
                var rec = parseInt($(this).val());
                var total = parseInt($(".after_vat_input").val());
                var ret = rec - total;
                $(".ammount_return").val(ret);
                $(".ammount_due").val("0");

              } else {

                var rec = parseInt($(this).val());
                var total = parseInt($(".after_vat_input").val());
                var ret = total - rec;
                $(".ammount_return").val("0");
                $(".ammount_due").val(ret);

              }  
                    
            } else {

              $(".ammount_due").val(payabl);
              $(".ammount_return").val("0");

            }
          }
        });
        
        // Check Customer list All Functions Show / Hide
        $(".check_cust").on('click',function() {
            
          if($(this).val() == '1') {

            $(".collapse_hide").slideUp();
            $(".collapse_hide_exist").slideUp();

          }
          
          if($(this).val() == '2') {

            $(".collapse_hide").slideDown();
            $(".collapse_hide_exist").slideUp();

          }

          if($(this).val() == '3') {

            $(".collapse_hide").slideUp();
            $(".collapse_hide_exist").slideDown();
              
          }

        });
          
      });
                  
      function myFunction (aaa) {
          
        var product_id = aaa;
        var vat_input = $(".vat_input").val();

        console.log(product_id);
        
        $('.cart_list_table').html("<tr><td colspan='6'><h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1><td></tr>");

        $.ajax({
              
          url:"<?php echo e(URL('/addTo')); ?>",
          method:"get",
          data:{product_id:product_id},
          success:function(data) {
              
            if(data == "1") {

              $('.cart_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

            } else {
          
              var af_splt = data.split("__sep__");

              $('.cart_list_table').html(af_splt[0]);

              $('.get_total_for_dis').html("Total TK. "+af_splt[1]);
              
              $('.get_total_for_dis').attr('data-total-dis', af_splt[1]);

              var after_vat = af_splt[1]*(vat_input/100);
              var tot = parseInt(af_splt[1]);

              after_vat = after_vat + tot;

              $(".discount_input").val("0");
              $(".ammount_received").val("");
              $(".ammount_return").val("");
              $(".ammount_due").val("");

              $(".after_discount_input").val(af_splt[1]);

              $(".after_vat_input").val(after_vat);
            }
          }
        });
      }
        
      function removeFunction (del_id) {
          
        var product_id = del_id;

        var vat_input = $(".vat_input").val();
        
        $('.rem_row_'+product_id).css("opacity", "0.6");

        $.ajax({
            
          url:"<?php echo e(URL('cart/remove/')); ?>",
          method:"get",
          data:{rem_id:product_id},
          success:function(data) {
              
            if(data == "1") {

              $('.cart_list_table').html("<tr><td colspan='6'><h3 style='text-align:center;color:gray; padding:20px 0;'>Cart is Empty!</h3><td></tr>");

              $('.get_total_for_dis').html("Total TK. 0");
              
              $('.get_total_for_dis').attr('data-total-dis', '0');

              $(".discount_input").val("0");
              $(".ammount_received").val("");
              $(".ammount_return").val("");
              $(".ammount_due").val("");

              $(".after_discount_input").val('0');
              $(".after_vat_input").val('0');

            } else {
              
              $('.rem_row_'+product_id).fadeOut("slow");

              var af_splt = data;

              $('.get_total_for_dis').html("Total TK. "+af_splt);
              
              $('.get_total_for_dis').attr('data-total-dis', af_splt);

              var after_vat = af_splt*(vat_input/100);
              var tot = parseInt(af_splt);

              after_vat = after_vat + tot;

              $(".discount_input").val("0");
              $(".ammount_received").val("");
              $(".ammount_return").val("");
              $(".ammount_due").val("");

              $(".after_discount_input").val(af_splt);

              $(".after_vat_input").val(after_vat);
              
            }
          }
        });
          
      }

      function plusFunction (iiddd, prrr) {

        var x = iiddd;
        var po = parseInt($("."+x).val());
        var af_sp_id = x.split("product_id_");

        po = po + 1;
        $("."+x).val(po);

        changeFunction(po,af_sp_id[1]);

        var shwTotal = prrr*po;

        $(".shwTotal_"+af_sp_id[1]).html(shwTotal)

      }

      function minusFunction (iidd, prr) {

        var y = iidd;
        var lo = parseInt($("."+y).val());
        var af_sp_idd = y.split("product_id_");

        if (lo > 1) {

          lo = lo - 1;
          $("."+y).val(lo);
          changeFunction(lo,af_sp_idd[1]);

          var shwTotal = prr*lo;

          $(".shwTotal_"+af_sp_idd[1]).html(shwTotal)
        }  
      }

      function changeFunction (qqq,rrr) {

        var qty = qqq;
        var rowid = rrr;

        var vat_input = $(".vat_input").val();

        console.log(qty);
        console.log(rowid);

        $.ajax({

          url:"<?php echo e(URL('/cart/update')); ?>",
          data:'qty=' + qty + '&rowid=' + rowid,
          type:'get',

          success:function(dataaaa) {

            $('.get_total_for_dis').html("Total TK. "+dataaaa);
            
            $('.get_total_for_dis').attr('data-total-dis', dataaaa);

            $(".discount_input").val("0");
            $(".ammount_received").val("");
            $(".ammount_return").val("");
            $(".ammount_due").val("");

            $(".after_discount_input").val(dataaaa);

            var after_vat = dataaaa*(vat_input/100);
            var tot = parseInt(dataaaa);
            after_vat = after_vat + tot;

            $(".after_vat_input").val(after_vat);

            
          } 
        });
      }

    </script>

    <!-- All Modal, cancel_order, panel_bootstrap, user Panel Show hide Function -->
    <script>

      // All Modal
      $(document).ready(function() {

        // Table Modal
        $('.table').on('click','.edit_table', function() {

          var table_id = $(this).val();

          var table_name = $(this).attr('data-tableName');

          $('.table_id').val(table_id);

          $('.table_name').val(table_name);

          $('.edit_table_modal').modal();

        });

        // Payment Modal
        $('.table').on('click','.add_payment', function() {

          var order_id = $(this).val();

          var amount = $(this).attr('data-amountDue');

          $('.order_id').val(order_id);

          $('.amount').val(amount);

          $('.due_payment').attr('max',amount);
            
          $('.add_payment_modal').modal();
        });

        // Payment view
        $('.table').on('click','.view_payment', function() {

          var order_id = $(this).val();
            
          $(".return_due").html();
          
          $('.return_due').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/view-payment')); ?>",

            method:"GET",

            data:{order_id:order_id},

            success: function(data) {

              if (data == "") {

                $('.return_due').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.return_due').html(data);

              }
            }
      
          });

          $('.view_payment_modal').modal();

        });

        // Add Stock Modal
        $('.table').on('click','.add_stock', function() {

          var product_id = $(this).val();

          var product_name = $(this).attr('data-productName');

          $('.product_id').val(product_id);

          $('.product_name').val(product_name);

          $('.add_stock_modal').modal();

        });

        // View Stock Modal
        $('.table').on('click','.view_stock', function() {

          var product_id = $(this).val();

          var product_name = $(this).attr('data-productName');
          
          $('.product_name').html(product_name);

          $(".return_product").html();
              
          $('.return_product').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/view-stock')); ?>",

            method:"GET",

            data:{product_id:product_id},

            success: function(data) {

              if(data == ""){

                $('.return_product').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              }else{

                $('.return_product').html(data);                    
              }

            }
      
          });

          $('.view_stock_modal').modal();

        });

        // Add Wastage Modal
        $('.table').on('click', '.add_wastage', function() {

          var product_id = $(this).val();

          var product_name = $(this).attr('data-productName');

          $('.product_id').val(product_id);

          $('.product_name').val(product_name);

          $('.add_wastage_modal').modal();
        });

        // View Wastage Modal
        $('.table').on('click','.view_wastage', function() {

          var product_id = $(this).val();

          var product_name = $(this).attr('data-productName');

          $('.product_name').html(product_name);

          $(".return_product").html();
              
          $('.return_product').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/view-stock')); ?>",

            method:"GET",

            data:{product_id:product_id},

            success: function(data) {

              if(data == ""){

                $('.return_product').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              }else{

                $('.return_product').html(data);                    
              }

            }

          });

          $('.view_wastage_modal').modal();
        });

        // Edit Category Modal
        $('.table').on('click', '.edit_category', function() {

          var category_id = $(this).val();

          var catName = $(this).attr('data-catName');

          var catOrder = $(this).attr('data-catOrder');

          var specialMenu = $(this).attr('data-specialMenu');

          var status = $(this).attr('data-status');

          $('.category_id').val(category_id);

          $('.category_name').val(catName);

          $('.category_order').val(catOrder);

          if( specialMenu == 0 ) {
      
            $('.edit_cat_special_type_active').removeClass('active');
            $('.edit_cat_special_type_active').children('input').prop('checked',false);
            
            $('.edit_cat_special_type_inactive').addClass('active');
            $('.edit_cat_special_type_inactive').children('input').prop('checked',true);
            
          }            
          if ( specialMenu == 1 ) {
            
            $('.edit_cat_special_type_active').addClass('active');
            $('.edit_cat_special_type_active').children('input').prop('checked',true);
            
            $('.edit_cat_special_type_inactive').removeClass('active');
            $('.edit_cat_special_type_inactive').children('input').prop('checked',false);
            
          }


          if ( status == 0 ) {
      
            $('.edit_cat_type_active').removeClass('active');
            $('.edit_cat_type_active').children('input').prop('checked',false);
            
            $('.edit_cat_type_inactive').addClass('active');
            $('.edit_cat_type_inactive').children('input').prop('checked',true);
            
          }

          if ( status == 1) {
            
            $('.edit_cat_type_active').addClass('active');
            $('.edit_cat_type_active').children('input').prop('checked',true);
            
            $('.edit_cat_type_inactive').removeClass('active');
            $('.edit_cat_type_inactive').children('input').prop('checked',false);
            
          }

          $('.edit_category_modal').modal();

        });

        // Add Product Modal
        $('.box_layout').on('click', '.add_product', function() {

          $('.add_product_modal').modal();

        })
        
        // Edit Product Modal
        $('.table').on('click', '.edit_product', function() {

          var product_id = $(this).val();
          
          var productName = $(this).attr('productName');

          // var productPurchasePrice = $(this).attr('productPurchasePrice');

          var productSellPrice = $(this).attr('productSellPrice');

          var productCategory = $(this).attr('productCategory');

          var productCategoryName = $(this).attr('productCategoryName');

          var productImage = $(this).attr('productImage');

          var oldImage = $(this).attr('oldImage');

          var productStatus = $(this).attr('productStatus');

          $('.product_id').val(product_id);

          $('.product_name').val(productName);

          // $('.product_purchase_price').val(productPurchasePrice);

          $('.product_sell_price').val(productSellPrice);

          $('.fk_category_id').val(productCategory);

          $('.fk_category_id').html(productCategoryName);

          $('.product_img').attr('src',productImage);

          $('.old_image').val(oldImage);

          $('.clear_image').val('');

          if(productStatus == 0) {
        
            $('.edit_product_type_active').removeClass('active');
            $('.edit_product_type_active').children('input').prop('checked',false);
            
            $('.edit_product_type_inactive').addClass('active');
            $('.edit_product_type_inactive').children('input').prop('checked',true);
            
          }

          if(productStatus == 1) {
            
            $('.edit_product_type_active').addClass('active');
            $('.edit_product_type_active').children('input').prop('checked',true);
            
            $('.edit_product_type_inactive').removeClass('active');
            $('.edit_product_type_inactive').children('input').prop('checked',false);
            
          }
          $('.edit_product_modal').modal();
        });

        // View Product Modal
        $('.table').on('click', '.view_product', function() {

          var product_id = $(this).val();

          var productImage = $(this).attr('productImage');

          // var product_name = $(this).attr('data-productName');

          // $('.product_image').html(product_image);

          $(".return_product").html();
              
          $('.return_product').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
            
          $.ajax({

            url:"<?php echo e(URL('/view-product')); ?>",

            method:"GET",

            data:{product_id:product_id},

            success: function(data) {

              if(data == "") {

                $('.return_product').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.return_product').html(data);

              }
            }
          });

          $('.product_id').val(product_id);

          $('.view_product_modal').modal();

        });

        // Edit Customer Modal
        $('.table').on('click', '.edit_customer', function() {

          var customer_id = $(this).val();
          
          var customerName = $(this).attr('customerName');

          var customerMobile = $(this).attr('customerMobile');

          var customerEmail = $(this).attr('customerEmail');

          var customerGroupId = $(this).attr('customerGroupId');

          var customerGroupName = $(this).attr('customerGroupName');

          $('.customer_id').val(customer_id);

          $('.customer_name').val(customerName);

          $('.customer_mobile').val(customerMobile);

          $('.customer_email').val(customerEmail);

          $('.customer_group_id').val(customerGroupId);

          $('.customer_group_id').html(customerGroupName);

          $('.edit_customer_modal').modal();
        });

        // View Customer Modal
        $('.table').on('click', '.view_customer', function() {

          var customer_id = $(this).val();

          $('.customer_id').val(customer_id);

          $(".return_product").html();
              
            $('.return_product').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
            
            $.ajax({

              url:"<?php echo e(URL('/view-customer')); ?>",

              method:"GET",

              data:{customer_id:customer_id},

              success: function(data) {

                if(data == ""){

                  $('.return_product').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

                }else{

                  $('.return_product').html(data);                    
                }
              }
            });

          $('.view_customer_modal').modal();
        });

        // Edit Customer Group Modal
        $('.table').on('click', '.edit_customer_group', function() {

          var group_id = $(this).val();
          
          var groupName = $(this).attr('groupName');

          $('.group_id').val(group_id);

          $('.group_name').val(groupName);

          $('.edit_customer_group_modal').modal();

        });

        // Edit Product Modal
        $('.table').on('click', '.edit_vat', function() {
          

          var vat_id = $(this).val();
          
          var vatName = $(this).attr('vatName');

          var vatAmount = $(this).attr('vatAmount');

          var vatStatus = $(this).attr('vatStatus');

          $('.vat_id').val(vat_id);

          $('.vat_name').val(vatName);

          $('.vat_amount').val(vatAmount);

          if(vatStatus == 0){
        
            $('.edit_vat_active').removeClass('active');
            $('.edit_vat_active').children('input').prop('checked',false);
            
            $('.edit_vat_inactive').addClass('active');
            $('.edit_vat_inactive').children('input').prop('checked',true);
            
          }
          if(vatStatus == 1){
            
            $('.edit_vat_active').addClass('active');
            $('.edit_vat_active').children('input').prop('checked',true);
            
            $('.edit_vat_inactive').removeClass('active');
            $('.edit_vat_inactive').children('input').prop('checked',false);
            
          }

          $('.edit_vat_modal').modal();

        });

      });

      // Cancel Order 
      $(document).ready(function () {

        // Cancel Order To list
        $('.table').on('click', '.cancel_order', function() {

          var this_data = $(this);
          var order_id = $(this).val();
          
          $.ajax({

            url:"<?php echo e(URL('/cancel-order')); ?>",

            method:"GET",

            data:{order_id:order_id},

            success: function(data) {
        
              if(data == "1"){

                console.log(data);
                this_data.parent().parent().fadeOut();

              } else {

                console.log(data);

              }
            }
          });
        });

        // Return Order To list.
        $('.table').on('click', '.return_cancel_order', function() {

          var this_data = $(this);
          var order_id = $(this).val();
          
          $.ajax({

            url:"<?php echo e(URL('/return-cancel-order')); ?>",

            method:"GET",

            data:{order_id:order_id},

            success: function(data) {
        
              if(data == "1"){

                console.log(data);
                this_data.parent().parent().fadeOut();

              } else {

                console.log(data);

              }
            }
          });
        });

      });

      //Panel bootstrap
      $(document).ready(function () {

        $(document).on('click', '.panel-heading span.clickable', function(e) {

          var $this = $(this);

          if(!$this.hasClass('panel-collapsed')) {

            $this.parents('.panel').find('.panel-body').slideUp();
            $this.addClass('panel-collapsed');
            $this.find('i').removeClass('fa fa-plus').addClass('fa fa-minus');

          } else {

            $this.parents('.panel').find('.panel-body').slideDown();
            $this.removeClass('panel-collapsed');
            $this.find('i').removeClass('fa fa-minus').addClass('fa fa-plus');

          }
        });

      });

      //user panel show hide in topbar
      $(document).ready(function () {
        
        $('.user_hover').hover(function() {

          $(this).find('.user_out').stop(true, true).fadeIn('fast');

          }, function() {

          $(this).find('.user_out').stop(true, true).fadeOut("slow");
          
        });
      });
        
      
    </script>

    <!-- Search All Function -->
    <script>
      
      $(document).ready(function(){

        // Search Product list
        $(document).on('click','.name_from_to_product_list',function() {
            
          var search_product = $(".search_product").val();
          var fk_category_id = $(".fk_category_id").val();

          // if ( search_product.length > 0 ) {
            
            $(".search_results").html();
            
            $('.search_results').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
            
            $.ajax({

              url:"<?php echo e(URL('/search-product-list')); ?>",

              method:"GET",

              data:{search_product:search_product,fk_category_id:fk_category_id},

              success: function(data) {

                $('.search_results').html(data);
                $('.hide_pagi').hide();
              }        
            });
          // }
        });


        // Search Stock list
        $(document).on('click','.name_from_to_stock_list',function() {
            
          var search_stock = $(".search_stock").val();
          var fk_category_id = $(".fk_category_id").val();
            
          $(".search_results").html();
          
          $('.search_results').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
            
          $.ajax({

            url:"<?php echo e(URL('/search-stock-list')); ?>",

            method:"GET",

            data:{search_stock:search_stock,fk_category_id:fk_category_id},

            success: function(data) {

              if(data == "1"){
                  $('.search_results').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
              }else{
                $('.search_results').html(data);
                $('.hide_pagi').hide();
              }
            }      
          });
        });

        
        // Search Wastage list
        $(document).on('click','.name_from_to_wastage_list',function() {
            
          var search_wastage = $(".search_wastage").val();
          var fk_category_id = $(".fk_category_id").val();
          
          $(".wastage_list_table").html();
          
          $('.wastage_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-wastage-list')); ?>",

            method:"GET",

            data:{search_wastage:search_wastage,fk_category_id:fk_category_id},

            success: function(data) {

              if (data == "1") {

                $('.wastage_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.wastage_list_table').html(data);
                $('.hide_pagi').hide();

              }
            }      
          });
        });

        // Search Order List 
        $(document).on('click','.date_from_to',function() {
            
          var date_from = $(".date_from").val();
          var date_to = $(".date_to").val();
          
          $(".order_list_table").html();
          
          $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-order-date')); ?>",

            method:"GET",

            data:{dt_from:date_from,dt_to:date_to},

            success: function(data) {

              if(data == "1") {

                $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              }else {

                $('.order_list_table').html(data);
                $('.hide_pagi').hide();
                
              }
            }      
          });
        });

        // Search Cancel Order List 
        $(document).on('click','.cancel_date_from_to',function() {
            
          var date_from = $(".date_from").val();
          
          var date_to = $(".date_to").val();
          
          $(".cancel_order_list_table").html();
          
          $('.cancel_order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-cancel-order-date')); ?>",

            method:"GET",

            data:{dt_from:date_from,dt_to:date_to},

            success: function(data) {

              if(data == "1") {

                $('.cancel_order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.cancel_order_list_table').html(data);
                $('.hide_pagi').hide();
                
              }
            }      
          });
        });

        // Search Customer list
        var field_data = $('.search_results').html();
        var search_key = $('.search_key').html();

        $('.search_customer').on('focus focusout',function() {
          
          $(this).on('change keyup',function() {
            
            var search_val = $(this).val();
            
            $('.search_key').html("Your Searched: '"+search_val+"'");
            
            if(search_val != '') {
              
              $('.search_results').html("<h2 class='text-center'><i class='fa fa-spinner fa-spin'></i></h2>");
              
              $('.pagi_box').hide();
                        
                $.ajax({

                  url:"<?php echo e(URL('/search-customer-list')); ?>",
      
                  method:"GET",
      
                  data:{search_val:search_val},
      
                  success: function(data) {
              
                    if(data == "1") {
                      
                      $('.search_results').html("<h4 class='text-center'>Nothing Found.</h4>");
                      
                    } else {
                      
                      $('.search_results').html(data);
                      
                    }

                  }
                });
            }

            if(search_val == '') {
              
              $('.search_results').html(field_data);
              $('.search_key').html(search_key);
              $('.pagi_box').show();
            }
          
          });
          
        });

        
        $(document).on('click','.date_from_to_for_sales_order',function() {
            
          var date_from = $(".date_from").val();
          var date_to = $(".date_to").val();
          
          $(".order_list_table").html();
          
          $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-sales-report-order')); ?>",

            method:"GET",

            data:{dt_from:date_from,dt_to:date_to},

            success: function(data) {

              if(data == "1") {

                $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.order_list_table').html(data);
                $('.hide_pagi').hide();

              }
            }      
          });
        });

        
        $(document).on('click','.date_from_to_for_sales',function() {
            
          var date_from = $(".date_from").val();
          var date_to = $(".date_to").val();
          
          $(".order_list_table").html();
          
          $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-sales-report')); ?>",

            method:"GET",

            data:{dt_from:date_from,dt_to:date_to},

            success: function(data) {

              if(data == "1") {

                $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.order_list_table').html(data);
                $('.hide_pagi').hide();

              }
            }
          });
        });


        $(document).on('click','.date_from_to_due',function() {
            
          var date_from = $(".date_from").val();
          var date_to = $(".date_to").val();
          
          $(".order_list_table").html();
          
          $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
            
          $.ajax({

            url:"<?php echo e(URL('/search-order-date-due')); ?>",

            method:"GET",

            data:{dt_from:date_from,dt_to:date_to},

            success: function(data) {

              if(data == "1") {

                $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              }else{

                $('.hide_pagi').hide();
                $('.order_list_table').html(data);

              }

              // $('.gen_range').html("Showing data from "+date_from+"to "+date_to);
              
            }
      
          });
            
        });


        $(document).on('click','.date_from_to_cancel_order',function() {
            
          var date_from = $(".date_from").val();
          var date_to = $(".date_to").val();
          
          $(".order_list_table").html();
          
          $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-order-date-cancel-order')); ?>",

            method:"GET",

            data:{dt_from:date_from,dt_to:date_to},

            success: function(data) {

              if(data == "1") {

                $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              } else {

                $('.hide_pagi').hide();
                $('.order_list_table').html(data);

              }

              // $('.gen_range').html("Showing data from "+date_from+"to "+date_to);
            }
      
          });
            
        });


        $(document).on('click','.cat_list_tag',function(){
          
          $(".cat_list_tag").removeClass('cat_list_tag_active');
          $(this).addClass('cat_list_tag_active');
          
          var cat_id = $(this).attr('data-cat-id');
          
          var cat_name = $(this).attr('data-cat-name');
          
          var all_pro = $(".show_pro_all").html();
          
          $('.show_pro_all').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
          
          $('.show_pro_small_cat').html("<i class='fa fa-spinner fa-spin'></i>");
          
          $.ajax({

            url:"<?php echo e(URL('/search-pro-by-cat')); ?>",

            method:"GET",

            data:{by_cat_id:cat_id},

            success: function(data) {

              if(data == "1") {

                $('.show_pro_all').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                $('.show_pro_small_cat').html(" ");

              } else {

                $('.show_pro_all').html(data);
                $('.show_pro_small_cat').html(cat_name.toUpperCase());

              }
            }

          });
            
        });

      });
      
    </script>

    <!-- Date Picker -->
    <script>

      $( function() {

        $( ".datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });

      });

    </script>

    <!-- Print Product & Customer -->
    <script>

      // Print for product list page view Print.
      $(document).ready(function() {

        $(document).on('click','.print_details',function () {

          var prtContent = document.getElementById("client_details");

          var WinPrint = window.open('', '', 'left=0,top=0,width=1200,height=900,toolbar=0,scrollbars=0,status=0');

          WinPrint.document.writeln('<html><head><title></title><style>table td {padding:10px !important;}</style>');

          WinPrint.document.writeln('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">');

          // WinPrint.document.writeln('<link href="files/backend/style.css" rel="stylesheet" type="text/css" />');

          WinPrint.document.writeln('<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet"> ');

          WinPrint.document.writeln('</head><body >');

          // WinPrint.document.writeln('<p><img src="files/backend/img/logo.png" width="auto" height="70px" alt="image"></p>');

          WinPrint.document.writeln('<br>');

          WinPrint.document.writeln('<h4>Product Details:</h4>');

          WinPrint.document.writeln(prtContent.innerHTML);

          WinPrint.document.writeln('</body></html>');
          WinPrint.document.close();
          WinPrint.focus();
          //WinPrint.print();
          //WinPrint.close();

        });

      });
      
      // Print for Customer list page view Print.
      $(document).ready(function() {

        $(document).on('click','.print_customer_details',function () {

          var prtContent = document.getElementById("customer_details");

          var WinPrint = window.open('', '', 'left=0,top=0,width=1200,height=900,toolbar=0,scrollbars=0,status=0');

          WinPrint.document.writeln('<html><head><title></title><style>table td {padding:10px !important;}</style>');

          WinPrint.document.writeln('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">');

          // WinPrint.document.writeln('<link href="files/backend/style.css" rel="stylesheet" type="text/css" />');

          WinPrint.document.writeln('<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i" rel="stylesheet"> ');

          WinPrint.document.writeln('</head><body >');

          // WinPrint.document.writeln('<p><img src="files/backend/img/logo.png" width="auto" height="70px" alt="image"></p>');

          WinPrint.document.writeln('<br>');

          WinPrint.document.writeln('<h4>Customer Details:</h4>');

          WinPrint.document.writeln(prtContent.innerHTML);

          WinPrint.document.writeln('</body></html>');
          WinPrint.document.close();
          WinPrint.focus();
          //WinPrint.print();
          //WinPrint.close();

        });

      });

      // Print-order-page.....
      <?php

        if(isset($_GET['oid'])) {

          if($_GET['oid'] > 0) { ?>
              
            window.open(

              '<?php echo e(url('/print-order-page'.$_GET['oid'])); ?>',
              '_blank'

            );
              
          <?php
          }
        } 
      ?>
        
    </script>

    <!-- Delete Function -->
    <script>
      function checkDelete() {

        check = confirm("Are you sure to delete?");
        if (check) {

          return true;

        } else {

          false;

        }
      }
    </script>

  </body>
</html>