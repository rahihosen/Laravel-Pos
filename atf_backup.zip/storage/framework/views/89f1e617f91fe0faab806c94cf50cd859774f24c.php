  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <div class="col-md-4 col-sm-3 col-xs-12">

                            <h3 class="no_padding"><i class="fa fa-money" aria-hidden="true"></i> Expenses </h3>

                        </div>

                        
                    </div>

                    <!-- All Success Messages -->
                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                    

                    <div class="no_padding right_padding res_no_padding col-md-4 col-sm-4 col-xs-12">				
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Expenses Head</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">        
                                
                                
                                <?php echo Form::open(['url' => '/save-expenses','method'=>'post']); ?>


                                    <div class="form-group form-group-sm">

                                        <label for="expenses-head">Expenses Head </label>

                                        <select id="expenses-head" name="expenses_head_id" class="form-control active expenses_head" required>
                                            
                                            <?php 
                                                $expenses = DB::table('expenses_head')->get();

                                                foreach($expenses as $expenses ) {  ?>
                                                
                                                    <option value="<?= $expenses->expenses_head_id; ?>"><?= $expenses->expenses_head_name;?></option>
                                            
                                                    <?php
                                                } 
                                            ?>
                                                
                                        </select>

                                    </div>


                                    <div class="form-group form-group-sm">

                                        <label for="expenses-sub-head-name">Expenses Sub Head </label>

                                        <select id="expenses-sub-head-name" name="expenses_sub_head_id" class="form-control search_results_expenses" required>
										
                                        </select>

                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label for="account-name">Select Account </label>

                                        <select id="account-name" name="account_id" class="form-control" required>
                                            
                                            <?php $accounts = DB::table('accounts')->get(); ?>

                                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <option value="<?= $accounts->account_id;?>"><?= $accounts->account_name;?></option>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
                                        </select>
                                    
                                    </div>     

                                    <div class="form-group form-group-sm">

                                        <label for="ammount"> Ammount </label>

                                        <input type="number" placeholder="Ammount" id="ammount" class="form-control" name="expenses_ammount" required>

                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label for="expenses-note">Note </label>
										
                                        <textarea id="expenses-note" class="form-control" placeholder="Note" name="expenses_note"></textarea>
                                        
                                    </div>

                                    <div class="ln_solid"></div>

                                    <div class="form-group form-group-sm">

                                        <button type="submit" class="btn btn-success">Save</button>
                                        
                                    </div>

                                <?php echo Form::close(); ?>                                
                                
                            </div>
                        </div>
                        
                    </div>

                    <div class="no_padding col-md-8 col-sm-8 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Expenses List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">

                                <?php if( $data = count($all_expenses) > 0 ): ?>
							
                                    <div class="col-md-4 col-sm-4 col-xs-12 no_padding">					
                                        <div class="marginBT10 form-group-sm">
                                            <input type="text" class="date_from datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-4 col-sm-4 col-xs-12 no_padding">					
                                        <div class="marginBT10 form-group-sm">
                                            <input type="text" class="date_to datepicker form-control" value="<?php echo e(date('Y-m-d')); ?>">
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-4 col-sm-4 col-xs-12 res_no_padding">					
                                        <div class="marginBT10 form-group-sm">
                                            <button class="date_from_to_expenses btn btn-primary btn-sm">Go</button>
                                            
                                            <button class="print_now btn btn-danger btn-sm"><i class="fa fa-print"></i> Print</button>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-12 col-sm-12 col-xs-12 no_padding" id="print_content">
                                        
                                        <p class="search_term"><b>Expenses </b></p>
                                
                                        <div class="table-responsive">   

                                            <table class="table table-align table-striped table-responsive table-bordered">

                                                <thead>
                                                    <tr class="headings">
                                                        <th class="text-center">Date / Time </th>
                                                        <th class="text-center">Ammount </th>
                                                        <th class="text-center">Note </th>
                                                        <th class="text-center">Head </th>
                                                        <th class="text-center">Sub Head </th>
                                                        <th class="text-center">Account Name </th>
                                                        <th class="text-center">Created By </th>
                                                        <th class="text-center">Action</th>
                                                    </tr>
                                                </thead>

                                                <tbody class="return_expenses">
                                                    
                                                    <?php $__currentLoopData = $all_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                                        <tr class="even pointer">

                                                            <td class="text-center"><?php echo e($expenses->expenses_created_date); ?> / <?php echo e($expenses->expenses_created_time); ?></td>
                                                            <td class="text-center"><?php echo e($expenses->expenses_ammount); ?></td>
                                                            <td class="text-center"><?php echo e($expenses->expenses_note); ?></td>
                                                            <td class="text-center"><?php echo e($expenses->expenses_head_name); ?></td>
                                                            <td class="text-center"><?php echo e($expenses->expenses_sub_head_name); ?></td>
                                                            <td class="text-center"><?php echo e($expenses->account_name); ?></td>
                                                            <td class="text-center"><?php echo e($expenses->name); ?></td>
                                                            <td class="text-center">
                                                                <button
                                                                    class="btn btn-danger btn-xs del"
                                                                    value="<?php echo e($expenses->expenses_id); ?>"

                                                                    ><i class="fa fa-trash"></i>
                                                                </button>
                                                            </td>                                                            
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                    
                                                </tbody>                                                
                                            </table>
                                        </div>
                                    </div>
                                <?php else: ?> 

                                    <h4 class="text-center">Nothing Found</h4>

                                <?php endif; ?>

                            </div>

                            <div class="hide_pagi pull-right">

                                <?php if( $all_expenses != ''): ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/expenses-list?page=1')); ?>">First</a> </li>
                                    </ul>

                                    <?php echo e($all_expenses->links()); ?>

                                    
                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/expenses-list?page='.$all_expenses->lastPage())); ?>">Last</a> </li>
                                    </ul>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>

<script>
    $(document).ready(function() {
        
        // Edit Client Modal
        $('.table').on('click', '.edit', function() { 
        
            var a_id = $(this).val();
            
            var a_name = $(this).attr('a_name');
            
            var a_email = $(this).attr('a_email');
            
            var photo = $(this).attr('photo');

            var oldImage = $(this).attr('oldImage');

            var a_mobile = $(this).attr('a_mobile');

            var a_address = $(this).attr('a_address');
            
            
            $('.a_id').val(a_id);
            
            $('.a_name').val(a_name);
            
            $('.a_email').val(a_email);

            $('.a_mobile').val(a_mobile);

            $('.a_address').val(a_address);
            
            $('.admin_img').attr('src',photo);
            
            $('.admin_img').show();
            
            $('#thumb-output-modal').html('');
            
            $('.old_image').val(oldImage);
            
            $('.clear_image').val('');
            
            
            $('.edit__modal').modal();
            
        });

        $('.table').on('click', '.del', function() {

            var this_data = $(this);
            var id = $(this).val();
                    
            $.confirm({
                icon: 'fa fa-smile-o',
                theme: 'modern',
                closeIcon: true,
                animation: 'scale',
                type: 'red',
                autoClose: 'cancel|10000',
                escapeKey: 'cancel',
                    
                buttons: {
                    
                    Delete: {
                        
                        btnClass: 'btn-red',
                    
                        action: function() {
                    
                            $.ajax({
                        
                                url:"<?php echo e(URL('/del-expenses')); ?>",
                        
                                method:"GET",
                                
                                data:{id:id},
                                
                                success: function(data) {
                        
                                    if(data == "1"){
                                        // console.log(data);
                                        this_data.parent().parent().fadeOut();
                                    
                                    } else {
                                        // console.log(data);
                                    }
                                }
                            });
                        
                            this.setCloseAnimation('zoom');
                        }
                    
                    },
                    
                    cancel: function() {
                    
                        $.alert('Canceled!');
                    
                        this.setCloseAnimation('zoom');
                    }
                }
            });
        });
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>