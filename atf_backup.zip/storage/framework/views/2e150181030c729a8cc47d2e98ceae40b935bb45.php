<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mukto Restaura </title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('public/admin_asset/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('public/admin_asset/build/css/custom.min.css')); ?>" rel="stylesheet">
    <style>
        
        p.cat_list_tag {
            background:#0091D2;
            color:#fff;
            padding:6px 0;
            text-align:center;
            cursor:pointer;
        }
        
        p.cat_list_tag:hover {
            background:#023264;
            transition:0.4s;
            cursor:pointer;
        }
        
        p.cat_list_tag_active {
            background:#023264;
        }
        
        
        
        
        
        
        .main_container {
            background: #0354A6;
        }
        
        .nav.side-menu > li.active > a {
            background: rgba(0,0,0,0.4);
        }

        .nav li.current-page {
            background: rgba(0,0,0,0.4);
        }

        .left_col {
            background: #0354A6;
        }
        .nav-md ul.nav.child_menu li::after {
            border-left: 1px solid #1598D3;
            left: 40px;
        }

        .nav-md ul.nav.child_menu li::before {
            background: #1598D3;
            left: 37px;
        }
        .nav.child_menu li {
            padding-left: 50px;
        }
        .sidebar-footer {
            background: #0354A6;
        }
        .sidebar-footer a{
           background: rgba(0,0,0,0.4);
           color:#888;
        }
        .sidebar-footer a:hover{
           background: rgba(0,0,0,0.6);
        }
        .nav_title {
         background:#023264;
        }
        .nav_title a{
         text-align: center;
         padding-left:0;
        }   
        
        .nav.side-menu>li.active, .nav.side-menu>li.current-page {
            border-right: 5px solid #00ace7;
        }
        table.jambo_table thead {
            background: #023264;
            color: #ECF0F1;
        }
        .show_pro_small_cat {
            background: #023264;
            color:#fff;
        }

        .q_input_fields i{
            font-size:16px;
            position:relative;
            top:-4px;
            left:-1px;
          }
          .q_input_fields {
            padding-top:4px;
            
          }

        .q_minus, .q_plus {
            margin: 0;
            height: 24.5px;
            width: 25px;
            color: #fff;
            border: none;
            font-size: 22px;
            position: relative;
            top: 2.5px;
        }
        button.q_plus {
            background: gray;
            border-radius: 0 5px 5px 0;
        }
        button.q_minus {
              background: gray;
              border-radius: 5px 0 0 5px;
          }
          
        .q_input {
          margin:0;
          padding: 5px;
          text-align: center;
          width:25px;
          height: 25px;
          border: none;
          border-top: 1px solid lightgray;
          border-bottom: 1px solid lightgray;
          position:relative;
          top:-4px;
        }

    </style>
    <script>
       

        function checkDelete(){
            check=confirm("Are you sure to delete?");
            if(check){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
   
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo e(URL::to('/dashboard')); ?>" class="site_title"> <span>Mukto Restaura</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                  <?php
                  $admin_id = Session::get('admin_id');
                  $admin_image_query = DB::table('admin')
                               ->where('admin_id',$admin_id)
                               ->first();
                 // echo'<pre>';
               //   print_r($admin_image_query);
                  //exit();
                  
                  ?>
                <img src="<?php echo $admin_image_query->admin_image;?>" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo e(Session::get('admin_name')); ?></h2>
              </div>
              <div class="clearfix"></div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                    <li><a href="<?php echo e(URL::to('/dashboard')); ?>"><i class="fa fa-home"></i> Dashboard </a></li>
                  
                  
                  <li><a><i class="fa fa-shopping-cart"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/create-sales')); ?>">Add New Order</a></li>
                      <li><a href="<?php echo e(URL::to('/order-list')); ?>">Order List</a></li>
                      <li><a href="<?php echo e(URL::to('/create-cancel-order')); ?>">Create Cancel Order</a></li>
                      <li><a href="<?php echo e(URL::to('/cancel-order-list')); ?>">Cancel Order List</a></li>
                      <li><a href="<?php echo e(URL::to('/create-return-order')); ?>">Create Return Order</a></li>
                      <li><a href="<?php echo e(URL::to('/return-order-list')); ?>">Return Order List</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-shopping-cart"></i> Due Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/due-list')); ?>">Due List</a></li>
                    
                    </ul>
                  </li>
                  
                  <li><a><i class="fa fa-hotel"></i> Stock Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/add-stock')); ?>">Add New Stock</a></li>
                      <li><a href="<?php echo e(URL::to('/stock-list')); ?>">Stock List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-trash"></i> Wastage Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/add-wastage')); ?>">Add Wastage Item</a></li>
                      <li><a href="<?php echo e(URL::to('/wastage-list')); ?>">Wastage List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-pie-chart"></i> Reports <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/stock-list-report')); ?>">Stock Reports</a></li>
                      <li><a href="<?php echo e(URL::to('/sales-report-by-order')); ?>">Sales Reports By Order</a></li>
                      <li><a href="<?php echo e(URL::to('/sales-report-by-item')); ?>">Sales Reports By Item</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-users"></i> Customer Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      
                      <li><a href="<?php echo e(URL::to('/create-customer')); ?>">Create New Customer</a></li>
                      <li><a href="<?php echo e(URL::to('/customer-list')); ?>">Customer List</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-archive"></i> Food Menu <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/add-category')); ?>">Add Menu</a></li>
                      <li><a href="<?php echo e(URL::to('/category-list')); ?>">Menu List</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-list"></i> Food Items <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/add-product')); ?>">Add Item</a></li>
                      <li><a href="<?php echo e(URL::to('/product-list')); ?>">Item List</a></li>
                    </ul>
                  </li>
              
                </ul>
              </div>
              <div class="menu_section">
                <h3>User Panel</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-user-plus"></i> User Management <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/create-admin')); ?>">Create Admin</a></li>
                      <li><a href="<?php echo e(URL::to('/admin-list')); ?>">Admin List</a></li>
                     
                    </ul>
                  </li>
                  <li><a><i class="fa fa-user-plus"></i> Settings <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo e(URL::to('/edit-settings')); ?>">Basic Settings</a></li>
                      <li><a href="<?php echo e(URL::to('/edit-role')); ?>">Edit Role</a></li>
                     
                    </ul>
                  </li>
              
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo e(URL::to('/logout')); ?>">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav hidden-print">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="images/img.jpg" alt=""><?php echo e(Session::get('admin_name')); ?>

                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="<?php echo e(URL::to('/logout')); ?>"><i class="fa fa-sign-out"></i> Log Out</a></li>
                  </ul>
                </li>

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        
        
        <!-- page content -->
        
        <?php echo $__env->yieldContent('admin_main_content'); ?>
        <!-- /page content -->

        <!-- footer content -->
        <footer class="hidden-print">
          <div class="pull-right">
              Developed by: <a href="https://muktodharaltd.com"><b>Muktodhara Technology Ltd.</b></a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    
   
   <script src="<?php echo e(asset('public/admin_asset/vendors/jquery/dist/jquery.min.js')); ?>"></script>
   <!-- Bootstrap -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo e(asset('public/admin_asset/vendors/nprogress/nprogress.js')); ?>"></script>
    
    
    <!-- Initialize datetimepicker -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="<?php echo e(asset('public/admin_asset/vendors/moment/min/moment.min.js')); ?>"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset('public/admin_asset/build/js/custom.min.js')); ?>"></script>
    
    <?php 
    $data=Cart::content();
    ?>
   

   <script>
    $(document).ready(function(){
        
         $('.add_cart').click(function(){

          var product_id = $(this).data("productid");
          //console.log(product_id);


          $('.cart_list_table').html("<tr><td colspan='6'><h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1><td></tr>");

          $.ajax({
            url:"<?php echo e(URL('/addTo')); ?>",
            method:"get",
            data:{product_id:product_id},

            success: function(data) {
        
              if(data == "1"){

                $('.cart_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              }else{
                
                var af_splt = data.split("__sep__");

                $('.cart_list_table').html(af_splt[0]);

                $('.get_total_for_dis').html("Total TK. "+af_splt[1]);
                
                $('.get_total_for_dis').attr('data-total-dis', af_splt[1]);

                $(".discount_input").val("0");
                $(".ammount_received").val("");
                $(".ammount_return").val("");
                $(".ammount_due").val("");

                $(".after_discount_input").val(af_splt[1]);
                
              }              

              
            }
            
          });
          
        });
         
         
         
    });
         
    </script>
    
    <script>
    $(document).ready(function(){
            
            $(document).on('click','.date_from_to_for_sales_order',function(){
                
                
                var date_from = $(".date_from").val();
                var date_to = $(".date_to").val();
                
                $(".order_list_table").html();
                
                $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
                
                $.ajax({

                    url:"<?php echo e(URL('/search-sales-report-order')); ?>",
        
                    method:"GET",
        
                    data:{dt_from:date_from,dt_to:date_to},
        
                    success: function(data) {
        
                      if(data == "1"){
                          $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                      }else{
                        $('.order_list_table').html(data);
                        $('.hide_pagi').hide();
                      }              
        
                      
                    }
            
                });
                
                
                
            });
            
            
            
            
            
            $(document).on('click','.date_from_to_for_sales',function(){
                
                
                var date_from = $(".date_from").val();
                var date_to = $(".date_to").val();
                
                $(".order_list_table").html();
                
                $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
                
                $.ajax({

                    url:"<?php echo e(URL('/search-sales-report')); ?>",
        
                    method:"GET",
        
                    data:{dt_from:date_from,dt_to:date_to},
        
                    success: function(data) {
        
                      if(data == "1"){
                          $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                      }else{
                        $('.order_list_table').html(data);
                        $('.hide_pagi').hide();
                      }              
        
                      
                    }
            
                });
                
                
                
            });
         
            
            
            
            $(document).on('click','.date_from_to',function(){
                
                
                var date_from = $(".date_from").val();
                var date_to = $(".date_to").val();
                
                $(".order_list_table").html();
                
                $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
                
                $.ajax({

                    url:"<?php echo e(URL('/search-order-date')); ?>",
        
                    method:"GET",
        
                    data:{dt_from:date_from,dt_to:date_to},
        
                    success: function(data) {
        
                      if(data == "1"){
                          $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                      }else{
                        $('.order_list_table').html(data);
                        $('.hide_pagi').hide();
                        
                      }              
        
        
                     // $('.gen_range').html("Showing data from "+date_from+"to "+date_to);
                      
                      
                    }
            
                });
                
                
                
            });
            
            
            
            

              $(document).on('click','.date_from_to_due',function(){
                
                
                var date_from = $(".date_from").val();
                var date_to = $(".date_to").val();
                
                $(".order_list_table").html();
                
                $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
                
                $.ajax({

                    url:"<?php echo e(URL('/search-order-date-due')); ?>",
        
                    method:"GET",
        
                    data:{dt_from:date_from,dt_to:date_to},
        
                    success: function(data) {
        
                      if(data == "1"){
                          $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                      }else{
                         $('.hide_pagi').hide();
                        $('.order_list_table').html(data);
                      }              
        
        
                     // $('.gen_range').html("Showing data from "+date_from+"to "+date_to);
                      
                      
                    }
            
                });
                
                
                
            });







              $(document).on('click','.date_from_to_cancel_order',function(){
                
                
                var date_from = $(".date_from").val();
                var date_to = $(".date_to").val();
                
                $(".order_list_table").html();
                
                $('.order_list_table').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
                
                $.ajax({

                    url:"<?php echo e(URL('/search-order-date-cancel-order')); ?>",
        
                    method:"GET",
        
                    data:{dt_from:date_from,dt_to:date_to},
        
                    success: function(data) {
        
                      if(data == "1"){
                          $('.order_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                      }else{
                          $('.hide_pagi').hide();
                        $('.order_list_table').html(data);
                      }              
        
        
                     // $('.gen_range').html("Showing data from "+date_from+"to "+date_to);
                      
                      
                    }
            
                });
                
                
                
            });
            
            
            
            $(document).on('click','.cat_list_tag',function(){
                
                $(".cat_list_tag").removeClass('cat_list_tag_active');
                $(this).addClass('cat_list_tag_active');
                
                var cat_id = $(this).attr('data-cat-id');
                
                var cat_name = $(this).attr('data-cat-name');
                
                var all_pro = $(".show_pro_all").html();
                
                $('.show_pro_all').html("<h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1>");
                
                $('.show_pro_small_cat').html("<i class='fa fa-spinner fa-spin'></i>");
                
                $.ajax({

                    url:"<?php echo e(URL('/search-pro-by-cat')); ?>",
        
                    method:"GET",
        
                    data:{by_cat_id:cat_id},
        
                    success: function(data) {
        
                      if(data == "1"){
                          $('.show_pro_all').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");
                          $('.show_pro_small_cat').html(" ");
                      }else{
                        $('.show_pro_all').html(data);
                        $('.show_pro_small_cat').html(cat_name.toUpperCase());
                      }              
        
        
                     
                      
                      
                    }
            
                });
                
                
                
            });
            
            
            $(".discount_input").val("0");
            $(".after_discount_input").val("0");
            
            if($(".discount_input").val() == 0 || $(".discount_input").val() < 99.99){
                    
                var dis = parseInt($(".discount_input").val());
                
                var total = parseInt($(".get_total_for_dis").attr('data-total-dis'));
                
                var am_pay = total - ( (total*dis)/100);
                
                $(".after_discount_input").val(am_pay);
                
            }
            
            
            $(".discount_input").on('change keyup',function(){
                
                $(".ammount_received").val("");
                $(".ammount_return").val("");
                $(".ammount_due").val("");
                
                if($(this).val() != ""){
                    
                    if($(".discount_input").val() == 0 || $(".discount_input").val() < 99.99){
                        
                        var dis = parseInt($(this).val());
                        
                        var total = parseInt($(".get_total_for_dis").attr('data-total-dis'));
                        
                        var am_pay = total - ( (total*dis)/100);
                        
                        $(".after_discount_input").val(am_pay);
                        
                    }else{
                        $(".after_discount_input").val("");
                    }
                        
                    
                }else{
                    $(".after_discount_input").val("");
                }
                
                    
      
           });
           
           
           
            $(".ammount_received").on('change keyup',function(){
                
                if(!$(this).val()){
                    
                    $(".ammount_return").val("");
                    $(".ammount_due").val("");
                    
                }else{
                    
                    var payabl = parseInt($(".after_discount_input").val());
                    var recv = parseInt($(this).val());
                    
                    
                    if(recv > 0){
                        
                        if(recv > payabl){
                            
                            var rec = parseInt($(this).val());
                            var total = parseInt($(".after_discount_input").val());
                            var ret = rec - total ;
                            $(".ammount_return").val(ret);
                            $(".ammount_due").val("0");
                        }else{
                            var rec = parseInt($(this).val());
                            var total = parseInt($(".after_discount_input").val());
                            var ret = total - rec ;
                            $(".ammount_return").val("0");
                            $(".ammount_due").val(ret);
                        }
                            
                    }else{
                        $(".ammount_due").val(payabl);
                            $(".ammount_return").val("0");
                    }
                    
                    
                }
                
                    
      
           });
    
           
           
           
           
           
           $(".check_cust").on('click',function(){
               
               if($(this).val() == '1'){
                   $(".collapse_hide").slideUp();
               }
               
               if($(this).val() == '2'){
                   $(".collapse_hide").slideDown();
               }
               
           });
    
    

        
    });
    </script>
        

  <script>
  $( function() {
    $( ".datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
    
    <script>
        <?php
            if(isset($_GET['oid'])){
                if($_GET['oid'] > 0){
            ?>
                window.open(
                    '<?php echo e(url('/print-order-page/'.$_GET['oid'])); ?>',
                    '_blank'
                );
                
            <?php
                }
            }
           ?>
               
        function myFunction(aaa){
            
            var product_id = aaa;
            console.log(product_id);
            
              $('.cart_list_table').html("<tr><td colspan='6'><h1 style='text-align:center;color:gray; padding:20px 0;'><i class='fa fa-spinner fa-spin'></i></h1><td></tr>");

            $.ajax({
                
                url:"<?php echo e(URL('/addTo')); ?>",
                method:"get",
                data:{product_id:product_id},
                success:function(data){
                    
                  if(data == "1"){

                $('.cart_list_table').html("<br><p>&nbsp;&nbsp;&nbsp;&nbsp; Nothing Found.</p>");

              }else{
                
                var af_splt = data.split("__sep__");

                $('.cart_list_table').html(af_splt[0]);

                $('.get_total_for_dis').html("Total TK. "+af_splt[1]);
                
                $('.get_total_for_dis').attr('data-total-dis', af_splt[1]);

                $(".discount_input").val("0");
                $(".ammount_received").val("");
                $(".ammount_return").val("");
                $(".ammount_due").val("");

                $(".after_discount_input").val(af_splt[1]);
                
              } 
               
                }
                
            });
           
            
        }
        
        function removeFunction(del_id){
            
            var product_id = del_id;
            
            $('.rem_row_'+product_id).css("opacity", "0.6");

            $.ajax({
                
                url:"<?php echo e(URL('cart/remove/')); ?>",
                method:"get",
                data:{rem_id:product_id},
                success:function(data){
                    
                  if(data == "1"){

                    $('.cart_list_table').html("<tr><td colspan='6'><h3 style='text-align:center;color:gray; padding:20px 0;'>Cart is Empty!</h3><td></tr>");

                    $('.get_total_for_dis').html("Total TK. 0");
                    
                    $('.get_total_for_dis').attr('data-total-dis', '0');

                    $(".discount_input").val("0");
                    $(".ammount_received").val("");
                    $(".ammount_return").val("");
                    $(".ammount_due").val("");

                    $(".after_discount_input").val('0');

                  }else{
                    
                    $('.rem_row_'+product_id).fadeOut("slow");

                    var af_splt = data;

                    $('.get_total_for_dis').html("Total TK. "+af_splt);
                    
                    $('.get_total_for_dis').attr('data-total-dis', af_splt);

                    $(".discount_input").val("0");
                    $(".ammount_received").val("");
                    $(".ammount_return").val("");
                    $(".ammount_due").val("");

                    $(".after_discount_input").val(af_splt);
                    
                  } 
               
                }
                
            });
           
            
        }



        function plusFunction(iiddd, prrr){
            var x = iiddd;
            var po = parseInt($("."+x).val());

            var af_sp_id = x.split("product_id_");

            po = po + 1;
            $("."+x).val(po);

            changeFunction(po,af_sp_id[1]);

            var shwTotal = prrr*po;

            $(".shwTotal_"+af_sp_id[1]).html(shwTotal)
          }

          function minusFunction(iidd, prr){
            var y = iidd;
            var lo = parseInt($("."+y).val());

            var af_sp_idd = y.split("product_id_");

            if (lo > 1) {			
              lo = lo - 1;
              $("."+y).val(lo);
              changeFunction(lo,af_sp_idd[1]);

              var shwTotal = prr*lo;

              $(".shwTotal_"+af_sp_idd[1]).html(shwTotal)
            }  
          }


        function changeFunction(qqq,rrr){

          var qty = qqq;
          var rowid = rrr;

          console.log(qty);
          console.log(rowid);

          $.ajax({
              url:"<?php echo e(URL('/cart/update')); ?>",
              data:'qty=' + qty + '&rowid=' + rowid,
              type:'get',
              success:function(dataaaa){

                    $('.get_total_for_dis').html("Total TK. "+dataaaa);
                    
                    $('.get_total_for_dis').attr('data-total-dis', dataaaa);

                    $(".discount_input").val("0");
                    $(".ammount_received").val("");
                    $(".ammount_return").val("");
                    $(".ammount_due").val("");

                    $(".after_discount_input").val(dataaaa);
              } 
          });


        }
        
        
    
    </script>
  </body>
</html>