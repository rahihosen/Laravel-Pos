  
<?php $__env->startSection('admin_main_content'); ?>

    <!-- page content -->
    <div class="right_col right_col_back" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <div class="box_layout col-md-12 col-sm-12 col-xs-12">			

                        <h3 class="no_padding bottom_padding"><i class="fa fa-user-plus"></i> Accounts </h3>
                        
                    </div>


                    <?php 

                        $message = Session::get('message');

                        if ( $message !='') { ?>

                            <div class="col-md-12 col-sm-12 col-xs-12" style="padding: 0;">

                                <h5 class="text-center">

                                    <?php

                                        if(isset($message)) { ?>

                                            <div class="alert alert-success alert-dismissible fade in" style="margin: 0;margin-bottom: 12px;box-shadow: 4px 4px 5px rgb(204, 203, 203);">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong> <?php echo $message;?> </strong>
                                            </div>
                                            
                                        <?php
                                            Session::put('message','');
                                        }
                                    ?>

                                </h5>
                            </div> 
                            
                            <?php 
                        }
                        
                    ?>
                    

                    <div class="no_padding right_padding col-md-4 col-sm-4 col-xs-12">				
                        
                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Add Account</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">        
                                
                                
                                <?php echo Form::open(['url' => '/save-account','method'=>'post','enctype'=>'multipart/form-data']); ?>

                                
                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="account-name">Account Name </label>
                                        <input type="text" id="account_name" name="account_name" required="required" class="form-control">
                                        
                                    </div>

                                    <div class="form-group form-group-sm">

                                        <label class="control-label" for="branch-name">Branch</label>
                                        <input type="text" id="branch-name" name="branch_name" required="required" class="form-control ">
                                        
                                    </div>                                    
                                    
                                    
                                    <div class="form-group form-group-sm">

                                        <label class="control-label " for="account-no" style="padding-top: 10px;">Account No </label>
                                        <input type="text" name="account_no" required="required" class="form-control ">
                                        
                                    </div>
                                   

                                    <!-- <div class="form-group" style="padding-top: 10px;">
                                        <label class="control-label ">Active?</label>

                                        <div><br></div>

                                        <div id="gender" class="btn-group" data-toggle="buttons">
                                            <label class="btn btn-default active" >
                                                <input type="radio"  name="admin_status" value="1" required="required"  checked="checked" /> &nbsp; Yes &nbsp;
                                            </label>

                                            <label class="btn btn-default" >
                                                <input type="radio" name="admin_status" value="0" required="required"> No
                                            </label>
                                        </div>
                                        
                                    </div> -->

                                    <div class="ln_solid"></div>

                                    <div class="form-group form-group-sm">
                                        
                                        <!-- <a href="<?php echo e(URL::to('customer-list')); ?>" class="btn btn-primary">Back</a>
                                        <button class="btn btn-primary" type="reset">Reset</button> -->
                                        <button type="submit" class="btn btn-success">Save</button>
                                        
                                    </div>

                                <?php echo Form::close(); ?>                                
                                
                            </div>
                        </div>
                        
                    </div>

                    <div class="no_padding col-md-8 col-sm-8 col-xs-12">

                        <div class="panel panel-amin">

                            <div class="panel-heading">
                                <h3 class="panel-title">Account List</h3>
                                <span class="pull-right clickable"><i class="fa fa-plus"></i></span>
                            </div>

                            <div class="panel-body">
                                <div class="table-responsive">                                    

                                    <table class="table table-striped bulk_action table-responsive table-bordered">

                                        <?php

                                            $data = count($all_accounts);

                                            if ( $data !='' ) { ?>

                                                <thead>
                                                    <tr class="headings">
                                                        <th class="column-title text-center">ID </th>
                                                        <th class="column-title text-center">Name </th>
                                                        <th class="column-title text-center">Branch </th>
                                                        <th class="column-title text-center">Account No. </th>
                                                        <th class="column-title text-center">Created By </th>
                                                        <th class="column-title text-center">Opening Date / Time</th>
                                                        <th class="column-title text-center">Update Date / Time</th>
                                                        <th class="column-title text-center"> Action </th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    
                                                    <?php foreach($all_accounts as $account) { ?>

                                                        <tr class="even pointer">
                                                            <td class="text-center"><?php echo e($account->account_id); ?></td>
                                                            <td class="text-center"><?php echo e($account->account_name); ?></td>
                                                            <td class="text-center"><?php echo e($account->account_branch); ?></td>
                                                            <td class="text-center"><?php echo e($account->account_no); ?></td>
                                                            <td class="text-center"><?php echo e($account->admin_name); ?></td>
                                                            <td class="text-center"><?php echo e($account->account_created_date); ?> / <?php echo e($account->account_created_time); ?></td>

                                                            <?php 
                                                                $data = $account->account_updated_date;
                                                                if ( $data !='' ) { ?>

                                                                    <td class="text-center"><?php echo e($account->account_updated_date); ?> / <?php echo e($account->account_updated_time); ?></td>

                                                                    <?php
                                                                } else { ?>

                                                                    <td> </td>

                                                                    <?php
                                                                }
                                                            ?>
                                                            
                                                            <td class="text-center">

                                                                <button
                                                                    class="btn btn-dark btn-xs edit_account"

                                                                    value="<?php echo e($account->account_id); ?>"
                                                                    accountName="<?php echo e($account->account_name); ?>"
                                                                    accountBranch="<?php echo e($account->account_branch); ?>"
                                                                    accountNo="<?php echo e($account->account_no); ?>"

                                                                    ><i class="fas fa-pencil-alt"></i> Edit
                                                                
                                                                </button>
                                                                
                                                            </td>
                                                        </tr>

                                                        <?php
                                                    }
                                                    ?>
                                                    
                                                        
                                                </tbody>

                                                <?php 
                                            }
                                        ?>
                                                
                                    </table>
                                    
                                </div>
                            </div>

                            <div class=" pull-right">

                                <?php if( $all_accounts != ''): ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/accounts-list?page=1')); ?>">First</a> </li>
                                    </ul>

                                    <?php echo e($all_accounts->links()); ?> 

                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="<?php echo e(URL::to('/accounts-list?page='.$all_accounts->lastPage())); ?>">Last</a> </li>
                                    </ul>

                                <?php endif; ?>

                            </div>

                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Edit Accounts Modal -->
    <div style="z-index:9999999999" class="modal fade edit_account_modal" id="edit" role="dialog">
        <div class="modal-dialog modal-md">

            <div class="modal-content">

                <div class="modal-header">                    
                    <h4 class="modal-title">Edit Account <button type="button" class="close" data-dismiss="modal" style="color: #fff;">&times;</button></h4>
                </div>

                <div class="modal-body">
                
                    <?php echo Form::open(['url'=>'/update-account','method'=>'post','enctype'=>'multipart/form-data']); ?>


                        <div class="form-group form-group-sm">
                            <label class="control-label" > ID </label>
                            <input type="text" id="first-name" class="form-control account_id" value="" disabled>
                            <input type="hidden" id="last-name"  name="account_id" value="" class="form-control account_id">
                            
                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" > Account Name </label>
                            <input type="text"  name="account_name" value="" required="required" class="form-control account_name">

                        </div>

                        <div class="form-group form-group-sm">

                            <label class="control-label" for="branch-name">Branch</label>
                            <input type="text" id="branch-name" name="branch_name" required="required" class="form-control branch_name">
                            
                        </div>
                        
                        <div class="form-group form-group-sm">

                            <label class="control-label " for="account-no" style="padding-top: 10px;">Account No </label>
                            <input type="number" name="account_no" required="required" class="form-control account_no">

                        </div>

                        <div class="ln_solid"></div>

                        <div class="form-group form-group-sm">

                            <!-- <a href="<?php echo e(URL::to('customer-list')); ?>" class="btn btn-primary">Back</a>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" class="btn btn-success">Update</button>
                        
                        </div>

                    <?php echo Form::close(); ?>

                
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>	  
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>