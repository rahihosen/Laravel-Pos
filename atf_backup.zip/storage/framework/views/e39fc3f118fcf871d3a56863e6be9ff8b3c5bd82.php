  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Cancel Order Product </h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />

                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action table-responsive table-bordered">
                                <thead>
                                    <tr class="headings">
                                        <th class="column-title">Order ID </th>
                                        <th class="column-title">Customer ID </th>
                                        <th class="column-title">P.ID </th>
                                        <th class="column-title"> Product Name </th>
                                        <th class="column-title"> Sale Price </th>
                                        <th class="column-title"> Quantity </th>
                                        <th class="column-title"> Subtotal </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($edit_ordered_product_info as $product) { ?>
                                        <?php echo Form::open(['url'=>'/update-order-product','method'=>'post','enctype'=>'multipart/form-data']); ?>


                                        <tr class="even pointer">
                                            <td class=" "><input type="hidden" name="order_id" value="<?php echo e($product->order_id); ?>"><?php echo e($product->order_id); ?></td>
                                            <td class=" "><input type="hidden" name="customer_id" value="<?php echo e($product->customer_id); ?>"><?php echo e($product->customer_id); ?></td>
                                            <td class=" "><input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>"><?php echo e($product->product_id); ?></td>
                                            <td class=" "><input type="hidden" name="product_name" value="<?php echo e($product->product_name); ?>"><?php echo e($product->product_name); ?></td>
                                            <td class=" "><input type="hidden" name="product_sale_price" value="<?php echo e($product->product_sale_price); ?>"><?php echo e($product->product_sale_price); ?></td>
                                            <td class=" "><input type="hidden" name="product_qty" value="<?php echo e($product->product_qty); ?>"><?php echo e($product->product_qty); ?></td>
                                            <td class=" last"><?php echo e($product->sub_total); ?></td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                            Total:  <?php
                                            $order_id = $edit_ordered_product_info_row->order_id;

                                            echo $total = DB::table('order_details')
                                            ->where('order_id', $order_id)
                                            ->sum('sub_total');
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td></td> 
                                        <td></td> 
                                        <td></td> 
                                        <td></td> 
                                        <td></td> 
                                        <td></td> 
                                        <td>
                                            <a href="<?php echo e(URL::to('create-cancel-order')); ?>" class="btn btn-primary">Back</a>
                                            <button type="submit" class="btn btn-success">Next</button>
                                        </td>
                                    </tr>
                                    <?php echo Form::close(); ?>   
                                </tbody>
                            </table>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- /page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>