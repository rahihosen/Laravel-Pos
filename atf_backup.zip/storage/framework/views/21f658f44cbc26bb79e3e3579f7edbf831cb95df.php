<h2>Front end master page header</h2>
    
        
<?php echo $__env->yieldContent('main_content'); ?>


<h2>Front end master page footer</h2>