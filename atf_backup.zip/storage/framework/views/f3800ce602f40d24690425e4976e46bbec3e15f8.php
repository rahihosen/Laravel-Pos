  
<?php $__env->startSection('admin_main_content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Edit Settings </h2>

                       
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <div id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" enctype="multipart/form-data">
                                                 
                            <?php echo Form::open(['url'=>'/update-settings','method'=>'post','enctype'=>'multipart/form-data','name'=>'edit_settings']); ?>

                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">ID <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="first-name" class="form-control col-md-7 col-xs-12 " value="<?php echo e($settings_by_id->settings_id); ?>" disabled>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Company Name <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="last-name" name="company_name" value="<?php echo e($settings_by_id->company_name); ?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <input type="hidden" id="last-name" name="settings_id" value="<?php echo e($settings_by_id->settings_id); ?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <input type="hidden" id="last-name" name="company_logo" value="<?php echo e($settings_by_id->company_logo); ?>" class="form-control col-md-7 col-xs-12">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Company Logo <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="file" id="last-name" name="company_logo" class="form-control col-md-7 col-xs-12">
                                    <span>
                                        <img src="<?php echo e(asset($settings_by_id->company_logo)); ?>" width="80" height="50">
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Company Mobile <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="number" id="last-name" name="company_mobile" value="<?php echo e($settings_by_id->company_mobile); ?>" required="required" class="form-control col-md-7 col-xs-12">
        
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Company Email <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="email" id="last-name" name="company_email" value="<?php echo e($settings_by_id->company_email); ?>" required="required" class="form-control col-md-7 col-xs-12">
        
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Company Address <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="last-name" name="company_address" value="<?php echo e($settings_by_id->company_address); ?>" required="required" class="form-control col-md-7 col-xs-12">
        
                                </div>
                            </div>
                            
                          

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <a href="<?php echo e(URL::to('create-settings')); ?>" class="btn btn-primary">Back</a>
                                    <button class="btn btn-primary" type="reset">Reset</button>
                                    <button type="submit" class="btn btn-success">Update</button>
                                </div>
                            </div>

                            <?php echo Form::close(); ?>

                        </div
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

</div>

<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>